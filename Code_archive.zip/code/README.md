# Code

Paper: "Rainfall–earthquake interaction versus superposition in slope stability: closed-form and field evidence".

- `bishop_ps.py` – pseudo-static Bishop simplified solver (Eqs. 1–2).
- `msh_*.py` – dataset audit, interaction factorial, calibrated equation, ML framework and figures.
- `fe_srm.py`, `fe_layered.py`, `fe_factorial.py`, `fe_analysis.py`, `fe_tandikat_mesh.py` – 2D finite-element strength reduction (Section 2.6, 5.6, 6.4). `fe_tandikat_long.py` is an exploratory run that was not used (element aspect ratio too large).
- `case_tandikat/` – Tandikat 2009 worked calculation, sensitivity and rigid-block time history (Section 6).
- `fv_*.py` – Iburi 2018 field test (Section 7), run in this order:
  1. `fv_slope.py <tile_E141.tif> <tile_E142.tif>` – Horn slope at sample points (Copernicus GLO-30).
  2. `fv_pga.py <grid.xml>` – ShakeMap PGA/PGV/Vs30 at the points.
  3. `fv_source_slope.py <inventory.shp> <tile_E141.tif> <tile_E142.tif> <grid.xml>` – source-area slope and matched hillslope sample.
  4. `fv_analysis_matched.py`, `fv_equivalent.py` – performance, spatial cross-validation, equivalent friction angle.
  5. `fv_figure.py` – Fig. 16.
  `fv_analysis.py` is the earlier centroid-based version (superseded).

See `../README_FINAL.md` for the run order of the remaining scripts and the folder layout (MSH_OUT / MSH_DATA / MSH_WORK).
Data sources: Zhang et al. (2019) Zenodo 10.5281/zenodo.2577300; USGS ShakeMap us2000h8ty; Copernicus GLO-30.

## Supplementary Video S1
`video/` – `fe_video_compute.py` (FE load paths, critical k_h, strength-reduction sequence, generic-slope mechanisms), `newmark_video_compute.py`, `iburi_video_compute.py <tile_E141> <tile_E142> <inventory.shp> <grid.xml>`, then `scenes/*.py` render each scene (1920x1080, 30 fps) and `assemble.sh` concatenates them with ffmpeg.
