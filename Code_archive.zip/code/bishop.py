"""
Bishop's simplified method for a homogeneous slope (height H, angle beta, c, phi, gamma, r_u) with a circular slip
surface. Search: circle centres on a grid above the slope; radius set so the circle passes through the toe or below
it (depth factors). Returns the minimum FoS. Pure physics, no data labels involved.
"""
import numpy as np
def bishop_fos(H, beta, c, phi, gam, ru, n_slices=40, ngrid=25, depths=(0.0, 0.25, 0.5), iters=12):
    H = max(H, .1); b = np.radians(np.clip(beta, 5, 85)); L = H / np.tan(b)          # toe (0,0), crest (L,H)
    tphi = np.tan(np.radians(phi))
    xs = np.linspace(-0.5 * H, L + 1.0 * H, ngrid); ys = np.linspace(H * 0.6, H * 3.0 + L * 0.5, ngrid)
    XC, YC = [a.ravel() for a in np.meshgrid(xs, ys)]
    best = np.inf
    for dfac in depths:                                                              # circle passes through point (xd, -dfac*H)
        yd = -dfac * H; xd = 0.0 if dfac == 0 else -dfac * H * 0.0
        R = np.sqrt((XC - xd) ** 2 + (YC - yd) ** 2)
        # ground surface y_g(x): yd level left of toe (for depth circles the exit is on the base ground line y=0)
        # entry on crest side: intersection of circle with y = H (x > L)
        dy = YC - H; ok = R > dy
        x_entry = XC + np.sqrt(np.clip(R ** 2 - dy ** 2, 0, None))
        dy0 = YC - 0.0; x_exit = XC - np.sqrt(np.clip(R ** 2 - dy0 ** 2, 0, None))  # exit on y=0 (toe level) left side
        if dfac == 0: x_exit = np.zeros_like(XC)
        ok &= (x_entry > L) & (x_exit <= 1e-6) & (x_entry - x_exit > .2 * H)
        if not ok.any(): continue
        XC_, YC_, R_, xa, xb = XC[ok], YC[ok], R[ok], x_exit[ok], x_entry[ok]
        t = (np.arange(n_slices) + .5) / n_slices; xm = xa[:, None] + (xb - xa)[:, None] * t[None]; w = ((xb - xa) / n_slices)[:, None]
        ytop = np.clip(xm / max(L, 1e-9) * H, 0, H); ytop = np.where(xm < 0, 0.0, ytop)
        ybot = YC_[:, None] - np.sqrt(np.clip(R_[:, None] ** 2 - (xm - XC_[:, None]) ** 2, 0, None))
        h = np.clip(ytop - ybot, 0, None); W = gam * h * w
        alpha = np.arcsin(np.clip((xm - XC_[:, None]) / R_[:, None], -.99, .99))
        u = ru * gam * h                                                             # pore pressure from r_u
        drive = (W * np.sin(alpha)).sum(1); valid = drive > 1e-6
        F = np.ones(len(XC_)) * 1.5
        for _ in range(iters):
            m = np.cos(alpha) * (1 + np.tan(alpha) * tphi / F[:, None]); m = np.clip(m, .2, None)
            res = ((c * w + (W - u * w) * tphi) / m).sum(1); F = np.where(valid, res / np.where(valid, drive, 1), np.inf)
            F = np.clip(F, .05, 50)
        F = np.where(valid, F, np.inf); best = min(best, float(F.min()))
    return best if np.isfinite(best) else 50.0
if __name__ == "__main__":
    # sanity checks: (1) c=0 dry slope ~ tan(phi)/tan(beta) (shallow surfaces); (2) monotone trends
    print("c=0, phi=30, beta=20 :", round(bishop_fos(10, 20, 0.01, 30, 20, 0), 3), " infinite-slope", round(np.tan(np.radians(30)) / np.tan(np.radians(20)), 3))
    base = bishop_fos(10, 26.57, 10, 20, 20, 0); print("H10 2:1 c10 phi20 dry:", round(base, 3))
    print("  +c:", round(bishop_fos(10, 26.57, 20, 20, 20, 0), 3), " +phi:", round(bishop_fos(10, 26.57, 10, 25, 20, 0), 3),
          " +beta:", round(bishop_fos(10, 35, 10, 20, 20, 0), 3), " +ru 0.3:", round(bishop_fos(10, 26.57, 10, 20, 20, .3), 3), " +H:", round(bishop_fos(20, 26.57, 10, 20, 20, 0), 3))
