"""Pseudo-static Bishop simplified limit-equilibrium method for a homogeneous slope (circular slip surfaces).

FoS = sum[(c b + (W - u b) tan(phi)) / m_alpha] / sum[W sin(alpha) + kh W (yc - y_g) / R]
m_alpha = cos(alpha) (1 + tan(alpha) tan(phi) / FoS),   u = r_u * gamma * h   (pore pressure from r_u)
Horizontal seismic force kh*W acts at each slice centroid (moment arm yc - y_g about the circle centre).
Critical surface: grid search over circle centres x toe / below-toe exit depths, then a local refinement around the
best centre. Fully vectorised over candidate circles; dimensionless inputs give the same FoS for any (H, gamma) pair.
"""
import numpy as np

def _fos_circles(XC, YC, R, xa, xb, H, beta_r, c, tphi, gam, ru, kh, n=40, iters=25):
    L = H / np.tan(beta_r)
    t = (np.arange(n) + .5) / n; xm = xa[:, None] + (xb - xa)[:, None] * t[None]; b = ((xb - xa) / n)[:, None]
    ytop = np.where(xm < 0, 0.0, np.where(xm > L, H, xm * np.tan(beta_r)))
    ybot = YC[:, None] - np.sqrt(np.clip(R[:, None] ** 2 - (xm - XC[:, None]) ** 2, 0, None))
    h = np.clip(ytop - ybot, 0, None); W = gam * h * b
    sa = np.clip((xm - XC[:, None]) / R[:, None], -.999, .999); al = np.arcsin(sa)
    yg = (np.maximum(ybot, ybot) + ytop) / 2
    drive = (W * sa).sum(1) + (kh * W * (YC[:, None] - yg)).sum(1) / R
    u = ru * gam * h
    ok = drive > 1e-9; F = np.full(len(XC), 1.5)
    for _ in range(iters):
        m = np.cos(al) * (1 + np.tan(al) * tphi / F[:, None]); m = np.clip(m, .15, None)
        res = ((c * b + np.clip(W - u * b, 0, None) * tphi) / m).sum(1)
        F = np.clip(np.where(ok, res / np.where(ok, drive, 1), 50.), .02, 50.)
    return np.where(ok & (h.max(1) > 1e-6), F, 50.)

def _candidates(XC, YC, H, L, depth):
    yd = -depth * H
    R = np.sqrt(XC ** 2 + (YC - yd) ** 2) if depth == 0 else (YC - yd)       # through toe, or tangent below toe level
    dy = YC - H; ok = R > dy
    xb = XC + np.sqrt(np.clip(R ** 2 - dy ** 2, 0, None))                    # exit on crest
    xa = (XC - np.sqrt(np.clip(R ** 2 - YC ** 2, 0, None))) if depth > 0 else np.zeros_like(XC)
    ok &= (xb > L + 1e-6) & (xa <= 1e-6) & (xb - xa > .2 * H)
    return R, xa, xb, ok

def bishop_ps(H, beta, c, phi, gam, ru=0.0, kh=0.0, ngrid=22):
    """Minimum pseudo-static Bishop FoS (dimensional inputs: m, deg, kPa, deg, kN/m3, -, -)."""
    H = max(float(H), .1); br = np.radians(np.clip(beta, 5, 85)); L = H / np.tan(br); tphi = np.tan(np.radians(phi))
    best, arg = np.inf, None
    for depth in (0.0, 0.1, 0.25, 0.5):
        xs = np.linspace(-0.6 * H, L + 0.8 * H, ngrid); ys = np.linspace(0.4 * H, H * 2.5 + L * 0.6, ngrid)
        XC, YC = [a.ravel() for a in np.meshgrid(xs, ys)]
        R, xa, xb, ok = _candidates(XC, YC, H, L, depth)
        if not ok.any(): continue
        F = _fos_circles(XC[ok], YC[ok], R[ok], xa[ok], xb[ok], H, br, c, tphi, gam, ru, kh)
        j = int(np.argmin(F))
        if F[j] < best: best, arg = F[j], (XC[ok][j], YC[ok][j], depth)
    if arg is None: return 50.0
    x0, y0, depth = arg; dx = (L + 1.4 * H) / ngrid; dyy = (H * 2.1 + L * .6) / ngrid
    xs = np.linspace(x0 - 1.5 * dx, x0 + 1.5 * dx, 13); ys = np.linspace(max(y0 - 1.5 * dyy, .05 * H), y0 + 1.5 * dyy, 13)
    XC, YC = [a.ravel() for a in np.meshgrid(xs, ys)]
    R, xa, xb, ok = _candidates(XC, YC, H, L, depth)
    if ok.any(): best = min(best, float(_fos_circles(XC[ok], YC[ok], R[ok], xa[ok], xb[ok], H, br, c, tphi, gam, ru, kh).min()))
    return float(best)

if __name__ == "__main__":
    import time
    t = time.time()
    print("dry c=0 phi=30 beta=20:", round(bishop_ps(10, 20, .01, 30, 20), 3), "(infinite slope 1.586)")
    b0 = bishop_ps(10, 26.57, 10, 20, 20); print("2:1 c10 phi20:", round(b0, 3))
    print(" kh=0.1:", round(bishop_ps(10, 26.57, 10, 20, 20, kh=.1), 3), " ru=0.3:", round(bishop_ps(10, 26.57, 10, 20, 20, ru=.3), 3), " both:", round(bishop_ps(10, 26.57, 10, 20, 20, .3, .1), 3))
    print("time per call (ms):", round((time.time() - t) / 5 * 1000, 1))
