"""Tandikat landslide (Padang Mw 7.6, 30 Sep 2009, during rainfall) - case study from Faris & Fawu (2014),
Geoenvironmental Disasters 1:4, doi:10.1186/s40677-014-0004-3. Infinite-slope pseudo-static analysis (their Eq. 29),
pore pressure from a slope-parallel perched water table of height m*l above the impermeable sandy clay.
Parameters from the paper: theta 30 deg, l = 3 m pumice sand, c' = 0, phi' = 39 deg, Gs 2.664, e = 2.0, bulk density 1.503 g/cm3."""
import numpy as np, pandas as pd
th, phi, l, c = np.radians(30), np.radians(39), 3.0, 0.0
gw = 9.81; g_m = 1.503 * gw; g_sat = (2.664 + 2.0) / 3.0 * gw            # 14.74 and 15.25 kN/m3
def fos(m, kh, ru_cyc=0.0):
    g = (1 - m) * g_m + m * g_sat                                          # weighted unit weight of the column
    sig = g * l * (np.cos(th) ** 2 - kh * np.sin(th) * np.cos(th)); tau = g * l * (np.sin(th) * np.cos(th) + kh * np.cos(th) ** 2)
    u = m * gw * l * np.cos(th) ** 2 + ru_cyc * max(sig - m * gw * l * np.cos(th) ** 2, 0)   # static + shaking-generated excess (ratio of sigma')
    return (c + (sig - u) * np.tan(phi)) / tau
def ky(m, ru_cyc=0.0):
    lo, hi = 0., 1.
    if fos(m, 0, ru_cyc) < 1: return 0.
    for _ in range(60):
        mid = (lo + hi) / 2; lo, hi = (mid, hi) if fos(m, mid, ru_cyc) >= 1 else (lo, mid)
    return lo
mcrit = [m for m in np.linspace(0, 1, 100001) if fos(m, 0) < 1][0]
rows = []
for m in (0, .2, .3, .4):
    for kh in (0, .05, .1, .15):
        rows.append(dict(water_table_ratio_m=m, kh=kh, FoS=fos(m, kh)))
T = pd.DataFrame(rows)
F = lambda m, k: fos(m, k)
inter = []
for m in (.2, .3, .4):
    for k in (.05, .1, .15):
        F0, FR, FE, FRE = F(0, 0), F(m, 0), F(0, k), F(m, k)
        inter.append(dict(m=m, kh=k, F_dry=F0, F_rain=FR, F_seismic=FE, F_combined=FRE, loss_sum_pct=((F0 - FR) + (F0 - FE)) / F0 * 100,
                          loss_combined_pct=(F0 - FRE) / F0 * 100, I_multiplicative=FRE * F0 / (FR * FE), fails_alone=bool(FR < 1 or FE < 1), fails_combined=bool(FRE < 1)))
K = pd.DataFrame(dict(m=[0, .1, .2, .3, .4], ky=[ky(m) for m in (0, .1, .2, .3, .4)]))
C = pd.DataFrame([dict(m=m, ru_cyclic=r, ky=ky(m, r)) for m in (0, .3) for r in (0, .2, .4, .6)])
T.round(4).to_csv("T1_FoS_grid.csv", index=False); pd.DataFrame(inter).round(4).to_csv("T2_interaction.csv", index=False)
K.round(4).to_csv("T3_yield_coefficient.csv", index=False); C.round(4).to_csv("T4_yield_with_cyclic_pore_pressure.csv", index=False)
print("gamma_m, gamma_sat", round(g_m, 2), round(g_sat, 2), " critical m (rain alone) =", round(mcrit, 3))
print(T.pivot(index="water_table_ratio_m", columns="kh", values="FoS").round(3)); print(pd.DataFrame(inter).round(3).to_string()); print(K.round(3)); print(C.round(3))
