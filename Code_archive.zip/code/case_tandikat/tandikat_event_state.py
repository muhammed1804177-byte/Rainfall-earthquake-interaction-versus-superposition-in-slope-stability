"""Worked calculation at the 2009 event state of the Tandikat toe: r_u(slip plane) = 0.10 before shaking, kh = 0.5 x 0.28 = 0.14."""
import numpy as np, pandas as pd, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
th, ph, l, gw = np.radians(30), np.radians(39), 3.0, 9.81; gm = 1.503 * gw; gsat = (2.664 + 2.0) / 3.0 * gw
def state(m, kh, dru=0.0):
    gb = (1 - m) * gm + m * gsat; sn = gb * l * np.cos(th) ** 2; ts = gb * l * np.sin(th) * np.cos(th); u = gw * m * l * np.cos(th) ** 2
    ru = u / sn; rut = ru + dru * (1 - ru); dt = kh * gb * l * np.cos(th) ** 2; ds = -kh * gb * l * np.sin(th) * np.cos(th)
    return dict(gb=gb, sn=sn, ts=ts, u=u, ru=ru, dt=dt, ds=ds, F=(sn + ds - rut * sn) * np.tan(ph) / (ts + dt), ky=max(0.0, (np.tan(ph) * (1 - rut) - np.tan(th)) / (1 + np.tan(ph) * np.tan(th))))
m = next(x for x in np.linspace(0.14, 0.16, 20001) if state(x, 0)["ru"] >= 0.1); kh = 0.14
s, s0, sR, sE = state(m, kh), state(0, 0), state(m, 0), state(0, kh); F0, FR, FE, FRE = s0["F"], sR["F"], sE["F"], s["F"]; t = np.tan(th); ru = s["ru"]
rows = [("Moist; saturated unit weight", "γm = ρg; γsat = (Gs + e)γw/(1 + e)", f"{gm:.2f}; {gsat:.2f} kN/m³"),
        ("Water-table ratio giving r̃u = 0.10", "m = r̃u γ̄/γw", f"{m:.3f}"), ("Column unit weight", "γ̄ = (1 − m)γm + mγsat", f"{s['gb']:.2f} kN/m³"),
        ("Normal stress on slip plane", "σn = γ̄ l cos²θ", f"{s['sn']:.2f} kPa"), ("Static shear stress", "τ = γ̄ l sinθ cosθ", f"{s['ts']:.2f} kPa"),
        ("Pore pressure", "u = γw m l cos²θ", f"{s['u']:.2f} kPa"), ("Pore-pressure ratio on slip plane", "r̃u = u/σn", f"{ru:.3f}"),
        ("Seismic coefficient", "kh = 0.5 × PGA = 0.5 × 0.28", "0.14"), ("Seismic shear increment", "Δτ = kh γ̄ l cos²θ", f"{s['dt']:.2f} kPa"),
        ("Seismic normal-stress reduction", "Δσ = −kh γ̄ l sinθ cosθ", f"{s['ds']:.2f} kPa"), ("Dry, static", "F0 = tanφ′/tanθ", f"{F0:.3f}"),
        ("Rainfall only", "FR = F0(1 − r̃u)", f"{FR:.3f}"), ("Shaking only", "FE: Eq. (4) with r̃u = 0", f"{FE:.3f}"),
        ("Rainfall + shaking", "FRE = (σn + Δσ − u)tanφ′/(τ + Δτ)", f"{FRE:.3f}"), ("No-interaction estimate", "Fnull = FR FE/F0", f"{FR * FE / F0:.3f}"),
        ("Interaction index, direct; closed form", "Eq. (5); Eq. (6)", f"{FRE * F0 / (FR * FE):.4f}; {1 - ru * kh * t / ((1 - ru) * (1 - kh * t)):.4f}"),
        ("Share of combined loss due to interaction", "(Fnull − FRE)/(F0 − FRE)", f"{(FR * FE / F0 - FRE) / (F0 - FRE) * 100:.1f} %"),
        ("Yield coefficient, dry → wet", "Eq. (8)", f"{s0['ky']:.3f} → {sR['ky']:.3f}"),
        ("Yield coefficient, wet + cyclic Δr̃u = 0.1; 0.2", "Eq. (8) with r̃u + Δr̃u(1 − r̃u)", f"{state(m, 0, .1)['ky']:.3f}; {state(m, 0, .2)['ky']:.3f}")]
pd.DataFrame(rows, columns=["step", "expression", "value"]).to_csv("T5b_worked_calculation_event_state.csv", index=False)
for r in rows: print(r)
