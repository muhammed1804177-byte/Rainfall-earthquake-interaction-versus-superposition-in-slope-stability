"""Tandikat case tied to the 2009 ground motion (Faris & Fawu 2014, Fig. 29) and a rigid-block time-history check.
Site inputs read from Faris & Fawu (2014): pre-shock pore-pressure ratio at the toe ~0.10 (groundwater model),
peak horizontal acceleration at the toe ~0.28 g (0.6 g mid-slope, ~0.9 g crest, amplified, ABAQUS 2D);
cyclic pore pressure rose from ~0.1 to 1.0 between ~15 and ~19 s at the toe.
Pseudo-static kh = 0.5 PGA (Hynes-Griffin & Franklin 1984)."""
import os, numpy as np, pandas as pd
os.chdir(os.path.dirname(os.path.abspath(__file__)))
th, ph = np.radians(30), np.radians(39); T, P = np.tan(th), np.tan(ph); g = 9.81
def F(ru, kh): return P * (1 - ru - kh * T) / (T + kh)
def ky(ru): return max(0.0, (P * (1 - ru) - T) / (1 + P * T))
F0 = F(0, 0)
# ---- T8 sensitivity grid around the event state
rus = [0, .05, .10, .15, .20]; khs = [.10, .12, .14, .16, .20]
G = pd.DataFrame([dict(ru_slip_plane=r, kh=k, F_R=F(r, 0), F_E=F(0, k), F_RE=F(r, k), F_no_interaction=F(r, 0) * F(0, k) / F0,
                       I=F(r, k) * F0 / (F(r, 0) * F(0, k)), fails_alone=bool(F(r, 0) < 1 or F(0, k) < 1), fails_combined=bool(F(r, k) < 1)) for r in rus for k in khs]).round(4)
G.to_csv("T8_sensitivity_ru_kh_event.csv", index=False)
# ---- stochastic ground motions (Kanai-Tajimi filtered white noise, Saragoni-Hart envelope), scaled to PGA
dt, dur = 0.01, 40.0; t = np.arange(0, dur, dt); n = len(t)
def motion(seed, pga, wg=4 * np.pi, zg=0.6):
    r = np.random.default_rng(seed); w = r.standard_normal(n)
    f = np.fft.rfftfreq(n, dt) * 2 * np.pi; H = (wg ** 2 + 2j * zg * wg * f) / (wg ** 2 - f ** 2 + 2j * zg * wg * f)
    a = np.fft.irfft(np.fft.rfft(w) * H, n)
    tn = t / 20.0; env = (tn ** 2.0) * np.exp(-2.0 * (tn - 1)) ; env /= env.max()          # peak of envelope ~20 s
    a = a * env; return a / np.abs(a).max() * pga
def newmark(a_g, ky_t):
    """rigid block, downslope sliding only; a_g and ky_t in g; returns displacement in cm (inf if ky reaches 0 while sliding)."""
    v = d = 0.0
    for i in range(n):
        k = ky_t[i] if np.ndim(ky_t) else ky_t
        if k <= 1e-6: return np.inf
        acc = (a_g[i] - k) * g if (v > 0 or a_g[i] > k) else 0.0
        v = max(0.0, v + acc * dt); d += v * dt
    return d * 100
def jibson(k, a): r = k / a; return 10 ** (0.215 + np.log10((1 - r) ** 2.341 * r ** -1.438)) if 0 < r < 1 else (0.0 if r >= 1 else np.inf)
pga = 0.28; M = [motion(s, pga) for s in range(50)]
ru_t = np.where(t < 15, 0.10, np.where(t > 19, 1.0, 0.10 + (t - 15) / 4 * 0.9))       # cyclic pore-pressure path at the toe
cases = [("dry slope", 0.0, None), ("rain-wetted, r_u = 0.10 (pre-shock state)", 0.10, None), ("hypothetical wetter state, r_u = 0.20", 0.20, None),
         ("rain-wetted + cyclic pore pressure (r_u 0.10 -> 1.0)", 0.10, ru_t)]
rows = []
for nm, ru, path in cases:
    kt = np.array([ky(x) for x in path]) if path is not None else ky(ru)
    D = np.array([newmark(m, kt) for m in M])
    rows.append(dict(case=nm, k_y_initial=ky(ru), F_static=F(ru, 0), F_pseudo_static_kh_0_14=F(ru, 0.14),
                     D_time_history_median_cm=np.median(D), D_16pct_cm=np.percentile(D, 16), D_84pct_cm=np.percentile(D, 84),
                     pct_runaway=np.isinf(D).mean() * 100, D_Jibson2007_cm=jibson(ky(ru), pga) if path is None else np.inf))
R = pd.DataFrame(rows).round(3); R.to_csv("T9_time_history_newmark_event.csv", index=False)
np.save("motions_pga028.npy", np.array(M[:3]))
# ---- population check with Bishop k_y (120 slopes x r_u) at PGA 0.3 g: time history vs Jibson
C4 = pd.read_csv("../calibrated_equation/C4_yield_coefficient_equation_vs_Bishop.csv"); M3 = [motion(100 + s, 0.30) for s in range(20)]
out = []
for _, r in C4.iterrows():
    k = r.ky_bishop
    if k <= 0: out.append((r.ru, np.inf, np.inf)); continue
    Dth = np.median([newmark(m, k) for m in M3]); out.append((r.ru, Dth, jibson(k, .30)))
O = pd.DataFrame(out, columns=["ru", "D_time_history_cm", "D_Jibson_cm"])
S = O.groupby("ru").agg(n=("ru", "size"), pct_fail_or_gt5cm_TH=("D_time_history_cm", lambda x: (x > 5).mean() * 100),
                        pct_fail_or_gt5cm_Jibson=("D_Jibson_cm", lambda x: (x > 5).mean() * 100),
                        median_D_TH=("D_time_history_cm", "median"), median_D_Jibson=("D_Jibson_cm", "median")).round(2)
fin = O[np.isfinite(O.D_time_history_cm) & (O.D_time_history_cm > 0.1) & (O.D_Jibson_cm > 0.1)]
S.to_csv("T10_population_time_history_vs_Jibson.csv")
print(G[G.kh == .14].to_string()); print(R.to_string()); print(S.to_string())
print("log10 corr TH vs Jibson:", np.corrcoef(np.log10(fin.D_time_history_cm), np.log10(fin.D_Jibson_cm))[0, 1].round(3), len(fin))
