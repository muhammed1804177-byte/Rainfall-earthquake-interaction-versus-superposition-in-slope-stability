"""Step-by-step worked calculation for the Tandikat case (closed-form pseudo-static infinite slope).
F = tan(phi') (1 - r_u - kh tan(theta)) / (tan(theta) + kh)  with r_u = u / (gbar l cos^2 theta)  (c' = 0).
Cyclic excess pore pressure: r_u,total = r_u + d_ru (1 - r_u)  (fraction d_ru of the remaining effective stress)."""
import numpy as np, pandas as pd, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
th, ph, l, gw, Gs, e, rho = np.radians(30), np.radians(39), 3.0, 9.81, 2.664, 2.0, 1.503
gm = rho * gw; gsat = (Gs + e) / (1 + e) * gw
def state(m, kh, dru=0.0):
    gb = (1 - m) * gm + m * gsat; sn = gb * l * np.cos(th) ** 2; ts = gb * l * np.sin(th) * np.cos(th)
    u = gw * m * l * np.cos(th) ** 2; ru = u / sn; rut = ru + dru * (1 - ru)
    dtau = kh * gb * l * np.cos(th) ** 2; dsig = -kh * gb * l * np.sin(th) * np.cos(th)
    F = (sn + dsig - rut * sn) * np.tan(ph) / (ts + dtau)
    ky = max(0.0, (np.tan(ph) * (1 - rut) - np.tan(th)) / (1 + np.tan(ph) * np.tan(th)))
    return dict(m=m, kh=kh, cyclic_dru=dru, gamma_bar=gb, sigma_n=sn, tau_static=ts, u=u, r_u=ru, r_u_total=rut, d_tau_seismic=dtau, d_sigma_seismic=dsig, FoS=F, k_y=ky)
steps = [("Moist unit weight", "gamma_m = rho g", gm, "kN/m3"), ("Saturated unit weight", "gamma_sat = (Gs + e)/(1 + e) gamma_w", gsat, "kN/m3")]
s = state(0.3, 0.05)
steps += [("Column unit weight (m = 0.3)", "gamma_bar = (1 - m) gamma_m + m gamma_sat", s["gamma_bar"], "kN/m3"),
          ("Normal stress on slip plane", "sigma_n = gamma_bar l cos^2(theta)", s["sigma_n"], "kPa"),
          ("Static shear stress", "tau = gamma_bar l sin(theta) cos(theta)", s["tau_static"], "kPa"),
          ("Pore pressure (perched water)", "u = gamma_w m l cos^2(theta)", s["u"], "kPa"),
          ("Pore-pressure ratio", "r_u = u / sigma_n", s["r_u"], "-"),
          ("Seismic shear increment (kh = 0.05)", "d_tau = kh gamma_bar l cos^2(theta)", s["d_tau_seismic"], "kPa"),
          ("Seismic normal decrement", "d_sigma = -kh gamma_bar l sin(theta) cos(theta)", s["d_sigma_seismic"], "kPa"),
          ("Factor of safety, dry static", "F0 = tan(phi')/tan(theta)", state(0, 0)["FoS"], "-"),
          ("Factor of safety, rain only (m = 0.3)", "F_R", state(.3, 0)["FoS"], "-"),
          ("Factor of safety, shaking only (kh = 0.05)", "F_E", state(0, .05)["FoS"], "-"),
          ("Factor of safety, rain + shaking", "F_RE = (sigma_n + d_sigma - u) tan(phi') / (tau + d_tau)", s["FoS"], "-")]
F0, FR, FE, FRE = state(0, 0)["FoS"], state(.3, 0)["FoS"], state(0, .05)["FoS"], s["FoS"]
I = FRE * F0 / (FR * FE); ru = s["r_u"]; t = np.tan(th)
steps += [("Interaction index (direct)", "I = F_RE F0 / (F_R F_E)", I, "-"),
          ("Interaction index (closed form)", "I = 1 - r_u kh tan(theta) / ((1 - r_u)(1 - kh tan(theta)))", 1 - ru * .05 * t / ((1 - ru) * (1 - .05 * t)), "-"),
          ("Additive loss expectation", "[(F0 - F_R) + (F0 - F_E)] / F0", ((F0 - FR) + (F0 - FE)) / F0 * 100, "%"),
          ("Actual combined loss", "(F0 - F_RE) / F0", (F0 - FRE) / F0 * 100, "%"),
          ("Critical r_u (static failure)", "r_u* = 1 - tan(theta)/tan(phi')", 1 - t / np.tan(ph), "-"),
          ("Yield coefficient, dry", "k_y = [tan(phi')(1 - r_u) - tan(theta)] / (1 + tan(phi') tan(theta))", state(0, 0)["k_y"], "-"),
          ("Yield coefficient, m = 0.3", "same, r_u = 0.198", state(.3, 0)["k_y"], "-"),
          ("Yield coefficient, m = 0.3 + cyclic d_ru = 0.1", "r_u,total = r_u + d_ru (1 - r_u)", state(.3, 0, .1)["k_y"], "-")]
mc = [m for m in np.linspace(0, 1, 100001) if state(m, 0)["FoS"] < 1][0]
steps += [("Critical water-table ratio (rain alone)", "F_R(m*) = 1", mc, "-")]
W = pd.DataFrame(steps, columns=["step", "equation", "value", "unit"]); W["value"] = W.value.round(4); W.to_csv("T5_worked_calculation.csv", index=False)
G = pd.DataFrame([state(m, k, d) for m in (0, .1, .2, .3, .4) for k in (0, .05, .1, .15) for d in (0, .1, .2)]).round(4); G.to_csv("T6_full_state_grid.csv", index=False)
C = pd.DataFrame([dict(m=m, cyclic_dru=d, k_y=state(m, 0, d)["k_y"]) for m in (0, .1, .2, .3, .4) for d in (0, .1, .2, .3)]).round(4); C.to_csv("T4_yield_with_cyclic_pore_pressure.csv", index=False)
def jib(ky, a): r = ky / a; return float(10 ** (0.215 + np.log10((1 - r) ** 2.341 * r ** -1.438))) if 0 < r < 1 else (np.inf if ky == 0 else 0.0)
N = pd.DataFrame([dict(m=m, k_y=state(m, 0)["k_y"], a_max_g=a, D_N_cm=jib(state(m, 0)["k_y"], a)) for m in (0, .2, .3) for a in (.1, .2, .3, .4)]).round(3); N.to_csv("T7_Newmark_Jibson2007.csv", index=False)
print(W.to_string()); print(N.to_string())
