"""Compare FE-SRM with pseudo-static Bishop and the calibrated equation; FE interaction index and failure decomposition."""
import os, json, numpy as np, pandas as pd
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/fe_results/"
D = pd.read_csv(OUT + "FE1_fe_vs_bishop_runs.csv"); D["FE_converged"] = D.FoS_FE.notna()   # NaN = no convergence even at SRF 0.5, i.e. FoS < 0.5 (failure)
p = json.load(open(ROOT + "/calibrated_equation/C2_calibrated_parameters.json"))["lambda-dependent a,b,c"]
lam = D.c / (D.gamma * D.H * np.tan(np.radians(D.phi))); tb = np.tan(np.radians(D.beta))
a = p[0] / (1 + p[1] * lam); b = p[2] / (1 + p[3] * lam); c = p[4] * (1 + p[5] * lam)
F0fe = D.set_index(["slope", "ru", "kh"]).FoS_FE.xs((0.0, 0.0), level=["ru", "kh"])
D["F0_FE"] = D.slope.map(F0fe)
D["FoS_eq_from_FE_F0"] = D.F0_FE * np.clip(1 - a * D.ru - b * D.kh * tb, 1e-3, None) / (1 + c * D.kh / tb)
def st(y, x, sub):
    sub = sub & y.notna() & x.notna(); y, x = y[sub], x[sub]; e = x / y - 1
    return dict(n=int(sub.sum()), R2=1 - ((y - x) ** 2).sum() / ((y - y.mean()) ** 2).sum(), MAPE_pct=np.abs(e).mean() * 100, bias_pct=np.median(e) * 100,
                class_agreement_pct=((y < 1) == (x < 1)).mean() * 100)
allc = D.ru.notna(); loaded = (D.ru > 0) | (D.kh > 0); poreonly = (D.ru > 0) & (D.kh == 0)
rows = [dict(comparison="Bishop vs FE, all cells", **st(D.FoS_FE, D.FoS_Bishop, allc)),
        dict(comparison="Bishop vs FE, pore pressure only", **st(D.FoS_FE, D.FoS_Bishop, poreonly)),
        dict(comparison="Calibrated equation (F0 from FE) vs FE, loaded cells", **st(D.FoS_FE, D.FoS_eq_from_FE_F0, loaded)),
        dict(comparison="Calibrated equation vs FE, pore pressure only", **st(D.FoS_FE, D.FoS_eq_from_FE_F0, poreonly)),
        dict(comparison="Calibrated equation vs FE, combined loading", **st(D.FoS_FE, D.FoS_eq_from_FE_F0, (D.ru > 0) & (D.kh > 0)))]
T = pd.DataFrame(rows).round(4); T.to_csv(OUT + "FE2_comparison.csv", index=False); print(T.to_string())
# FE interaction index and decomposition
P = D.pivot_table(index="slope", columns=["ru", "kh"], values="FoS_FE", dropna=False).fillna(0.49); PB = D.pivot_table(index="slope", columns=["ru", "kh"], values="FoS_Bishop")
out = []
for ru in (0.2, 0.4):
    for kh in (0.1, 0.2):
        for nm, Q in (("FE", P), ("Bishop", PB)):
            F0, FR, FE_, FRE = Q[(0.0, 0.0)], Q[(ru, 0.0)], Q[(0.0, kh)], Q[(ru, kh)]; I = FRE * F0 / (FR * FE_); null = FR * FE_ / F0
            out.append(dict(method=nm, ru=ru, kh=kh, median_I=I.median(), pct_I_lt_1=(I < 1).mean() * 100, interaction_share_of_loss_pct=np.median(((null - FRE) / (F0 - FRE) * 100)[FRE > 0.49]),
                            pct_fail_combined=(FRE < 1).mean() * 100, pct_compound_only=((FRE < 1) & (FR >= 1) & (FE_ >= 1)).mean() * 100, pct_by_interaction=((FRE < 1) & (null >= 1)).mean() * 100))
I = pd.DataFrame(out).round(4); I.to_csv(OUT + "FE4_interaction_FE_vs_Bishop.csv", index=False); print(I.to_string())
