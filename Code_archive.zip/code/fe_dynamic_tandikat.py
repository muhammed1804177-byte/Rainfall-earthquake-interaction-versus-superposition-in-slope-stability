"""Dynamic FE runs of the Tandikat slope for the paper and Video S1.
1. Elastic run (event state) to measure the toe amplification; the base motion is then scaled so that the elastic
   toe-surface PGA equals 0.28 g, the value of Faris & Fawu (2014) used in the rigid-block analysis.
2. Quasi-static ramp of a uniform horizontal acceleration (0 -> 0.25 g in 25 s) to find the dynamic-model yield
   coefficient for the dry and event states (cross-check with the strength-reduction critical k_h).
3. Time histories with the median motion (seed 19) for: dry; rain-wetted (m 0.151); wetted + prescribed excess pore
   pressure (r_u 0.10 -> 1.0 at 15-19 s)."""
import sys, os, time, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fe_dynamic import Dyn
OUT = "/mnt/user-data/outputs/"; V = OUT + "video/data/"; FE = OUT + "fe_results/"
D = pd.read_csv(V + "newmark_series.csv"); acc = D.a_g.values; ru_cyc = D.ru_cyclic.values; dt_in = 0.01
d0 = Dyn(m=0.151); C = d0.L.coords; ys = d0.L.ys
def surf(x):  # surface node nearest to x
    on = np.where(np.isclose(C[:, 1], ys(C[:, 0])))[0]; return on[np.argmin(np.abs(C[on, 0] - x))]
REC = [surf(3.0), surf(d0.L.L / 2), surf(d0.L.L - 3.0)]   # toe, mid-slope, crest of the slope face
t0 = time.time()
case = sys.argv[1]
if case == "elastic":
    r = d0.run(acc, dt_in, elastic=True, rec=REC, relax=1.0)
    pga = np.abs(r["rec_a"]).max(0); np.save(V + "dyn_elastic_pga.npy", np.r_[np.abs(acc).max(), pga])
    print("elastic: base PGA %.3f g; surface PGA toe %.3f, mid %.3f, crest %.3f g" % (np.abs(acc).max(), *pga), round(time.time() - t0), "s")
elif case == "ramp":
    rows = []
    for m in (0.0, 0.151):
        d = Dyn(m=m); ramp = np.linspace(0, 0.25, 2501)
        r = d.run(ramp, dt_in, rec=REC, relax=2.0, zeta=0.0, umax=0.5)
        ux = -r["rec_u"][:, 1]; kk = r["rec_ag"]; lin = kk < 0.05                # elastic trend fitted on k < 0.05
        b = np.polyfit(kk[lin], ux[lin], 1); dev = ux - np.polyval(b, kk); i = np.argmax(dev > 0.01)   # 1 cm beyond the elastic trend
        np.savez_compressed(V + f"dyn_ramp_{m}.npz", k=kk[::25], ux=ux[::25], dev=dev[::25])
        rows.append(dict(m=m, kh_at_1cm_plastic=kk[i] if dev.max() > 0.01 else np.nan)); print(m, "kh at 1 cm plastic:", round(kk[i], 4), round(time.time() - t0), "s", flush=True)
    pd.DataFrame(rows).to_csv(FE + "FE5_dynamic_quasistatic_ky.csv", index=False)
else:
    sc = 0.28 / np.load(V + "dyn_elastic_pga.npy")[1]
    m, ru = {"dry": (0.0, None), "wet": (0.151, None), "cyclic": (0.151, ru_cyc)}[case]
    d = Dyn(m=m); r = d.run(acc, dt_in, scale=sc, ru_path=ru, rec=REC, umax=1.0)
    np.savez_compressed(V + f"dyn_{case}.npz", t=r["t"], u=r["u"], ep=r["ep"], a_g=r["a_g"], rec_t=r["rec_t"][::10], rec_a=r["rec_a"][::10], rec_u=r["rec_u"][::10],
                        rec_ag=r["rec_ag"][::10], stopped=-1 if r["stopped"] is None else r["stopped"], scale=sc, rec=np.array(REC))
    # permanent downslope displacement of the slope face (mid-slope), relative to the base
    ux, uy = r["rec_u"][-1] if r["stopped"] is None else r["rec_u"][-1], None
    print(case, "scale %.3f" % sc, "stopped", r["stopped"], "final ux (toe, mid, crest) m:", np.round(r["rec_u"][-1], 4), round(time.time() - t0), "s")
