"""Independent FE-SRM check of the Bishop factorial and the calibrated equation (16 slopes x 9 loading cells)."""
import os, sys, time, numpy as np, pandas as pd
from joblib import Parallel, delayed
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fe_srm import Model
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/fe_results/"
R = pd.read_csv(ROOT + "/calibrated_equation/bishop_factorial_runs.csv")
S = R[(R.ru == 0) & (R.kh == 0) & (R.FoS > 1.0) & (R.FoS < 3.0)].copy()
S = S.sort_values("FoS").iloc[np.linspace(0, len(S) - 1, 16).astype(int)]          # spread over static FoS 1-3
cells = [(ru, kh) for ru in (0.0, 0.2, 0.4) for kh in (0.0, 0.1, 0.2)]
def run(r):
    f = OUT + f"fe_slope_{int(r.slope)}.csv"
    if os.path.exists(f): return pd.read_csv(f)
    t = time.time(); m = Model(r.H, r.beta, r.gamma); rows = []
    for ru, kh in cells:
        rows.append(dict(slope=int(r.slope), H=r.H, beta=r.beta, c=r.c, phi=r.phi, gamma=r.gamma, ru=ru, kh=kh, FoS_FE=m.fos(r.c, r.phi, ru, kh)))
    d = pd.DataFrame(rows); d.to_csv(f, index=False); print("slope", int(r.slope), round(time.time() - t), "s", flush=True); return d
D = pd.concat(Parallel(n_jobs=1)(delayed(run)(r) for _, r in S.iterrows()))
D = D.merge(R[["slope", "ru", "kh", "FoS"]].rename(columns={"FoS": "FoS_Bishop"}), on=["slope", "ru", "kh"])
D.to_csv(OUT + "FE1_fe_vs_bishop_runs.csv", index=False); print("DONE", len(D))
