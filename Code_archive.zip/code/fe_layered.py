"""FE-SRM model of the Tandikat slope: a surface-parallel pumice layer (thickness t) over stiff sandy clay, perched
water table of height m*t above the clay (slope-parallel seepage), pseudo-static k_h. Same element, integration and
viscoplastic Mohr-Coulomb algorithm as fe_srm.py; materials and pore pressure vary by Gauss point.
Strength reduction is applied to both layers (standard SRM); the clay is strong, so failure develops in the pumice."""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from fe_srm import shape, mc_f, mc_dq

def mesh(Hs, theta, t, ncol=(14, 60, 14), nclay=8, npum=6, left=0.4, right=0.4, depth=0.35):
    L = Hs / np.tan(np.radians(theta)); D = depth * Hs
    xs = np.concatenate([np.linspace(-left * Hs, 0, 2 * ncol[0] + 1)[:-1], np.linspace(0, L, 2 * ncol[1] + 1)[:-1], np.linspace(L, L + right * Hs, 2 * ncol[2] + 1)])
    ys = lambda x: np.where(x <= 0, 0.0, np.where(x >= L, Hs, x * np.tan(np.radians(theta))))
    NX = len(xs); NYc, NYp = 2 * nclay, 2 * npum; NY = NYc + NYp + 1
    lev = np.array([0, .04, .08, .12, .17, .23, .32, .45, .62, .8, 1.0])[:npum + 1] if npum == 10 else np.linspace(0, 1, npum + 1)
    fr = np.zeros(NYp + 1); fr[0::2] = lev; fr[1::2] = (lev[:-1] + lev[1:]) / 2              # graded towards the clay interface
    idx = -np.ones((NX, NY), int); coords = []
    for i in range(NX):
        top = ys(xs[i]); base = top - t
        for j in range(NY):
            if i % 2 == 1 and j % 2 == 1: continue
            y = -D + (base + D) * j / NYc if j <= NYc else base + t * fr[j - NYc]
            idx[i, j] = len(coords); coords.append((xs[i], y))
    coords = np.array(coords); els, lay = [], []
    for ie in range(0, NX - 1, 2):
        for je in range(0, NY - 1, 2):
            els.append([idx[ie, je], idx[ie + 1, je], idx[ie + 2, je], idx[ie + 2, je + 1], idx[ie + 2, je + 2], idx[ie + 1, je + 2], idx[ie, je + 2], idx[ie, je + 1]])
            lay.append(je >= NYc)
    return coords, np.array(els), np.array(lay), ys, D, xs.min(), xs.max(), L

class Layered:
    def __init__(s, Hs=60.0, theta=30.0, t=3.0, pumice=(0.0, 39.0, 14.74, 15.25), clay=(150.0, 35.0, 20.0), E=(2e4, 1e5), nu=0.3, **mk):
        s.coords, s.els, s.lay, s.ys, s.D, xmin, xmax, s.L = mesh(Hs, theta, t, **mk); s.t, s.theta, s.nu = t, theta, nu
        s.pum, s.clay = pumice, clay; ne = len(s.els); nn = len(s.coords); s.ndof = 2 * nn
        g = 1 / np.sqrt(3); gp = [(-g, -g), (g, -g), (g, g), (-g, g)]
        def Dmat(Em):
            lam = Em * nu / ((1 + nu) * (1 - 2 * nu)); mu = Em / (2 * (1 + nu))
            return np.array([[lam + 2 * mu, lam, 0, lam], [lam, lam + 2 * mu, 0, lam], [0, 0, mu, 0], [lam, lam, 0, lam + 2 * mu]])
        s.Dp, s.Dc = Dmat(E[0]), Dmat(E[1]); s.Emin = min(E)
        s.B = np.zeros((ne, 4, 4, 16)); s.W = np.zeros((ne, 4)); s.Nmat = np.zeros((ne, 4, 8)); s.xg = np.zeros((ne, 4, 2)); s.edof = np.zeros((ne, 16), int)
        rows, cols, vals = [], [], []
        for e, con in enumerate(s.els):
            X = s.coords[con]; s.edof[e, 0::2] = 2 * con; s.edof[e, 1::2] = 2 * con + 1; Ke = np.zeros((16, 16)); Dm = s.Dp if s.lay[e] else s.Dc
            for q, (xi, eta) in enumerate(gp):
                N, dN = shape(xi, eta); J = dN @ X; dJ = np.linalg.det(J); dX = np.linalg.solve(J, dN)
                B = np.zeros((4, 16)); B[0, 0::2] = dX[0]; B[1, 1::2] = dX[1]; B[2, 0::2] = dX[1]; B[2, 1::2] = dX[0]
                s.B[e, q] = B; s.W[e, q] = dJ; s.Nmat[e, q] = N; s.xg[e, q] = N @ X; Ke += B.T @ Dm @ B * dJ
            rr, cc = np.meshgrid(s.edof[e], s.edof[e], indexing="ij"); rows.append(rr.ravel()); cols.append(cc.ravel()); vals.append(Ke.ravel())
        K = coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(s.ndof, s.ndof)).tocsc()
        fix = np.zeros(s.ndof, bool); x, y = s.coords[:, 0], s.coords[:, 1]
        fix[2 * np.where(np.isclose(x, xmin) | np.isclose(x, xmax))[0]] = True; b = np.where(np.isclose(y, -s.D))[0]; fix[2 * b] = True; fix[2 * b + 1] = True
        s.free = np.where(~fix)[0]; s.lu = splu(K[s.free][:, s.free].tocsc())
        s.Dg = np.where(s.lay[:, None, None, None], s.Dp[None, None], s.Dc[None, None])   # (ne,1,4,4) broadcast per element
    def loads(s, m, kh, gw=9.81):
        """m = perched water-table ratio (height m*t above the clay); slope-parallel seepage."""
        f = np.zeros(s.ndof); mv = np.array([1., 1., 0., 1.])
        cpum, ppum, gm, gs = s.pum; xg, yg = s.xg[..., 0], s.xg[..., 1]
        zb = yg - (s.ys(xg) - s.t)                                         # vertical height above the clay surface
        sat = s.lay[:, None] & (zb < m * s.t)
        gam = np.where(s.lay[:, None], np.where(sat, gs, gm), s.clay[2])
        cos2 = np.where((xg > 0) & (xg < s.L), np.cos(np.radians(s.theta)) ** 2, 1.0)
        u = np.where(sat, gw * (m * s.t - zb) * cos2, 0.0)
        for q in range(4):
            Nw = s.Nmat[:, q, :] * s.W[:, q][:, None]
            np.add.at(f, s.edof[:, 0::2], Nw * (-kh * gam[:, q])[:, None]); np.add.at(f, s.edof[:, 1::2], Nw * (-gam[:, q])[:, None])
            fe = np.einsum("eij,j->ei", np.transpose(s.B[:, q], (0, 2, 1)), mv) * (u[:, q] * s.W[:, q])[:, None]
            np.add.at(f, s.edof, fe)
        return f
    def solve(s, m, kh, srf, itmax=600, tol=1e-4):
        c = np.where(s.lay, s.pum[0], s.clay[0]) / srf; ph = np.arctan(np.tan(np.radians(np.where(s.lay, s.pum[1], s.clay[1]))) / srf)
        cE, sE = (c * np.cos(ph))[:, None], np.sin(ph)[:, None]
        dt = 4 * (1 + s.nu) * (1 - 2 * s.nu) / (1e5 * (1 - 2 * s.nu + np.sin(ph).max() ** 2))   # stable step for the stiffest material (E = 1e5 kPa)
        f0 = s.loads(m, kh); evp = np.zeros((len(s.els), 4, 4)); bl = np.zeros(s.ndof); u = np.zeros(s.ndof); uold = np.zeros(s.ndof)
        for it in range(itmax):
            u[:] = 0; u[s.free] = s.lu.solve((f0 + bl)[s.free]); ue = u[s.edof]
            eps = np.einsum("eqij,ej->eqi", s.B, ue); sig = np.einsum("eqij,eqj->eqi", np.broadcast_to(s.Dg, (len(s.els), 4, 4, 4)), eps - evp)
            F = mc_f(sig, np.broadcast_to(sE, sig.shape[:2]), np.broadcast_to(cE, sig.shape[:2])); pl = F > 0
            if pl.any():
                dq = mc_dq(sig[pl]); de = np.zeros_like(evp); de[pl] = dt * F[pl][:, None] * dq; evp += de
                dsig = np.einsum("eqij,eqj->eqi", np.broadcast_to(s.Dg, (len(s.els), 4, 4, 4)), de)
                fe = np.einsum("eqji,eqj,eq->ei", s.B, dsig, s.W); np.add.at(bl, s.edof, fe)
            if it > 0 and np.max(np.abs(u - uold)) / max(np.max(np.abs(u)), 1e-12) < tol:
                s.evp, s.its = evp, it; return True, it, u
            uold = u.copy()
        s.evp, s.its = evp, itmax; return False, itmax, u
    def fos(s, m=0.0, kh=0.0, n=7, grid=(0.5, 0.7, 0.85, 1.0, 1.15, 1.3, 1.5, 1.8, 2.2, 2.8)):
        """Same search as fe_srm.Model.fos."""
        lo = next((i for i, g in enumerate(grid) if s.solve(m, kh, g)[0]), None)
        if lo is None: return float("nan")
        hi = None
        for i in range(lo + 1, len(grid)):
            if s.solve(m, kh, grid[i])[0]: lo = i
            else: hi = i; break
        if hi is None: return grid[-1]
        a, b = grid[lo], grid[hi]
        for _ in range(n):
            mid = .5 * (a + b)
            if s.solve(m, kh, mid)[0]: a = mid
            else: b = mid
        return .5 * (a + b)

if __name__ == "__main__":
    import time, os, pandas as pd
    OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/fe_results/"
    md = Layered(); print("elements", len(md.els))
    th, ph = np.radians(30), np.radians(39); P, T = np.tan(ph), np.tan(th)
    def inf(ru, k): return P * (1 - ru - k * T) / (T + k)
    rows = []
    for nm, m, kh, ru in [("dry, static", 0.0, 0.0, 0.0), ("rainfall only (m = 0.151)", 0.151, 0.0, 0.10), ("shaking only (kh = 0.14)", 0.0, 0.14, 0.0), ("rainfall + shaking", 0.151, 0.14, 0.10)]:
        t0 = time.time(); f = md.fos(m, kh); rows.append(dict(state=nm, m=m, kh=kh, FoS_FE=f, FoS_infinite_slope=inf(ru, kh)))
        print(nm, round(f, 3), "infinite slope", round(inf(ru, kh), 3), round(time.time() - t0), "s", flush=True)
        pd.DataFrame(rows).to_csv(OUT + "FE3_Tandikat_layered.csv", index=False)
    print("DONE")
