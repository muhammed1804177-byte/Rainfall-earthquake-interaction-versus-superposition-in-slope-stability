"""Two-dimensional finite-element strength-reduction method (FE-SRM) for slopes, after Griffiths & Lane (1999).
Plane strain, 8-node serendipity quadrilaterals with 2x2 Gauss integration, elastic-viscoplastic (initial-stiffness)
algorithm with a Mohr-Coulomb yield surface and non-dilatant Mohr-Coulomb plastic potential (psi = 0).
Effective-stress analysis with pore pressure u = r_u * gamma * h (h = depth below the ground surface) and a uniform
horizontal pseudo-static body force k_h * gamma acting towards the slope face. Failure = non-convergence of the
viscoplastic iterations; the FoS is the strength reduction factor (SRF) at failure, found by bisection."""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu

def mesh(H, beta, nx=(10, 16, 14), ny=12, left=1.2, right=1.6, depth=1.0):
    Lh = H / np.tan(np.radians(beta)); D = depth * H
    xs = np.concatenate([np.linspace(-left * H, 0, 2 * nx[0] + 1)[:-1], np.linspace(0, Lh, 2 * nx[1] + 1)[:-1], np.linspace(Lh, Lh + right * H, 2 * nx[2] + 1)])
    ys_top = np.where(xs <= 0, 0.0, np.where(xs >= Lh, H, xs * np.tan(np.radians(beta))))
    NX, NY = len(xs), 2 * ny + 1
    idx = -np.ones((NX, NY), int); coords = []
    for i in range(NX):
        for j in range(NY):
            if i % 2 == 1 and j % 2 == 1: continue
            idx[i, j] = len(coords); coords.append((xs[i], -D + (ys_top[i] + D) * j / (NY - 1)))
    coords = np.array(coords); els = []
    for ie in range(0, NX - 1, 2):
        for je in range(0, NY - 1, 2):
            # corner-midside order (counter-clockwise): 1 bl, 2 bm, 3 br, 4 rm, 5 tr, 6 tm, 7 tl, 8 lm
            els.append([idx[ie, je], idx[ie + 1, je], idx[ie + 2, je], idx[ie + 2, je + 1], idx[ie + 2, je + 2], idx[ie + 1, je + 2], idx[ie, je + 2], idx[ie, je + 1]])
    return coords, np.array(els), (lambda x: np.where(x <= 0, 0.0, np.where(x >= Lh, H, x * np.tan(np.radians(beta))))), D, xs.min(), xs.max()

def shape(xi, eta):
    xn = np.array([-1, 0, 1, 1, 1, 0, -1, -1]); en = np.array([-1, -1, -1, 0, 1, 1, 1, 0])
    N = np.zeros(8); dN = np.zeros((2, 8))
    for a in range(8):
        if xn[a] == 0:
            N[a] = .5 * (1 - xi ** 2) * (1 + en[a] * eta); dN[0, a] = -xi * (1 + en[a] * eta); dN[1, a] = .5 * (1 - xi ** 2) * en[a]
        elif en[a] == 0:
            N[a] = .5 * (1 + xn[a] * xi) * (1 - eta ** 2); dN[0, a] = .5 * xn[a] * (1 - eta ** 2); dN[1, a] = -(1 + xn[a] * xi) * eta
        else:
            N[a] = .25 * (1 + xn[a] * xi) * (1 + en[a] * eta) * (xn[a] * xi + en[a] * eta - 1)
            dN[0, a] = .25 * xn[a] * (1 + en[a] * eta) * (2 * xn[a] * xi + en[a] * eta)
            dN[1, a] = .25 * en[a] * (1 + xn[a] * xi) * (xn[a] * xi + 2 * en[a] * eta)
    return N, dN


def _inv(sig):
    p = (sig[..., 0] + sig[..., 1] + sig[..., 3]) / 3; sx, sy, sz, t = sig[..., 0] - p, sig[..., 1] - p, sig[..., 3] - p, sig[..., 2]
    J2 = .5 * (sx ** 2 + sy ** 2 + sz ** 2) + t ** 2; J3 = sx * sy * sz - sz * t ** 2
    sb = np.sqrt(np.maximum(3 * J2, 1e-16)); sn = np.clip(-13.5 * J3 / sb ** 3, -1, 1); th = np.arcsin(sn) / 3
    return p, sb, th
def mc_f(sig, sphi, ccos):
    """Mohr-Coulomb yield function (tension positive), Smith & Griffiths form."""
    p, sb, th = _inv(sig); return p * sphi + sb * (np.cos(th) / np.sqrt(3) - np.sin(th) * sphi / 3) - ccos
def mc_q(sig):
    p, sb, th = _inv(sig); return sb * np.cos(th) / np.sqrt(3)          # potential with psi = 0
def mc_dq(sig, h=1e-4):
    g = np.zeros_like(sig); sc = np.maximum(np.abs(sig).max(-1, keepdims=True), 1.0) * h
    for i in range(4):
        e = np.zeros(4); e[i] = 1; d = sc[..., 0]
        g[..., i] = (mc_q(sig + d[..., None] * e) - mc_q(sig - d[..., None] * e)) / (2 * d)
    g[..., 2] *= 1.0                                                     # engineering shear: dQ/dtau pairs with gamma
    return g

class Model:
    def __init__(s, H, beta, gamma, E=1e5, nu=0.3, surface="MC", **mk):
        s.surface = surface
        s.coords, s.els, s.ysurf, s.D, xmin, xmax = mesh(H, beta, **mk); s.gamma, s.E, s.nu = gamma, E, nu
        nn = len(s.coords); s.ndof = 2 * nn; g = 1 / np.sqrt(3); gp = [(-g, -g), (g, -g), (g, g), (-g, g)]
        lam = E * nu / ((1 + nu) * (1 - 2 * nu)); mu = E / (2 * (1 + nu))
        s.Dm = np.array([[lam + 2 * mu, lam, 0, lam], [lam, lam + 2 * mu, 0, lam], [0, 0, mu, 0], [lam, lam, 0, lam + 2 * mu]])
        ne = len(s.els); s.B = np.zeros((ne, 4, 4, 16)); s.W = np.zeros((ne, 4)); s.Nmat = np.zeros((ne, 4, 8)); s.depth = np.zeros((ne, 4))
        s.edof = np.zeros((ne, 16), int); rows, cols, vals = [], [], []
        for e, con in enumerate(s.els):
            X = s.coords[con]; s.edof[e, 0::2] = 2 * con; s.edof[e, 1::2] = 2 * con + 1; Ke = np.zeros((16, 16))
            for q, (xi, eta) in enumerate(gp):
                N, dN = shape(xi, eta); J = dN @ X; dJ = np.linalg.det(J); dX = np.linalg.solve(J, dN)
                B = np.zeros((4, 16)); B[0, 0::2] = dX[0]; B[1, 1::2] = dX[1]; B[2, 0::2] = dX[1]; B[2, 1::2] = dX[0]
                s.B[e, q] = B; s.W[e, q] = dJ; s.Nmat[e, q] = N; xg, yg = N @ X; s.depth[e, q] = max(s.ysurf(xg) - yg, 0.0)
                Ke += B.T @ s.Dm @ B * dJ
            rr, cc = np.meshgrid(s.edof[e], s.edof[e], indexing="ij"); rows.append(rr.ravel()); cols.append(cc.ravel()); vals.append(Ke.ravel())
        K = coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(s.ndof, s.ndof)).tocsc()
        fix = np.zeros(s.ndof, bool); x, y = s.coords[:, 0], s.coords[:, 1]
        fix[2 * np.where(np.isclose(x, xmin) | np.isclose(x, xmax))[0]] = True; b = np.where(np.isclose(y, -s.D))[0]; fix[2 * b] = True; fix[2 * b + 1] = True
        s.free = np.where(~fix)[0]; s.lu = splu(K[s.free][:, s.free].tocsc())
    def loads(s, ru, kh):
        f = np.zeros(s.ndof); m = np.array([1., 1., 0., 1.])
        bx = -kh * s.gamma; by = -s.gamma                                # body force (face of slope points to -x)
        for q in range(4):
            Nw = s.Nmat[:, q, :] * s.W[:, q][:, None]
            np.add.at(f, s.edof[:, 0::2], Nw * bx); np.add.at(f, s.edof[:, 1::2], Nw * by)
            u = ru * s.gamma * s.depth[:, q]                              # pore pressure at Gauss points
            fe = np.einsum("eij,j->ei", np.transpose(s.B[:, q], (0, 2, 1)), m) * (u * s.W[:, q])[:, None]
            np.add.at(f, s.edof, fe)                                     # + int B^T m u dV (effective-stress equilibrium)
        return f
    def solve(s, c, phi, ru=0.0, kh=0.0, srf=1.0, itmax=500, tol=1e-4):
        cf = c / srf; tphi = np.tan(np.radians(phi)) / srf; ph = np.arctan(tphi)
        al = np.tan(ph) / np.sqrt(9 + 12 * np.tan(ph) ** 2); k = 3 * cf / np.sqrt(9 + 12 * np.tan(ph) ** 2)   # plane-strain DP match
        dt = 4 * (1 + s.nu) * (1 - 2 * s.nu) / (s.E * (1 - 2 * s.nu + np.sin(ph) ** 2))
        f0 = s.loads(ru, kh); evp = np.zeros((len(s.els), 4, 4)); bl = np.zeros(s.ndof); uold = np.zeros(s.ndof); u = np.zeros(s.ndof)
        for it in range(itmax):
            rhs = f0 + bl; u[:] = 0; u[s.free] = s.lu.solve(rhs[s.free]); ue = u[s.edof]
            eps = np.einsum("eqij,ej->eqi", s.B, ue); sig = np.einsum("ij,eqj->eqi", s.Dm, eps - evp)
            if s.surface == "MC":
                F = mc_f(sig, np.sin(ph), cf * np.cos(ph)); pl = F > 0
                if pl.any():
                    dq = mc_dq(sig[pl])                                      # Mohr-Coulomb potential with psi = 0
                    de = np.zeros_like(evp); de[pl] = dt * F[pl][:, None] * dq; evp += de
                    dsig = np.einsum("ij,eqj->eqi", s.Dm, de)
                    fe = np.einsum("eqji,eqj,eq->ei", s.B, dsig, s.W); np.add.at(bl, s.edof, fe)
            else:
                p = (sig[..., 0] + sig[..., 1] + sig[..., 3]) / 3; sx, sy, sz, txy = sig[..., 0] - p, sig[..., 1] - p, sig[..., 3] - p, sig[..., 2]
                J2 = .5 * (sx ** 2 + sy ** 2 + sz ** 2) + txy ** 2; rJ = np.sqrt(np.maximum(J2, 1e-12))
                F = al * 3 * p + rJ - k; pl = F > 0
                if pl.any():
                    dq = np.stack([sx / (2 * rJ), sy / (2 * rJ), txy / rJ, sz / (2 * rJ)], -1)
                    de = np.where(pl[..., None], dt * F[..., None] * dq, 0.0); evp += de
                    dsig = np.einsum("ij,eqj->eqi", s.Dm, de)
                    fe = np.einsum("eqji,eqj,eq->ei", s.B, dsig, s.W); np.add.at(bl, s.edof, fe)
            if it > 0 and np.max(np.abs(u - uold)) / max(np.max(np.abs(u)), 1e-12) < tol:
                s.evp, s.its = evp, it; return True, it, u
            uold = u.copy()
        s.evp, s.its = evp, itmax; return False, itmax, u
    def fos(s, c, phi, ru=0.0, kh=0.0, itmax=500, n=7, grid=(0.5, 0.7, 0.9, 1.1, 1.3, 1.6, 2.0, 2.5, 3.0, 3.6, 4.4)):
        """FoS = largest strength reduction factor that converges. Very low SRF values can fail to converge for numerical
        reasons (tension near the apex of the Mohr-Coulomb cone at very high factored friction angles), so the search
        scans upwards from the first convergent SRF to the first non-convergent one and then bisects that bracket."""
        lo = None
        for i, g in enumerate(grid):
            if s.solve(c, phi, ru, kh, g, itmax)[0]: lo = i; break
        if lo is None: return float("nan")
        hi = None
        for i in range(lo + 1, len(grid)):
            if s.solve(c, phi, ru, kh, grid[i], itmax)[0]: lo = i
            else: hi = i; break
        if hi is None: return grid[-1]
        a, b = grid[lo], grid[hi]
        for _ in range(n):
            mid = .5 * (a + b)
            if s.solve(c, phi, ru, kh, mid, itmax)[0]: a = mid
            else: b = mid
        return .5 * (a + b)

if __name__ == "__main__":
    import time
    t = time.time(); m = Model(10, 26.565, 20)
    print("Griffiths & Lane (1999) example: 2:1 slope, c/(gamma H) = 0.05, phi = 20 -> FE-SRM", round(m.fos(10, 20), 3), "(published FE 1.4, Bishop 1.38)", round(time.time() - t, 1), "s")
