"""Tandikat FE-SRM sensitivity to slope length (toe buttressing): Hs = 200 m instead of 60 m."""
import os, time, numpy as np, pandas as pd
from fe_layered import Layered
OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/fe_results/"
md = Layered(Hs=200.0, ncol=(8, 90, 8), left=0.15, right=0.15, depth=0.12); print("elements", len(md.els), flush=True)
th, ph = np.radians(30), np.radians(39); P, T = np.tan(ph), np.tan(th); inf = lambda ru, k: P * (1 - ru - k * T) / (T + k)
rows = []
for nm, m, kh, ru in [("dry, static", 0.0, 0.0, 0.0), ("rainfall only (m = 0.151)", 0.151, 0.0, 0.10), ("shaking only (kh = 0.14)", 0.0, 0.14, 0.0), ("rainfall + shaking", 0.151, 0.14, 0.10)]:
    t0 = time.time(); f = md.fos(m, kh); rows.append(dict(state=nm, m=m, kh=kh, FoS_FE_Hs200=f, FoS_infinite_slope=inf(ru, kh)))
    print(nm, round(f, 3), round(inf(ru, kh), 3), round(time.time() - t0), "s", flush=True); pd.DataFrame(rows).to_csv(OUT + "FE3b_Tandikat_long_slope.csv", index=False)
print("DONE")
