"""Tandikat layered FE-SRM: final runs (uniform 0.5 m pumice rows) and a mesh-refinement check."""
import os, time, numpy as np, pandas as pd
from fe_layered import Layered
OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/fe_results/"
th, ph = np.radians(30), np.radians(39); P, T = np.tan(ph), np.tan(th); inf = lambda ru, k: P * (1 - ru - k * T) / (T + k)
rows = []
for mesh_name, kw in [("standard mesh (60 slope columns, 6 pumice rows)", dict(ncol=(14, 60, 14), npum=6)), ("refined mesh (90 slope columns, 6 pumice rows)", dict(ncol=(18, 90, 18), npum=6))]:
    md = Layered(**kw); print(mesh_name, "elements", len(md.els), flush=True)
    for nm, m, kh, ru in [("dry, static", 0.0, 0.0, 0.0), ("rainfall only", 0.151, 0.0, 0.10), ("shaking only (kh = 0.14)", 0.0, 0.14, 0.0), ("rainfall + shaking", 0.151, 0.14, 0.10), ("rainfall, m = 0.30", 0.30, 0.0, 0.198), ("rainfall m = 0.30 + shaking", 0.30, 0.14, 0.198)]:
        t0 = time.time(); f = md.fos(m, kh); rows.append(dict(mesh=mesh_name, elements=len(md.els), state=nm, m=m, kh=kh, FoS_FE=round(f, 3), FoS_infinite_slope=round(inf(ru, kh), 3)))
        print(" ", nm, round(f, 3), round(inf(ru, kh), 3), round(time.time() - t0), "s", flush=True); pd.DataFrame(rows).to_csv(OUT + "FE3_Tandikat_layered.csv", index=False)
print("DONE")
