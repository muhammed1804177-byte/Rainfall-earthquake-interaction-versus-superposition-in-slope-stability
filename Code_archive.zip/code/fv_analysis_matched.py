"""Field validation on the 2018 Hokkaido Eastern Iburi event: do the paper's yield coefficient and Newmark model
(Eqs. 8-9), driven by ShakeMap PGA and DEM slope, separate the 5,625 mapped landslides from non-landslide hillslopes,
and does a rain-wetted state (r_u > 0, after Typhoon Jebi) explain the observed failures better than a dry state?
Cohesionless tephra cover (c' = 0) is assumed; phi' is varied over 30-40 deg because it was not measured here."""
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
OUT = "/mnt/user-data/outputs/field_validation/"
H = pd.read_csv(OUT + "Iburi_matched_hillslope_points.csv"); H["slope_deg"] = H.slope_source_deg   # source-area slope, matched hillslope sample
print("hillslope points:", len(H), H.landslide.value_counts().to_dict())
def ky(beta, phi, ru):
    return np.maximum((np.tan(np.radians(phi)) * (1 - ru) - np.tan(np.radians(beta))) / (1 + np.tan(np.radians(phi)) * np.tan(np.radians(beta))), 0)
def DN(k, a):
    r = np.clip(k / a, 1e-6, None); d = 10 ** (0.215 + np.log10(np.clip((1 - r), 1e-9, None) ** 2.341 * r ** -1.438))
    return np.where(k <= 0, np.inf, np.where(r >= 1, 0.0, d))
def score(y, pred):
    tpr = pred[y == 1].mean(); fpr = pred[y == 0].mean(); return tpr, fpr, (tpr + 1 - fpr) / 2
rows = []
y = H.landslide.values; b = H.slope_deg.values; a = H.pga_g.values
for phi in (30, 33, 36, 39):
    for ru in (0, .1, .2, .3, .4, .5):
        k = ky(b, phi, ru); d = DN(k, a); s = -np.log10(np.clip(k, 1e-4, None) / a)
        for thr in (5, 15):
            tpr, fpr, ba = score(y, d > thr)
            rows.append(dict(phi=phi, ru=ru, threshold_cm=thr, TPR=tpr, FPR=fpr, balanced_acc=ba, AUROC=roc_auc_score(y, s),
                             landslides_static_fail_pct=(k[y == 1] <= 0).mean() * 100))
T = pd.DataFrame(rows).round(4); T.to_csv(OUT + "FV3_matched_dry_vs_wet_performance.csv", index=False)
print(T[T.threshold_cm == 5].pivot_table(index="ru", columns="phi", values=["TPR", "FPR", "balanced_acc"]).round(3).to_string())
# slope-only and PGA-only baselines (best threshold)
def best_thr(x, y):
    q = np.unique(np.quantile(x, np.linspace(.01, .99, 199))); best = max(((score(y, x > t)[2], t) for t in q)); return best
print("slope-only best BA %.3f at %.1f deg" % best_thr(b, y)); print("PGA-only best BA %.3f at %.3f g" % best_thr(a, y))
print("AUROC slope %.3f  PGA %.3f" % (roc_auc_score(y, b), roc_auc_score(y, a)))
# spatial cross-validation of r_u (choose on one half, test on the other), phi = 36
H["half"] = np.where(H.lon < H.lon.median(), "west", "east"); cv = []
for phi in (33, 36, 39):
    for tr, te in (("west", "east"), ("east", "west")):
        A, Bt = H[H.half == tr], H[H.half == te]; best = None
        for ru in np.round(np.arange(0, .61, .05), 2):
            ba = score(A.landslide.values, DN(ky(A.slope_deg.values, phi, ru), A.pga_g.values) > 5)[2]
            if best is None or ba > best[0]: best = (ba, ru)
        ru = best[1]; t_wet = score(Bt.landslide.values, DN(ky(Bt.slope_deg.values, phi, ru), Bt.pga_g.values) > 5)
        t_dry = score(Bt.landslide.values, DN(ky(Bt.slope_deg.values, phi, 0), Bt.pga_g.values) > 5)
        cv.append(dict(phi=phi, fit_on=tr, test_on=te, ru_selected=ru, test_TPR_wet=t_wet[0], test_FPR_wet=t_wet[1], test_BA_wet=t_wet[2], test_TPR_dry=t_dry[0], test_FPR_dry=t_dry[1], test_BA_dry=t_dry[2]))
CV = pd.DataFrame(cv).round(4); CV.to_csv(OUT + "FV4_matched_spatial_cv_ru.csv", index=False); print(CV.to_string())
# landslides explained only when wetted: dry D <= 5 cm but wet (selected r_u) D > 5 cm
for phi in (33, 36, 39):
    ru = CV[CV.phi == phi].ru_selected.mean()
    L = H[H.landslide == 1]; dd = DN(ky(L.slope_deg, phi, 0), L.pga_g) > 5; dw = DN(ky(L.slope_deg, phi, ru), L.pga_g) > 5
    print(f"phi {phi}: r_u {ru:.2f}  landslides predicted dry {dd.mean()*100:.1f}%  wet {dw.mean()*100:.1f}%  only when wet {(dw & ~dd).mean()*100:.1f}%")
