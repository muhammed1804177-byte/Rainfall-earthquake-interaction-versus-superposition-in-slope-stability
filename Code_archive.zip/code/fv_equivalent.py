"""Iburi 2018: identifiability of wetting. For a cohesionless infinite slope, k_y depends on phi' and r_u only through
tan(phi_eq) = tan(phi')(1 - r_u) (apart from the denominator), so the field data constrain an equivalent dry friction
angle phi_eq, not r_u alone. This script (i) selects phi_eq by the same west/east spatial cross-validation as r_u,
(ii) extends the r_u cross-validation to phi' = 42 and 45 deg (laboratory range of Atsuma pumice/ash), and
(iii) converts phi_eq into the slip-plane pore-pressure ratio implied by each measured friction angle."""
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
OUT = "/mnt/user-data/outputs/field_validation/"
H = pd.read_csv(OUT + "Iburi_matched_hillslope_points.csv"); H["slope_deg"] = H.slope_source_deg
H["half"] = np.where(H.lon < H.lon.median(), "west", "east")
def ky(beta, phi, ru):
    return np.maximum((np.tan(np.radians(phi)) * (1 - ru) - np.tan(np.radians(beta))) / (1 + np.tan(np.radians(phi)) * np.tan(np.radians(beta))), 0)
def DN(k, a):
    r = np.clip(k / a, 1e-6, None); d = 10 ** (0.215 + np.log10(np.clip((1 - r), 1e-9, None) ** 2.341 * r ** -1.438))
    return np.where(k <= 0, np.inf, np.where(r >= 1, 0.0, d))
def score(df, phi, ru):
    p = DN(ky(df.slope_deg.values, phi, ru), df.pga_g.values) > 5; y = df.landslide.values
    tpr, fpr = p[y == 1].mean(), p[y == 0].mean(); return tpr, fpr, (tpr + 1 - fpr) / 2
rows = []
# (i) dry model, equivalent friction angle chosen by spatial CV
for tr, te in (("west", "east"), ("east", "west")):
    A, B = H[H.half == tr], H[H.half == te]
    ph = max(np.arange(24, 46.01, 0.5), key=lambda p: score(A, p, 0)[2])
    t = score(B, ph, 0); rows.append(dict(model="dry, phi_eq selected", phi=ph, ru=0.0, fit_on=tr, test_on=te, TPR=t[0], FPR=t[1], BA=t[2]))
# (ii) r_u selected by CV for each fixed phi'
for phi in (33, 36, 39, 42, 45):
    for tr, te in (("west", "east"), ("east", "west")):
        A, B = H[H.half == tr], H[H.half == te]
        ru = max(np.round(np.arange(0, .61, .05), 2), key=lambda r: score(A, phi, r)[2])
        t = score(B, phi, ru); d = score(B, phi, 0)
        rows.append(dict(model="wet, r_u selected", phi=phi, ru=ru, fit_on=tr, test_on=te, TPR=t[0], FPR=t[1], BA=t[2], TPR_dry=d[0], FPR_dry=d[1], BA_dry=d[2]))
R = pd.DataFrame(rows).round(4); R.to_csv(OUT + "FV5_equivalent_friction_and_phi_range.csv", index=False); print(R.to_string())
peq = R[R.model.str.startswith("dry")].phi.values; print("phi_eq selected:", peq)
# (iii) implied slip-plane pore-pressure ratio for measured friction angles
imp = []
for phi in (31, 33, 36, 39, 42, 45, 48):
    r = [1 - np.tan(np.radians(p)) / np.tan(np.radians(phi)) for p in peq]
    imp.append(dict(phi_measured=phi, ru_implied_min=max(min(r), 0), ru_implied_max=max(max(r), 0)))
I = pd.DataFrame(imp).round(3); I.to_csv(OUT + "FV6_implied_pore_pressure_ratio.csv", index=False); print(I.to_string())
# whole-area summary for phi_eq and for the landslides-predicted share
for p in sorted(set(peq)): print("phi_eq %.1f whole area:" % p, np.round(score(H, p, 0), 3))
