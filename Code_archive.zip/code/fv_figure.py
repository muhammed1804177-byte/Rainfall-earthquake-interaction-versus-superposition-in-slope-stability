"""Field-validation figure for the 2018 Iburi event."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
OUT = "/mnt/user-data/outputs/"; FV = OUT + "field_validation/"
plt.rcParams.update({"font.family": "Inter", "font.size": 8.2, "axes.titleweight": "semibold", "axes.titlesize": 8.8, "axes.titlelocation": "left",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#BDB6A8", "axes.grid": True, "grid.color": "#E6E1D8", "grid.linewidth": .5, "pdf.fonttype": 42, "legend.frameon": False})
INK2 = "#555B61"; TEAL, AMBER, SLATE, TERRA, GREY = "#1F8A84", "#D99A1E", "#46525F", "#B5573B", "#C9C6BC"
P = pd.read_csv(FV + "Iburi_points_source_slope.csv"); P["slope_deg"] = P.slope_source_deg; H = pd.read_csv(FV + "Iburi_matched_hillslope_points.csv"); H["slope_deg"] = H.slope_source_deg; T = pd.read_csv(FV + "FV3_matched_dry_vs_wet_performance.csv")
from sklearn.metrics import roc_auc_score
ky = lambda b, phi, ru: np.maximum((np.tan(np.radians(phi)) * (1 - ru) - np.tan(np.radians(b))) / (1 + np.tan(np.radians(phi)) * np.tan(np.radians(b))), 0)
def DN(k, a):
    r = np.clip(k / a, 1e-6, None); d = 10 ** (0.215 + np.log10(np.clip(1 - r, 1e-9, None) ** 2.341 * r ** -1.438)); return np.where(k <= 0, np.inf, np.where(r >= 1, 0, d))
f, ax = plt.subplots(1, 4, figsize=(13.2, 3.4), gridspec_kw=dict(width_ratios=[1, 1, 1, 1.15], wspace=.34))
bins = np.arange(0, 47, 2)
ax[0].hist(P[P.landslide == 0].slope_deg, bins, density=True, color=GREY, label="non-landslide points"); ax[0].hist(P[P.landslide == 1].slope_deg, bins, density=True, color=TERRA, alpha=.75, label="landslides (5,625)")
ax[0].axvline(10, color=INK2, lw=.8, ls=":"); ax[0].text(10.5, ax[0].get_ylim()[1] * .55, "hillslope\ncut-off", fontsize=6.8, color=INK2)
ax[0].set(xlabel="Slope angle (°): landslide source area / 3×3 window", ylabel="Density", title="(a) Slope angle"); ax[0].legend(fontsize=7)
y = H.landslide.values
fpr, tpr, _ = roc_curve(y, H.slope_deg); ax[1].plot(fpr, tpr, color=GREY, lw=1.4, label=f"slope only, AUROC {roc_auc_score(y, H.slope_deg):.2f}")
fpr, tpr, _ = roc_curve(y, H.pga_g); ax[1].plot(fpr, tpr, color=SLATE, lw=1, ls="--", label=f"PGA only, AUROC {roc_auc_score(y, H.pga_g):.2f}")
d = T[(T.phi == 36) & (T.threshold_cm == 5)]
ax[1].plot(d.FPR, d.TPR, "-o", color=TEAL, ms=4, label=f"Newmark ($\\varphi'$ 36°), AUROC {d.AUROC.iloc[0]:.2f};\nlabels: $\\tilde r_u$")
for _, r in d.iterrows(): ax[1].text(r.FPR + .015, r.TPR - .035, f"{r.ru:g}", fontsize=6.5, color=TEAL)
ax[1].plot([0, 1], [0, 1], color=INK2, lw=.6, ls=":"); ax[1].set(xlabel="False-positive rate (stable hillslopes)", ylabel="True-positive rate (landslides)", title="(b) Discrimination, $D_N$ > 5 cm"); ax[1].legend(fontsize=6.5, loc="lower right", bbox_to_anchor=(1.0, 0.0))
ph = np.arange(24, 48.01, 0.5); tp = [(DN(ky(H.slope_deg.values, p, 0), H.pga_g.values) > 5)[y == 1].mean() * 100 for p in ph]; fp = [(DN(ky(H.slope_deg.values, p, 0), H.pga_g.values) > 5)[y == 0].mean() * 100 for p in ph]
ax[2].axvspan(42, 48, color="#F3E3D0", zorder=0); ax[2].text(42.4, 97, "lab. tests,\npumice/ash\n42–48°", fontsize=6.3, color=TERRA, va="top")
ax[2].axvspan(31, 33, color="#ECE7F2", zorder=0); ax[2].text(31.1, 96, "halloysite\nlayer", fontsize=6.3, color="#3F3D8F", va="top")
ax[2].axvspan(27, 31, color="#DCEFED", zorder=0); ax[2].text(27.1, 8, "selected by\nspatial CV", fontsize=6.5, color="#16615D")
ax[2].plot(ph, tp, "-", color=TEAL, lw=1.6, label="landslides predicted"); ax[2].plot(ph, fp, "--", color=SLATE, lw=1.1, label="stable hillslopes predicted")
ax[2].set(xlabel="Equivalent friction angle $\\varphi_{eq}$ (°), tan$\\varphi_{eq}$ = tan$\\varphi'$(1 − $\\tilde r_u$)", ylabel="Points with $D_N$ > 5 cm (%)", title="(c) Strength needed to explain the event", ylim=(0, 102), xlim=(24, 48)); ax[2].legend(fontsize=6.8, loc="upper right", bbox_to_anchor=(1.0, 0.72))
L = P[P.landslide == 1]; dd = DN(ky(L.slope_deg, 36, 0), L.pga_g) > 5; dw = DN(ky(L.slope_deg, 36, .25), L.pga_g) > 5
cat = np.where(dd, "dry state", np.where(dw, "only when wetted", "not predicted"))
for nm, c, s in [("not predicted", GREY, 3), ("only when wetted", TEAL, 4), ("dry state", TERRA, 4)]:
    m = cat == nm; ax[3].scatter(L.lon[m], L.lat[m], s=s, color=c, lw=0, label=f"{nm} ({m.mean()*100:.0f} %)")
ax[3].plot(141.9303, 42.6864, "*", color="#3F3D8F", ms=11, mec="white"); ax[3].annotate("epicentre", (141.9303, 42.6864), (141.80, 42.66), fontsize=6.8, color="#3F3D8F", arrowprops=dict(arrowstyle="-", lw=.5, color="#3F3D8F"))
ax[3].set(xlabel="Longitude (°E)", ylabel="Latitude (°N)", title="(d) Landslides predicted ($\\varphi'$ 36°, $\\tilde r_u$ 0.25)"); ax[3].set_aspect(1 / np.cos(np.radians(42.75))); ax[3].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=1, markerscale=2.5)
for e in ("png", "pdf"): f.savefig(OUT + "figures_manuscript/Fig_Iburi_validation." + e, dpi=600 if e == "png" else None, bbox_inches="tight", facecolor="white")
print("saved")
