"""Parse the USGS ShakeMap grid.xml (us2000h8ty) and interpolate PGA, PGV and Vs30 to the Iburi sample points."""
import sys, re, numpy as np, pandas as pd
from scipy.interpolate import RegularGridInterpolator
OUT = "/mnt/user-data/outputs/field_validation/"
txt = open(sys.argv[1], encoding="utf-8", errors="replace").read()
spec = dict(re.findall(r'(\w+)="([^"]+)"', re.search(r"<grid_specification[^>]*>", txt).group(0)))
nlon, nlat = int(spec["nlon"]), int(spec["nlat"])
data = np.array(txt[txt.index("<grid_data>") + 11: txt.index("</grid_data>")].split(), dtype=float).reshape(-1, 9)
assert len(data) == nlon * nlat, (len(data), nlon * nlat)
lon = data[:nlon, 0]; lat = data[::nlon, 1]                     # lat descending
G = data.reshape(nlat, nlon, 9)
P = pd.read_csv(OUT + "Iburi_points_with_slope.csv")
for k, nm, sc in [(3, "pga_g", 0.01), (4, "pgv_cms", 1.0), (8, "vs30_ms", 1.0), (2, "mmi", 1.0)]:
    f = RegularGridInterpolator((lat[::-1], lon), G[::-1, :, k]); P[nm] = f(np.c_[P.lat, P.lon]) * sc
P.to_csv(OUT + "Iburi_points_slope_pga.csv", index=False)
print(P.groupby("landslide")[["slope_deg", "pga_g", "pgv_cms"]].describe().round(2).T.to_string())
