"""Slope (Horn 1981, degrees) from Copernicus GLO-30 tiles (EPSG:4326) sampled at the Iburi sample points."""
import sys, numpy as np, pandas as pd, rasterio
OUT = "/mnt/user-data/outputs/field_validation/"
P = pd.read_csv(OUT + "Iburi_sample_points.csv"); P["slope_deg"] = np.nan; P["elev_m"] = np.nan
for f in sys.argv[1:]:
    with rasterio.open(f) as d:
        z = d.read(1).astype(float); T = d.transform
        lat0 = d.bounds.bottom + (d.bounds.top - d.bounds.bottom) / 2
        dx = d.res[0] * 111320 * np.cos(np.radians(lat0)); dy = d.res[1] * 110574
        zp = np.pad(z, 1, mode="edge")
        a, b, c = zp[:-2, :-2], zp[:-2, 1:-1], zp[:-2, 2:]; dd, ff = zp[1:-1, :-2], zp[1:-1, 2:]; g, h, i = zp[2:, :-2], zp[2:, 1:-1], zp[2:, 2:]
        gx = ((c + 2 * ff + i) - (a + 2 * dd + g)) / (8 * dx); gy = ((g + 2 * h + i) - (a + 2 * b + c)) / (8 * dy)
        S = np.degrees(np.arctan(np.hypot(gx, gy)))
        m = (P.lon >= d.bounds.left) & (P.lon < d.bounds.right) & (P.lat >= d.bounds.bottom) & (P.lat < d.bounds.top)
        rows, cols = rasterio.transform.rowcol(T, P.lon[m].values, P.lat[m].values)
        P.loc[m, "slope_deg"] = S[rows, cols]; P.loc[m, "elev_m"] = z[rows, cols]
        print(f.split("/")[-1], "sampled", int(m.sum()))
P.to_csv(OUT + "Iburi_points_with_slope.csv", index=False)
s = P.dropna(subset=["slope_deg"])
print(s.groupby("landslide").slope_deg.describe().round(1))
