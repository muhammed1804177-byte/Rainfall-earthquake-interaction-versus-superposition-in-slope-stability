"""Source-area slope for each Iburi landslide: rasterise the polygon on the 30 m Copernicus DEM, keep the pixels in the
upper quarter of the polygon's elevation range (the source area rather than the runout/deposit) and take their median
slope. Non-landslide points use the median slope of a 3 x 3 pixel window. Comparison points are then restricted to
hillslopes (slope >= 10 deg) and to the elevation band of the landslide source areas (5th-95th percentile)."""
import sys, numpy as np, pandas as pd, rasterio, shapefile
from rasterio.features import rasterize
from pyproj import Transformer
from scipy.interpolate import RegularGridInterpolator
FV = "/mnt/user-data/outputs/field_validation/"; INV = sys.argv[1]; TILES = sys.argv[2:4]; GRID = sys.argv[4]
# mosaic the two tiles (same grid spacing, adjacent in longitude)
Z, B = [], []
for f in TILES:
    with rasterio.open(f) as d: Z.append(d.read(1).astype(float)); B.append(d.bounds); res = d.res
order = np.argsort([b.left for b in B]); Z = np.hstack([Z[i] for i in order]); left = B[order[0]].left; top = B[order[0]].top
T = rasterio.transform.from_origin(left, top, res[0], res[1])
lat0 = 42.75; dx = res[0] * 111320 * np.cos(np.radians(lat0)); dy = res[1] * 110574
zp = np.pad(Z, 1, mode="edge"); a, b, c = zp[:-2, :-2], zp[:-2, 1:-1], zp[:-2, 2:]; d_, f_ = zp[1:-1, :-2], zp[1:-1, 2:]; g, h, i = zp[2:, :-2], zp[2:, 1:-1], zp[2:, 2:]
S = np.degrees(np.arctan(np.hypot(((c + 2 * f_ + i) - (a + 2 * d_ + g)) / (8 * dx), ((g + 2 * h + i) - (a + 2 * b + c)) / (8 * dy))))
tr = Transformer.from_crs(3100, 4326, always_xy=True)
r = shapefile.Reader(INV, encoding="cp932", encodingErrors="replace")
P = pd.read_csv(FV + "Iburi_points_slope_pga.csv"); L = P[P.landslide == 1].reset_index(drop=True); N = P[P.landslide == 0].reset_index(drop=True)
src_slope, src_elev, n_src, max_slope = [], [], [], []
for k, shp in enumerate(r.shapes()):
    pts = np.array(shp.points); lon, lat = tr.transform(pts[:, 0], pts[:, 1])
    parts = list(shp.parts) + [len(pts)]; rings = [list(zip(lon[parts[j]:parts[j + 1]], lat[parts[j]:parts[j + 1]])) for j in range(len(parts) - 1)]
    c0, r0 = ~T * (min(lon), max(lat)); c1, r1 = ~T * (max(lon), min(lat)); c0, r0 = int(max(c0 - 1, 0)), int(max(r0 - 1, 0)); c1, r1 = int(c1 + 2), int(r1 + 2)
    sub = rasterio.transform.from_origin(left + c0 * res[0], top - r0 * res[1], res[0], res[1])
    m = rasterize([{"type": "Polygon", "coordinates": rings}], out_shape=(r1 - r0, c1 - c0), transform=sub, all_touched=False).astype(bool)
    zz, ss = Z[r0:r1, c0:c1][m], S[r0:r1, c0:c1][m]
    if len(zz) < 3:   # very small polygon: centroid value
        src_slope.append(L.slope_deg[k]); src_elev.append(L.elev_m[k]); n_src.append(len(zz)); max_slope.append(L.slope_deg[k]); continue
    up = zz >= np.quantile(zz, .75); src_slope.append(np.median(ss[up])); src_elev.append(np.median(zz[up])); n_src.append(int(up.sum())); max_slope.append(np.percentile(ss, 90))
L["slope_source_deg"] = src_slope; L["elev_source_m"] = src_elev; L["n_source_px"] = n_src; L["slope_p90_deg"] = max_slope
rows, cols = rasterio.transform.rowcol(T, N.lon.values, N.lat.values); rows, cols = np.array(rows), np.array(cols)
win = np.stack([S[np.clip(rows + di, 0, S.shape[0] - 1), np.clip(cols + dj, 0, S.shape[1] - 1)] for di in (-1, 0, 1) for dj in (-1, 0, 1)])
N["slope_source_deg"] = np.median(win, 0); N["elev_source_m"] = N.elev_m; N["n_source_px"] = 9; N["slope_p90_deg"] = np.percentile(win, 90, 0)
Q = pd.concat([L, N], ignore_index=True); Q.to_csv(FV + "Iburi_points_source_slope.csv", index=False)
lo, hi = np.percentile(L.elev_source_m, [5, 95])
M = Q[(Q.slope_source_deg >= 10) & Q.elev_source_m.between(lo, hi)]
M.to_csv(FV + "Iburi_matched_hillslope_points.csv", index=False)
print("source slope, landslides:", L.slope_source_deg.describe().round(1).to_dict())
print("elevation band of sources: %.0f-%.0f m; matched sample:" % (lo, hi), M.landslide.value_counts().to_dict())
print(M.groupby("landslide")[["slope_source_deg", "pga_g"]].median().round(3))
