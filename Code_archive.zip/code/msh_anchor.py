"""Mechanics-anchored hybrid (MAH): reconciling the data-driven Kaggle FoS with slope mechanics.
Prior P(x) = MVB-trained surrogate of pseudo-static Bishop, evaluated on each slope's mechanics inputs (H, beta, c, phi,
gamma, r_u, kh). Variants trained on the Kaggle training split (same splits, test used once):
  A  data-only LightGBM (reference)
  B  LightGBM with the mechanics prior as an extra feature
  C  residual LightGBM: log FoS = log P(x) + g(all inputs)
  D  anchored-calibration: log FoS = log P(x) + g(non-mechanics inputs only: rainfall, groundwater, weathering, soil,
     vegetation, drainage) -> sensitivities to the mechanics variables come from mechanics by construction
Each variant: Kaggle test accuracy + agreement of its log-sensitivities with Bishop on the 300 audit slopes (M4)."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_mechanics as ME
src = open(os.path.join(HERE, "msh_unified.py")).read(); exec(src.split("# ===================================================================== 6. tree models")[0])
import lightgbm as lgb2
from scipy.stats import spearmanr
OUTM = ME.OUT; T1 = time.time()
def say2(*a): print(f"[MAH {(time.time()-T1)/60:5.1f}m]", *a, flush=True)
MECH = ["SlopeHeight_m", "SlopeAngle_deg", "Cohesion_kPa", "FrictionAngle_deg", "UnitWeight_kN_m3", "PorePressureRatio", "SeismicCoefficient"]
ENV = [c for c in FEATS if c not in MECH + ["StabilityNumber_N", "FrictionRatio", "FS_infinite"]]
def prior(A):
    d = pd.DataFrame(A[MECH].values, columns=ME.COLS)
    for i, k in enumerate(ME.COLS): d[k] = d[k].clip(ME.LO[i], ME.HI[i])
    return np.log(np.clip(ME.pred(ME.BEST, ME.feats(d)), .05, 20))
def lg(): return lgb2.LGBMRegressor(n_estimators=5000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS)
Atr, Ava, Ate = A_sva.iloc[s_tr], A_sva.iloc[s_va], A_sva.iloc[s_te]; y = sva.FoS.values; ytr, yva, yte = y[s_tr], y[s_va], y[s_te]
Ptr, Pva, Pte = prior(Atr), prior(Ava), prior(Ate)
es = lambda: [lgb2.early_stopping(150, verbose=False)]
def build():
    M = {}
    M["A data-only LightGBM"] = lg().fit(Atr, ytr, eval_set=[(Ava, yva)], callbacks=es())
    M["B + mechanics prior feature"] = lg().fit(Atr.assign(prior=Ptr), ytr, eval_set=[(Ava.assign(prior=Pva), yva)], callbacks=es())
    M["C residual on mechanics prior (all inputs)"] = lg().fit(Atr, np.log(ytr) - Ptr, eval_set=[(Ava, np.log(yva) - Pva)], callbacks=es())
    M["D anchored calibration (environment inputs only)"] = lg().fit(Atr[ENV], np.log(ytr) - Ptr, eval_set=[(Ava[ENV], np.log(yva) - Pva)], callbacks=es())
    return M
f = ME.CK + "mah_models.joblib"; M = joblib.load(f) if os.path.exists(f) else build(); joblib.dump(M, f)
def predict(n, A):
    if n.startswith("A"): return M[n].predict(A[FEATS])
    if n.startswith("B"): return M[n].predict(A[FEATS].assign(prior=prior(A)))
    if n.startswith("C"): return np.exp(prior(A) + M[n].predict(A[FEATS]))
    return np.exp(prior(A) + M[n].predict(A[ENV]))
# sensitivities on the same 300 audit slopes as M4
S = TS["A"].sample(300, random_state=11).reset_index(drop=True)
MAP = {"c": "Cohesion_kPa", "phi": "FrictionAngle_deg", "beta": "SlopeAngle_deg", "H": "SlopeHeight_m", "gamma": "UnitWeight_kN_m3", "ru": "PorePressureRatio", "kh": "SeismicCoefficient"}
STEP = {"c": 3., "phi": 1.5, "beta": 2., "H": 2., "gamma": .5, "ru": .03, "kh": .02}
def shifted(k, sgn):
    D = S.copy(); D[MAP[k]] = np.clip(D[MAP[k]] + sgn * STEP[k], LO_[MAP[k]], HI_[MAP[k]]); return recompute(D)
B = joblib.load(ME.CK + "m4_sens_BishopPSLEM.joblib")
rows = []; SENSALL, PREDALL = {}, {}
for n in M:
    p = np.clip(predict(n, Ate), .25, 5); a, b = to_class(yte), to_class(p)
    sens = {}
    for k in MAP:
        Dp, Dm = shifted(k, 1), shifted(k, -1); dx = Dp[MAP[k]].values - Dm[MAP[k]].values
        sens[k] = np.where(dx > 0, (np.log(np.clip(predict(n, Dp), .05, 50)) - np.log(np.clip(predict(n, Dm), .05, 50))) / np.where(dx > 0, dx, 1), np.nan)
    r = dict(model=n, R2=r2_score(yte, p), RMSE=mean_squared_error(yte, p) ** .5, Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1))
    for k in MAP:
        ok = np.isfinite(B[k]) & np.isfinite(sens[k])
        r[f"rho_{k}"] = spearmanr(B[k][ok], sens[k][ok])[0]; r[f"ratio_{k}"] = np.median(sens[k][ok]) / np.median(B[k][ok])
    r["mean_rho_with_Bishop"] = np.mean([r[f"rho_{k}"] for k in MAP]); r["mean_abs_log_ratio"] = np.mean([abs(np.log(abs(r[f"ratio_{k}"]))) for k in MAP])
    SENSALL[n], PREDALL[n] = sens, p
    rows.append(r); say2(n, {k: round(v, 3) for k, v in r.items() if k != "model"})
T = pd.DataFrame(rows).set_index("model"); T.round(4).to_csv(OUTM + "M8_mechanics_anchored_hybrid.csv"); say2("\n" + T.round(3).T.to_string())
# Pareto front: log-space blend of the data-only (A) and anchored (D) models, log F = w log F_A + (1 - w) log F_D
a_, d_ = "A data-only LightGBM", "D anchored calibration (environment inputs only)"; pr = []
for w in np.round(np.linspace(0, 1, 21), 2):
    p = np.exp(w * np.log(PREDALL[a_]) + (1 - w) * np.log(PREDALL[d_])); p = np.clip(p, .25, 5); rr = dict(w_data=w, R2=r2_score(yte, p), RMSE=mean_squared_error(yte, p) ** .5, Accuracy=accuracy_score(to_class(yte), to_class(p)))
    rh = []
    for k in MAP:
        sk = w * SENSALL[a_][k] + (1 - w) * SENSALL[d_][k]; ok = np.isfinite(B[k]) & np.isfinite(sk); rh.append(spearmanr(B[k][ok], sk[ok])[0])
        rr[f"ratio_{k}"] = np.median(sk[ok]) / np.median(B[k][ok])
    rr["mean_rho_with_Bishop"] = np.mean(rh); pr.append(rr)
PF = pd.DataFrame(pr); PF.round(4).to_csv(OUTM + "M8b_accuracy_vs_mechanics_pareto.csv", index=False); say2("\n" + PF.round(3).to_string())
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(5.2, 4)); ax.plot(PF.mean_rho_with_Bishop, PF.R2, "-o", color="#2a78d6", lw=2, ms=4)
for _, r in PF.iloc[::2].iterrows(): ax.annotate(f"w={r.w_data:.1f}", (r.mean_rho_with_Bishop, r.R2), textcoords="offset points", xytext=(5, -10), fontsize=7, color="#52514e")
ax.set(xlabel="Mean rank correlation of sensitivities with Bishop", ylabel="R2 on Kaggle test labels", title="Data fit vs mechanics consistency")
ax.spines[["top", "right"]].set_visible(False); ax.grid(color="#e1e0d9"); plt.tight_layout(); plt.savefig(OUTM + "figures/M8_pareto_data_vs_mechanics.png", dpi=300); plt.close()
say2("DONE")
