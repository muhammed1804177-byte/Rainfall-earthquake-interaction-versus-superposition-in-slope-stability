"""Validation-only choice of the blend weight w (no test information): the smallest data weight w whose VALIDATION R2
meets the study's predefined benchmark R2 >= 0.93 (maximum mechanics consistency subject to the benchmark)."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_anchor.py")).read().split("# sensitivities on the same 300 audit slopes")[0]; exec(src)
a_, d_ = "A data-only LightGBM", "D anchored calibration (environment inputs only)"
pa, pdd = predict(a_, Ava), predict(d_, Ava); rows = []
for w in np.round(np.linspace(0, 1, 21), 2):
    p = np.clip(np.exp(w * np.log(pa) + (1 - w) * np.log(pdd)), .25, 5); rows.append(dict(w_data=w, val_R2=r2_score(yva, p), val_accuracy=accuracy_score(to_class(yva), to_class(p))))
V = pd.DataFrame(rows); w_sel = float(V[V.val_R2 >= .93].w_data.min()); V["selected"] = V.w_data == w_sel
V.round(4).to_csv(OUTM + "M8c_blend_weight_selected_on_validation.csv", index=False)
pt = np.clip(np.exp(w_sel * np.log(predict(a_, Ate)) + (1 - w_sel) * np.log(predict(d_, Ate))), .25, 5)
say2(f"selected w = {w_sel} (validation R2 {V[V.selected].val_R2.iloc[0]:.4f}); TEST R2 {r2_score(yte, pt):.4f}, RMSE {mean_squared_error(yte, pt)**.5:.4f}, accuracy {accuracy_score(to_class(yte), to_class(pt)):.4f}")
open(OUTM + "M8d_selected_blend.txt", "w").write(f"w_data={w_sel}\ntest_R2={r2_score(yte, pt):.4f}\ntest_RMSE={mean_squared_error(yte, pt)**.5:.4f}\ntest_accuracy={accuracy_score(to_class(yte), to_class(pt)):.4f}\n")
say2("DONE")
