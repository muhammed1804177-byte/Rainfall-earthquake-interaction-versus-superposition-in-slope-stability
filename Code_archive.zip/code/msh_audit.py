"""Provenance audit of the SVA dataset: compare its FoS with an independent Bishop simplified LEM (same H, beta, c, phi,
gamma, r_u) on 1,500 random slopes, overall and by seismic level (Bishop here is static; kh effect shown separately)."""
import numpy as np, pandas as pd, sys
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__))); from bishop import bishop_fos
from scipy.stats import spearmanr, pearsonr
d = pd.read_csv((__import__("os").environ.get("MSH_DATA", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/data") + "/1791149933879_Slope_dataset_SVA.csv")).sample(1500, random_state=1).reset_index(drop=True)
d["Bishop_FoS"] = [bishop_fos(r.SlopeHeight_m, r.SlopeAngle_deg, r.Cohesion_kPa, r.FrictionAngle_deg, r.UnitWeight_kN_m3, r.PorePressureRatio) for r in d.itertuples()]
rows = []
for name, m in [("all slopes", np.ones(len(d), bool)), ("kh < 0.05 (near static)", d.SeismicCoefficient < .05), ("kh >= 0.15", d.SeismicCoefficient >= .15),
                ("FoS not clipped (0.25 < FoS < 5)", (d.FactorOfSafety > .26) & (d.FactorOfSafety < 4.99))]:
    x, y = d.Bishop_FoS[m], d.FactorOfSafety[m]
    rows.append(dict(subset=name, n=int(m.sum()), spearman=spearmanr(x, y)[0], pearson_log=pearsonr(np.log(np.clip(x, .05, 50)), np.log(y))[0],
                     median_ratio_SVA_over_Bishop=float(np.median(y / x)), class_agreement_FoS_lt_1=float(np.mean((x < 1) == (y < 1)))))
A = pd.DataFrame(rows); print(A.round(3).to_string())
A.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/final_results/T8_SVA_dataset_audit_vs_Bishop.csv"), index=False)
d[["SlopeHeight_m","SlopeAngle_deg","Cohesion_kPa","FrictionAngle_deg","UnitWeight_kN_m3","PorePressureRatio","SeismicCoefficient","FactorOfSafety","Bishop_FoS"]].round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/final_results/T8b_SVA_vs_Bishop_sample.csv"), index=False)
