"""Calibrated closed-form rainfall-seismic equation fitted to direct pseudo-static Bishop runs.

Analytical basis (infinite slope, c'=0, pore-pressure ratio r_u on the slip plane, horizontal kh):
    F = tan(phi) (1 - r_u - kh tan(beta)) / (tan(beta) + kh)
    =>  F/F0 = (1 - r_u - kh tan b) / (1 + kh / tan b),      I = 1 - r_u kh tan b / ((1 - r_u)(1 - kh tan b))
Calibrated form for finite c-phi slopes (Bishop, circular):
    F/F0 = (1 - a r_u - b kh tan(beta)) / (1 + c kh / tan(beta)),   a = p0/(1 + p1 lambda), b = p2/(1 + p3 lambda), c = p4 (1 + p5 lambda), all p >= 0
    lambda_cphi = c' / (gamma H tan phi')  (Janbu 1954)
Fitted on 70 % of the sampled slopes, tested on the other 30 % (grouped by slope).
"""
import os, sys, json, time
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from scipy.optimize import least_squares
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from bishop_ps import bishop_ps

OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/calibrated_equation/"; os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(2026)
N = int(os.environ.get("N_SLOPES", 600))
LO = np.array([5, 15, 5, 15, 16]); HI = np.array([50, 50, 120, 45, 24])   # H, beta, c, phi, gamma
u = (rng.permutation(N)[:, None] + rng.random((N, 5))) / N
for j in range(5): u[:, j] = u[rng.permutation(N), j]                 # Latin hypercube
P = pd.DataFrame(LO + u * (HI - LO), columns=["H", "beta", "c", "phi", "gamma"])
RU = [0, .1, .2, .3, .4]; KH = [0, .05, .1, .15, .2]
jobs = [(i, ru, kh) for i in range(N) for ru in RU for kh in KH]
f = OUT + "bishop_factorial_runs.csv"
if not os.path.exists(f):
    t = time.time()
    res = Parallel(n_jobs=-1, batch_size=64)(delayed(bishop_ps)(*P.loc[i, ["H", "beta", "c", "phi", "gamma"]].values, ru, kh) for i, ru, kh in jobs)
    R = pd.DataFrame(jobs, columns=["slope", "ru", "kh"]); R["FoS"] = res
    R = R.merge(P.reset_index().rename(columns={"index": "slope"}), on="slope"); R.to_csv(f, index=False)
    print("Bishop runs", len(R), "in", round(time.time() - t), "s", flush=True)
R = pd.read_csv(f)
F0 = R[(R.ru == 0) & (R.kh == 0)].set_index("slope").FoS
R["F0"] = R.slope.map(F0); R = R[(R.F0 < 10) & (R.FoS < 49)].copy()
R["lam"] = R.c / (R.gamma * R.H * np.tan(np.radians(R.phi))); R["tb"] = np.tan(np.radians(R.beta))
R["y"] = np.log(R.FoS / R.F0)
sl = R.slope.unique(); rs = np.random.default_rng(7).permutation(sl); tr = set(rs[: int(.7 * len(rs))])
R["split"] = np.where(R.slope.isin(tr), "train", "test")

def model(p, d, form):
    L = np.log1p(d.lam.values)
    if form == "infinite-slope (a=b=c=1)": a = b = c = np.ones(len(d))
    elif form == "constant a,b,c": a, b, c = p[0], p[1], p[2]
    else: a, b, c = p[0] / (1 + p[1] * d.lam.values), p[2] / (1 + p[3] * d.lam.values), p[4] * (1 + p[5] * d.lam.values)
    num = np.clip(1 - a * d.ru.values - b * d.kh.values * d.tb.values, 1e-3, None)
    return np.log(num / (1 + c * d.kh.values / d.tb.values))

def interaction(d, Fhat):
    """I = F_RE F0 / (F_R F_E) per slope and loading cell, from FoS (true or predicted)."""
    k = d.assign(F=Fhat).set_index(["slope", "ru", "kh"]).F
    rows = []
    for (s, ru, kh), v in k.items():
        if ru == 0 or kh == 0: continue
        try: rows.append((s, ru, kh, v * k[(s, 0, 0)] / (k[(s, ru, 0)] * k[(s, 0, kh)])))
        except KeyError: pass
    return pd.DataFrame(rows, columns=["slope", "ru", "kh", "I"])

tr_d = R[R.split == "train"]; te_d = R[R.split == "test"]
out, params = [], {}
for form, p0 in [("infinite-slope (a=b=c=1)", []), ("constant a,b,c", [1, 1, 1]), ("lambda-dependent a,b,c", [1, 0.5, 1, 0.5, 1, 0.5])]:
    if p0:
        fit = least_squares(lambda p: model(p, tr_d, form) - tr_d.y.values, p0, bounds=(0, np.inf)); p = fit.x
    else: p = np.array([])
    params[form] = [round(float(x), 4) for x in p]
    for nm, d in [("train", tr_d), ("test", te_d)]:
        yh = model(p, d, form); Fh = d.F0.values * np.exp(yh)
        ss = ((d.FoS.values - Fh) ** 2).sum(); st = ((d.FoS.values - d.FoS.values.mean()) ** 2).sum()
        It = interaction(d, d.FoS.values); Ih = interaction(d, Fh)
        m = It.merge(Ih, on=["slope", "ru", "kh"], suffixes=("_bishop", "_eq"))
        cls = ((d.FoS.values < 1) == (Fh < 1)).mean()
        out.append(dict(form=form, split=nm, n_runs=len(d), R2_FoS=1 - ss / st, RMSE_FoS=np.sqrt(ss / len(d)),
                        MAPE_pct=np.mean(np.abs(Fh / d.FoS.values - 1)) * 100, class_agreement_pct=cls * 100,
                        I_median_bishop=m.I_bishop.median(), I_median_eq=m.I_eq.median(),
                        I_MAE=np.mean(np.abs(m.I_bishop - m.I_eq)), I_spearman=m[["I_bishop", "I_eq"]].corr("spearman").iloc[0, 1],
                        pct_I_lt_1_bishop=(m.I_bishop < 1).mean() * 100, pct_I_lt_1_eq=(m.I_eq < 1).mean() * 100))
T = pd.DataFrame(out).round(4); T.to_csv(OUT + "C1_calibrated_equation_performance.csv", index=False)
json.dump(params, open(OUT + "C2_calibrated_parameters.json", "w"), indent=1)
# cell-wise check for the test slopes
best = "lambda-dependent a,b,c"; p = np.array(params[best]); Fh = te_d.F0.values * np.exp(model(p, te_d, best))
It = interaction(te_d, te_d.FoS.values); Ih = interaction(te_d, Fh); m = It.merge(Ih, on=["slope", "ru", "kh"], suffixes=("_bishop", "_eq"))
m.groupby(["ru", "kh"])[["I_bishop", "I_eq"]].median().round(4).reset_index().to_csv(OUT + "C3_interaction_by_cell_test.csv", index=False)
print(T.to_string()); print(params)

lam = R.drop_duplicates("slope").lam
print("lambda quantiles", lam.quantile([0, .1, .5, .9, 1]).round(3).to_dict())
