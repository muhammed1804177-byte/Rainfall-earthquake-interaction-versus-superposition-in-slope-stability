"""Check the closed-form yield coefficient implied by the calibrated equation against Bishop bisection (test slopes)."""
import os, sys, json, numpy as np, pandas as pd
from joblib import Parallel, delayed
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from bishop_ps import bishop_ps
OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/calibrated_equation/"
R = pd.read_csv(OUT + "bishop_factorial_runs.csv"); p = json.load(open(OUT + "C2_calibrated_parameters.json"))["lambda-dependent a,b,c"]
S = R[(R.ru == 0) & (R.kh == 0)].rename(columns={"FoS": "F0"})
S = S[(S.F0 > 1.05) & (S.F0 < 4)].sample(120, random_state=3)
def ky_bishop(r, ru):
    if bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru, 0.0) < 1: return 0.0
    lo, hi = 0.0, 0.6
    if bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru, hi) > 1: return np.nan
    for _ in range(14):
        m = (lo + hi) / 2
        if bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru, m) > 1: lo = m
        else: hi = m
    return (lo + hi) / 2
jobs = [(r, ru) for _, r in S.iterrows() for ru in (0.0, 0.2, 0.3)]
kb = Parallel(n_jobs=-1)(delayed(ky_bishop)(r, ru) for r, ru in jobs)
rows = []
for (r, ru), k in zip(jobs, kb):
    lam = r.c / (r.gamma * r.H * np.tan(np.radians(r.phi))); tb = np.tan(np.radians(r.beta))
    F0 = r.F0; a = p[0] / (1 + p[1] * lam); b = p[2] / (1 + p[3] * lam); c = p[4] * (1 + p[5] * lam)
    Fr = F0 * (1 - a * ru)                       # static FoS after wetting from the equation
    ke = max(0.0, (Fr - 1) / (F0 * b * tb + c / tb))
    rows.append(dict(slope=r.slope, H=r.H, beta=r.beta, c=r.c, phi=r.phi, gamma=r.gamma, lam=lam, F0=F0, ru=ru, ky_bishop=k, ky_equation=ke))
D = pd.DataFrame(rows).dropna(); D.to_csv(OUT + "C4_yield_coefficient_equation_vs_Bishop.csv", index=False)
d = D[D.ky_bishop > 0]
s = dict(n=len(D), n_positive=len(d), MAE=float(np.mean(np.abs(d.ky_bishop - d.ky_equation))), R2=float(1 - ((d.ky_bishop - d.ky_equation) ** 2).sum() / ((d.ky_bishop - d.ky_bishop.mean()) ** 2).sum()),
         median_bishop={str(k): float(v) for k, v in D.groupby("ru").ky_bishop.median().items()}, median_eq={str(k): float(v) for k, v in D.groupby("ru").ky_equation.median().items()},
         zero_agreement=float(((D.ky_bishop == 0) == (D.ky_equation == 0)).mean()))
json.dump(s, open(OUT + "C5_yield_summary.json", "w"), indent=1); print(s)
