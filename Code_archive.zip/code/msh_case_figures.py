"""Figures for the calibrated closed-form equation (Fig16) and the Tandikat case study (Fig17 site, Fig18 analysis).
Site photographs/section/rainfall in Fig17 are reproduced from Faris & Fawu (2014), Geoenvironmental Disasters 1:4,
doi:10.1186/s40677-014-0004-3, under CC BY 4.0 (authors' own field photographs; the AP aerial photo is NOT used)."""
import os, sys, json
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyArrowPatch
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/figures_manuscript/"; CE = ROOT + "/calibrated_equation/"
IMG = ROOT + "/manuscript/img_src/"; CASE = ROOT + "/case_tandikat/"
plt.rcParams.update({"font.family": "Inter", "font.size": 8.2, "axes.titleweight": "semibold", "axes.titlesize": 8.8, "axes.titlelocation": "left",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#BDB6A8", "axes.grid": True, "grid.color": "#E6E1D8",
                     "grid.linewidth": .5, "pdf.fonttype": 42, "legend.frameon": False})
INK, INK2 = "#1F2328", "#555B61"
TEAL, PLUM, OCHRE, BASALT, TERRA, PUMICE, CLAY = "#1F8A84", "#6B4C9A", "#C98A1B", "#3A3D42", "#B5573B", "#D9C29A", "#9C8468"

def save(fig, name):
    for e in ("png", "pdf"): fig.savefig(OUT + name + "." + e, dpi=600 if e == "png" else None, facecolor="white", bbox_inches="tight")
    plt.close(fig); print("saved", name)

# ======================= Fig16 calibrated equation =======================
R = pd.read_csv(CE + "bishop_factorial_runs.csv"); P = json.load(open(CE + "C2_calibrated_parameters.json"))["lambda-dependent a,b,c"]
F0 = R[(R.ru == 0) & (R.kh == 0)].set_index("slope").FoS; R["F0"] = R.slope.map(F0); R = R[(R.F0 < 10) & (R.FoS < 49)].copy()
R["lam"] = R.c / (R.gamma * R.H * np.tan(np.radians(R.phi))); R["tb"] = np.tan(np.radians(R.beta))
a = P[0] / (1 + P[1] * R.lam); b = P[2] / (1 + P[3] * R.lam); c = P[4] * (1 + P[5] * R.lam)
R["Feq"] = R.F0 * np.clip(1 - a * R.ru - b * R.kh * R.tb, 1e-3, None) / (1 + c * R.kh / R.tb)
sl = R.slope.unique(); rs = np.random.default_rng(7).permutation(sl); tr = set(rs[: int(.7 * len(rs))]); T = R[~R.slope.isin(tr)]
C1 = pd.read_csv(CE + "C1_calibrated_equation_performance.csv"); C3 = pd.read_csv(CE + "C3_interaction_by_cell_test.csv"); K = pd.read_csv(CE + "C4_yield_coefficient_equation_vs_Bishop.csv")
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.6), gridspec_kw=dict(wspace=.38))
m = (T.ru > 0) & (T.kh > 0)
for sel, col, lab, mk in [((T.ru > 0) & (T.kh == 0), TEAL, "rainfall only", "o"), ((T.ru == 0) & (T.kh > 0), PLUM, "seismic only", "s"), (m, OCHRE, "combined", "^")]:
    d = T[sel & (T.FoS < 4)]; ax[0].scatter(d.FoS, d.Feq, s=3, color=col, alpha=.45, marker=mk, lw=0, label=lab)
ax[0].plot([0, 4], [0, 4], color=BASALT, lw=.8, ls="--"); ax[0].set(xlim=(0, 4), ylim=(0, 4), xlabel="Bishop FoS (pseudo-static)", ylabel="Calibrated equation FoS")
r = C1[(C1.form == "lambda-dependent a,b,c") & (C1.split == "test")].iloc[0]
ax[0].text(.05, .95, f"test slopes: R² = {r.R2_FoS:.3f}\nMAPE = {r.MAPE_pct:.1f} %\nFoS<1 agreement = {r.class_agreement_pct:.1f} %", transform=ax[0].transAxes, va="top", fontsize=7.4)
ax[0].legend(loc="lower right", fontsize=7, markerscale=3, handletextpad=.2); ax[0].set_title("(a) Combined-loading FoS")
for kh, mk in zip([.05, .1, .15, .2], ["o", "s", "^", "D"]):
    d = C3[C3.kh == kh]; ax[1].plot(d.ru, d.I_bishop, color=BASALT, marker=mk, ms=4, mfc="white", lw=.8, ls="--")
    ax[1].plot(d.ru, d.I_eq, color=TERRA, marker=mk, ms=3.2, lw=1.1); ax[1].text(d.ru.iloc[-1] + .012, d.I_eq.iloc[-1], f"$k_h$={kh}", fontsize=6.8, va="center", color=INK2)
ax[1].set(xlabel="Pore-pressure ratio $r_u$", ylabel="Median interaction index $I$", xlim=(.05, .49)); ax[1].set_title("(b) Interaction index")
ax[1].plot([], [], color=BASALT, ls="--", marker="o", mfc="white", label="Bishop"); ax[1].plot([], [], color=TERRA, marker="o", label="Calibrated equation"); ax[1].legend(loc="lower left", fontsize=7)
for ru, col, mk in [(0, BASALT, "o"), (.2, TEAL, "s"), (.3, PLUM, "^")]:
    d = K[K.ru == ru]; ax[2].scatter(d.ky_bishop, d.ky_equation, s=9, color=col, marker=mk, alpha=.75, lw=0, label=f"$r_u$ = {ru}")
s5 = json.load(open(CE + "C5_yield_summary.json"))
ax[2].plot([0, .6], [0, .6], color=BASALT, lw=.8, ls="--"); ax[2].set(xlim=(0, .6), ylim=(0, .6), xlabel="Bishop yield coefficient $k_y$", ylabel="Closed-form $k_y$ (calibrated)")
ax[2].text(.05, .95, f"R² = {s5['R2']:.3f}\nMAE = {s5['MAE']:.3f}", transform=ax[2].transAxes, va="top", fontsize=7.4); ax[2].legend(loc="lower right", fontsize=7)
ax[2].set_title("(c) Yield coefficient")
save(fig, "Fig16_calibrated_equation")

# ======================= Fig17 Tandikat site =======================
from PIL import Image
fig = plt.figure(figsize=(7.2, 6.4))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.0], hspace=.12, wspace=.08)
a0 = fig.add_subplot(gs[0, :]); a0.imshow(Image.open(IMG + "p4_1.png")); a0.axis("off")
a0.set_title("(a) Field photographs: tuffaceous pumice sand over sandy clay (left) and water ponding on the clay (right)", fontsize=8.4)
a1 = fig.add_subplot(gs[1, 0]); a1.imshow(Image.open(IMG + "p5_1.png")); a1.axis("off"); a1.set_anchor("N"); a1.set_title("(b) Longitudinal section of the landslide", fontsize=8.4)
# (c) own infinite-slope model of the case
a2 = fig.add_subplot(gs[1, 1]); a2.grid(False); a2.axis("off"); a2.set_title("(c) Analysis model used here (infinite slope)", fontsize=8.4)
th = np.radians(30); t = np.tan(th); X0, X1 = 0.0, 9.0
def y_s(x, d=0.0): return x * t - d
xx = np.array([X0, X1]); mwt = 0.3
a2.fill_between(xx, y_s(xx, 3), y_s(xx, 7.5), color=CLAY, lw=0)
a2.fill_between(xx, y_s(xx, 0), y_s(xx, 3), color=PUMICE, lw=0)
a2.fill_between(xx, y_s(xx, 3 - 3 * mwt), y_s(xx, 3), color="#9CC9E0", lw=0, alpha=.9)
a2.plot(xx, y_s(xx), color=INK, lw=1.3); a2.plot(xx, y_s(xx, 3), color=TERRA, lw=1.6, ls=(0, (5, 2))); a2.plot(xx, y_s(xx, 3 - 3 * mwt), color="#2C7FB8", lw=1.2)
x0, w = 4.0, 1.3; bx_ = [x0, x0 + w, x0 + w, x0]; by_ = [y_s(x0), y_s(x0 + w), y_s(x0 + w, 3), y_s(x0, 3)]
a2.add_patch(Polygon(np.c_[bx_, by_], fc="none", ec=INK, lw=1.1))
cx, cy = x0 + w / 2, y_s(x0 + w / 2, 1.5)
a2.add_patch(FancyArrowPatch((cx, cy + .3), (cx, cy - 1.6), arrowstyle="-|>", mutation_scale=9, color=INK, lw=1.3)); a2.text(cx + .12, cy - 1.45, "$W$", fontsize=8.5)
a2.add_patch(FancyArrowPatch((cx, cy + .3), (cx - 1.7, cy + .3), arrowstyle="-|>", mutation_scale=9, color=PLUM, lw=1.3)); a2.text(cx - 2.1, cy - .25, "$k_hW$", color=PLUM, fontsize=8.5, va="top")
a2.text(-1.5, 5.4, "pumice sand\n$\\varphi'$ = 39°, $c'$ = 0\n$\\gamma_m$ = 14.7 kN/m³", fontsize=7.0, ha="left", va="top")
a2.text(5.0, y_s(5.0, 4.9), "stiff sandy clay\n(impermeable)", fontsize=6.8, ha="center", va="center", color="white")
a2.text(9.15, y_s(9, 2.6), "$m\\,l$", fontsize=8, color="#2C7FB8", va="center")
a2.text(9.15, y_s(9, 3.15), "slip plane", fontsize=7, color=TERRA, va="center")
a2.annotate("", xy=(0.9, y_s(0.9)), xytext=(0.9, y_s(0.9, 3)), arrowprops=dict(arrowstyle="<->", lw=.8, color=INK2)); a2.text(0.75, y_s(0.9, 1.6), "$l$ = 3 m", fontsize=7.6, color=INK2, ha="right")
a2.text(2.3, y_s(2.3, 8.6), "$\\theta$ = 30°", fontsize=8, color=INK2)
a2.set_xlim(-1.6, 10.6); a2.set_ylim(-7.8, 5.9); a2.set_aspect("equal"); a2.set_anchor("N")
fig.text(0.01, 0.005, "Panels (a) and (b) reproduced from Faris and Fawu (2014), Geoenvironmental Disasters 1:4, CC BY 4.0.", fontsize=6.8, color=INK2)
save(fig, "Fig17_Tandikat_site")

# ======================= Fig18 Tandikat analysis =======================
th, ph, l, gw = np.radians(30), np.radians(39), 3.0, 9.81; gm = 1.503 * gw; gs_ = (2.664 + 2.0) / 3.0 * gw
def gbar(m): return (1 - m) * gm + m * gs_
def ru_of(m): return gw * m / gbar(m)
def Fos(m, kh, dru=0.0):
    ru = ru_of(m); return np.tan(ph) * (1 - ru - dru * (1 - ru) - kh * np.tan(th)) / (np.tan(th) + kh)
def Ky(m, dru=0.0):
    ru = ru_of(m) + dru * (1 - ru_of(m)); return np.maximum((np.tan(ph) * (1 - ru) - np.tan(th)) / (1 + np.tan(ph) * np.tan(th)), 0)
mm = np.linspace(0, .6, 301)
fig, ax = plt.subplots(2, 2, figsize=(7.2, 5.6), gridspec_kw=dict(hspace=.45, wspace=.48)); ax = ax.ravel()
for kh, col, ls in [(0, BASALT, "-"), (.05, TEAL, "-"), (.10, PLUM, "--"), (.15, TERRA, "-.")]:
    ax[0].plot(mm, Fos(mm, kh), color=col, ls=ls, lw=1.4, label=f"$k_h$ = {kh:.2f}")
ax[0].axhline(1, color=INK2, lw=.8, ls=":"); mc = mm[np.argmax(Fos(mm, 0) < 1)]
ax[0].plot([0, .3, 0, .3], [Fos(0, 0), Fos(.3, 0), Fos(0, .05), Fos(.3, .05)], ls="none", marker="o", ms=5, mfc="white", mec=INK)
ax[0].annotate(f"rain only (m=0.3): {Fos(.3, 0):.3f}", (.3, Fos(.3, 0)), (.33, 1.27), fontsize=7, arrowprops=dict(arrowstyle="-", lw=.5, color=INK2))
ax[0].annotate(f"shaking only ($k_h$=0.05): {Fos(0, .05):.3f}", (0, Fos(0, .05)), (.07, 1.38), fontsize=7, arrowprops=dict(arrowstyle="-", lw=.5, color=INK2))
ax[0].annotate(f"rain + shaking: {Fos(.3, .05):.3f}", (.3, Fos(.3, .05)), (.36, .9), fontsize=7, arrowprops=dict(arrowstyle="-", lw=.5, color=INK2))
ax[0].set(xlabel="Perched water-table ratio $m$", ylabel="Factor of safety $F$", ylim=(.55, 1.5)); ax[0].legend(fontsize=6.8, loc="lower left", ncol=2); ax[0].set_title("(a) FoS under rainfall and shaking")
for d, col, ls in [(0, BASALT, "-"), (.1, TEAL, "--"), (.2, PLUM, "-.")]:
    ax[1].plot(mm, Ky(mm, d), color=col, ls=ls, lw=1.4, label=f"cyclic $\\Delta r_u$ = {d}")
ax[1].set(xlabel="Perched water-table ratio $m$", ylabel="Yield coefficient $k_y$", ylim=(0, .17)); ax[1].legend(fontsize=7); ax[1].set_title("(b) Yield coefficient")
KH = np.linspace(0.005, .2, 120); M = np.linspace(.01, .45, 120); MM, KK = np.meshgrid(M, KH)
I = Fos(MM, KK) * Fos(0, 0) / (Fos(MM, 0) * Fos(0, KK))
cs = ax[2].contourf(MM, KK, I, levels=np.linspace(.94, 1, 13), cmap="BuPu_r"); ax[2].contour(MM, KK, Fos(MM, KK), levels=[1], colors=TERRA, linewidths=1.4)
ax[2].text(.33, .16, "$F$ < 1", color=TERRA, fontsize=8, fontweight="semibold"); ax[2].plot(.3, .05, "o", mfc="white", mec=INK, ms=5)
cb = fig.colorbar(cs, ax=ax[2], fraction=.05, pad=.03); cb.set_label("Interaction index $I$", fontsize=7.5); cb.ax.tick_params(labelsize=7)
ax[2].set(xlabel="Perched water-table ratio $m$", ylabel="Seismic coefficient $k_h$"); ax[2].grid(False); ax[2].set_title("(c) Interaction index (closed form)")
amax = np.linspace(.05, .5, 200)
def jib(ky, a): r = ky / a; return np.where(r < 1, 10 ** (0.215 + np.log10(np.clip((1 - r) ** 2.341 * r ** -1.438, 1e-12, None))), 0)
for m_, col, ls in [(0, BASALT, "-"), (.2, TEAL, "--"), (.3, PLUM, "-.")]:
    ky = Ky(m_); ax[3].plot(amax, jib(ky, amax), color=col, ls=ls, lw=1.4, label=f"m = {m_} ($k_y$ = {ky:.3f})")
ax[3].axhspan(5, 15, color="#EFE8DA", zorder=0); ax[3].text(.06, 9, "5–15 cm", fontsize=7, color=INK2)
ax[3].set(yscale="log", ylim=(.1, 300), xlabel="Peak ground acceleration (g)", ylabel="Newmark displacement $D_N$ (cm)"); ax[3].legend(fontsize=6.8, loc="lower right")
ax[3].set_title("(d) Newmark displacement, Jibson (2007)")
save(fig, "Fig18_Tandikat_analysis")
print("check", round(Fos(.3, 0), 4), round(Fos(0, .05), 4), round(Fos(.3, .05), 4), round(Ky(0), 4), round(Ky(0, .2), 4), "mcrit", mc)
