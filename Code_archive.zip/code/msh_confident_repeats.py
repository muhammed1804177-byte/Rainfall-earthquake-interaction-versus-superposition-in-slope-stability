"""Stability of the confident-verdict result: the k=4 confident-slope analysis repeated over 5 independent grouped-CV
repeats (different fold assignments). Reports mean +- SD of coverage and accuracy, and per-slope how often each real
slope received a confident verdict and how often that verdict was correct."""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "msh_confident_slopes.py")).read()
exec(src.split("prob, cut = np.zeros(len(y))")[0])
SEEDS = [11, 12, 13, 14, 15]; rows = []; NC = np.zeros(len(y)); NOK = np.zeros(len(y)); PF = np.zeros(len(y))
for s in SEEDS:
    prob, cut = np.zeros(len(y)), np.zeros(len(y))
    for a, bb in SGK(5, shuffle=True, random_state=s).split(X, y, Gp):
        po = np.zeros(len(a))
        for ia, ib in SGK(3, shuffle=True, random_state=s + 50).split(a, y[a], Gp[a]): po[ib] = Vote().fit(X[a][ia], y[a][ia]).predict_proba(X[a][ib])[:, 1]
        cf = np.abs(po - .5); c0 = cf.max()
        for cc in np.sort(np.unique(cf)):
            m = cf >= cc
            if m.sum() >= 10 and accuracy_score(y[a][m], po[m] > .5) >= .93: c0 = cc; break
        prob[bb] = Vote().fit(X[a], y[a]).predict_proba(X[bb])[:, 1]; cut[bb] = c0
    cm = np.abs(prob - .5) >= cut; ok = (prob > .5) == (y == 1); named = (real.location != "Unknown").values
    NC += cm; NOK += cm & ok; PF += prob
    rows.append(dict(seed=s, coverage_pct=cm.mean() * 100, accuracy_confident=ok[cm].mean() * 100, n_confident=int(cm.sum()),
                     accuracy_named_confident=ok[cm & named].mean() * 100, n_named_confident=int((cm & named).sum()), accuracy_all=ok.mean() * 100))
    say(rows[-1])
R = pd.DataFrame(rows); S = R.drop(columns="seed").agg(["mean", "std"]).T
R.round(3).to_csv(OUTR + "T18_confident_repeats_per_seed.csv", index=False); S.round(3).to_csv(OUTR + "T18b_confident_repeats_summary.csv")
P = real[["location"] + F6].copy(); P["observed"] = np.where(y == 1, "Failure", "Stable"); P["mean_P_failure"] = (PF / len(SEEDS)).round(3)
P["times_confident_of_5"] = NC.astype(int); P["times_confident_and_correct"] = NOK.astype(int)
P["always_confident"] = NC == len(SEEDS)
P.sort_values(["times_confident_of_5", "times_confident_and_correct"], ascending=False).to_csv(OUTR + "T18c_per_slope_confidence_frequency.csv", index=False)
A = P[P.always_confident]; say(f"\n{S.round(2).to_string()}\nslopes confident in all 5 repeats: {len(A)}, accuracy {(A.times_confident_and_correct == 5).mean()*100:.1f}% "
      f"(named: {(A.location != 'Unknown').sum()}, accuracy {((A.times_confident_and_correct == 5)[A.location != 'Unknown']).mean()*100:.1f}%)"); say("DONE")
