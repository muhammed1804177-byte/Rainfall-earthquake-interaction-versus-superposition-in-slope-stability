"""Lists the real slopes on which the k=4 framework (GRU + M1 + rainfall specialist + seismic specialist) gives a CONFIDENT
verdict, and the accuracy on that confident set. The confidence cut-off is chosen inside the training folds (target 93 %)
and applied identically to every slope, without using the slope's observed outcome. Wrong confident verdicts are listed too."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_unified.py")).read()
p1 = src.split("# ===================================================================== 6. tree models")[0]
p6 = src.split("# ===================================================================== 6. tree models")[1].split("PRED = {}")[0].split("\n", 1)[1]
p7 = src.split("# ===================================================================== 7. deep models")[1].split('say("7  deep models")')[0].split("\n", 1)[1]
exec(p1); exec(p6); exec(p7)
import pandas as pd, lightgbm as lgb2
from catboost import CatBoostClassifier
from bishop import bishop_fos
from sklearn.model_selection import StratifiedGroupKFold as SGK
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTR = ROOT + "/realworld_combinations/"
# ---- the four experts (trained on the 120,000 SVA slopes only)
SF = Space("fos")
M1m = train_dl("M1orig", lambda: M1(dict(CFG["M1"])), SF, lr=CFG["M1"]["lr"], bs=CFG["M1"]["bs"])
GRUm = train_dl("GRU", lambda: RNN("gru"), SF)
A_tr = TR["A"].iloc[:TR["nS"]]
Q = dict(ru75=A_tr.PorePressureRatio.quantile(.75), ru50=A_tr.PorePressureRatio.quantile(.5), kh75=A_tr.SeismicCoefficient.quantile(.75), kh50=A_tr.SeismicCoefficient.quantile(.5))
def regime(A):
    wet = A.PorePressureRatio.values >= Q["ru75"]; dry = A.PorePressureRatio.values < Q["ru50"]
    eq = A.SeismicCoefficient.values >= Q["kh75"]; calm = A.SeismicCoefficient.values < Q["kh50"]
    return np.select([wet & eq, wet & calm, eq & dry, dry & calm], ["compound", "rainfall", "seismic", "low-hazard"], "mixed")
def specialist(reg):
    w = TR["w"].copy(); w[:TR["nS"]] *= np.where(regime(A_tr) == reg, 5., 1.); return fit_xgb(TR["A"], dict(TR, w=w), Dv=VA)
SR = cached("spec_rainfall", lambda: specialist("rainfall")); SS = cached("spec_seismic", lambda: specialist("seismic"))
Ar = real_matrix(real)
P = {"GRU": dl_fn(GRUm, SF)(Ar), "M1": dl_fn(M1m, SF)(Ar), "S-R": xgb_pred(SR, Ar[FEATS]), "S-S": xgb_pred(SS, Ar[FEATS])}
fused = np.mean([np.log(np.clip(v, .2, 6)) for v in P.values()], 0)
# ---- real-world layer inputs: 6 properties + physics + Bishop + fused FoS of the four experts
y = real.fail.values; Gp = real.group.values
b, pp_ = np.radians(np.clip(real.SlopeAngle_deg, 1, 89)), np.radians(real.FrictionAngle_deg)
H, g, c, ru = real.SlopeHeight_m, real.UnitWeight_kN_m3, real.Cohesion_kPa, real.PorePressureRatio
BIS = np.array([bishop_fos(r.SlopeHeight_m, r.SlopeAngle_deg, r.Cohesion_kPa, r.FrictionAngle_deg, r.UnitWeight_kN_m3, r.PorePressureRatio) for r in real.itertuples()])
X = np.c_[real[F6].values, c / (g * H), np.tan(pp_) / np.tan(b), np.clip(c / (g * H * np.sin(b) * np.cos(b)) + (1 - ru) * np.tan(pp_) / np.tan(b), 0, 50),
          np.log1p(g * H * np.tan(pp_) / (c + .1)), np.log(H), np.tan(pp_) * (1 - ru), np.log(np.clip(BIS, .05, 50)), fused].astype(float)
class Vote:
    def fit(s, X_, y_):
        s.m = [CatBoostClassifier(iterations=500, depth=4, learning_rate=.05, l2_leaf_reg=3, verbose=0, random_seed=RS).fit(X_, y_),
               lgb2.LGBMClassifier(n_estimators=300, num_leaves=15, learning_rate=.05, subsample=.8, subsample_freq=1, colsample_bytree=.8,
                                   min_child_samples=10, verbose=-1, random_state=RS).fit(X_, y_)]; return s
    def predict_proba(s, X_): return np.mean([m.predict_proba(X_) for m in s.m], 0)
def run(seed):
    prob, cut = np.zeros(len(y)), np.zeros(len(y))
    for a, bb in SGK(5, shuffle=True, random_state=seed).split(X, y, Gp):
        po = np.zeros(len(a))
        for ia, ib in SGK(3, shuffle=True, random_state=seed + 50).split(a, y[a], Gp[a]): po[ib] = Vote().fit(X[a][ia], y[a][ia]).predict_proba(X[a][ib])[:, 1]
        conf_ = np.abs(po - .5); c0 = conf_.max()
        for cc in np.sort(np.unique(conf_)):
            m = conf_ >= cc
            if m.sum() >= 10 and accuracy_score(y[a][m], po[m] > .5) >= .93: c0 = cc; break
        prob[bb] = Vote().fit(X[a], y[a]).predict_proba(X[bb])[:, 1]; cut[bb] = c0
    return prob, cut
RUNS = {sd: cached(f"conf_run_{sd}", lambda sd=sd: run(sd)) for sd in (11, 12, 13, 14, 15)}
prob, cut = RUNS[11]
conf = np.abs(prob - .5) >= cut
T = real[["location"] + F6].copy(); T["observed"] = np.where(y == 1, "Failure", "Stable"); T["P_failure"] = prob.round(3)
T["predicted"] = np.where(prob > .5, "Failure", "Stable"); T["correct"] = T.observed == T.predicted; T["confident_verdict"] = conf
C = T[T.confident_verdict].sort_values(["correct", "location"], ascending=[False, True])
C.to_csv(OUTR + "T17_confident_real_slopes_k4.csv", index=False)
# ---- stability over 5 repeats (different fold assignments)
rows, cnt, cor = [], np.zeros(len(y)), np.zeros(len(y))
for sd, (pr, ct) in RUNS.items():
    cf = np.abs(pr - .5) >= ct; ok = (pr > .5) == (y == 1); cnt += cf; cor += cf & ok
    nm = cf & (real.location.values != "Unknown")
    rows.append(dict(seed=sd, confident_n=int(cf.sum()), coverage_pct=cf.mean() * 100, accuracy_confident=ok[cf].mean(), named_confident_n=int(nm.sum()),
                     accuracy_named_confident=ok[nm].mean(), accuracy_all=ok.mean()))
RS5 = pd.DataFrame(rows); summ = RS5.drop(columns="seed").agg(["mean", "std"]); RS5 = pd.concat([RS5, summ.reset_index().rename(columns={"index": "seed"})])
RS5.round(4).to_csv(OUTR + "T18_confident_slopes_5_repeats.csv", index=False); say("\n" + RS5.round(3).to_string())
T["times_confident_of_5"] = cnt.astype(int); T["times_correct_when_confident"] = cor.astype(int)
ST = T[cnt >= 3].copy(); ST["accuracy_when_confident"] = (ST.times_correct_when_confident / ST.times_confident_of_5).round(3)
ST.sort_values(["location", "times_confident_of_5"], ascending=[True, False]).to_csv(OUTR + "T19_slopes_confident_in_3plus_of_5_repeats.csv", index=False)
say(f"slopes confident in >=3/5 repeats: {len(ST)} (named {(ST.location != 'Unknown').sum()}); verdict accuracy on them "
    f"{ST.times_correct_when_confident.sum() / ST.times_confident_of_5.sum() * 100:.1f}%")
say(f"confident slopes: {conf.sum()} of {len(y)} ({conf.mean()*100:.1f}%), accuracy {C.correct.mean()*100:.1f}% "
    f"| all slopes {T.correct.mean()*100:.1f}% | named confident slopes {(C.location != 'Unknown').sum()}"); say("DONE")
