"""Exhaustive search of all C(20,3)=1140 three-model combinations (fast LightGBM real-world layer), nested selection,
and fresh-split re-test (all slopes + confident-only) of the top 10."""
import numpy as np, pandas as pd, itertools, joblib, os, warnings
warnings.filterwarnings("ignore")
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realpush.py")).read().split("FOLDS = [list(")[0])
EX = list(E.columns); COMBOS = list(itertools.combinations(EX, 3)); print("combinations:", len(COMBOS), flush=True)
fast = lambda: lgb.LGBMClassifier(n_estimators=150, num_leaves=15, learning_rate=.08, subsample=.8, subsample_freq=1, colsample_bytree=.8, min_child_samples=10, verbose=-1, random_state=RS)
XS = {c: np.c_[A.values, E[list(c)].mean(1).values] for c in COMBOS}
F0 = list(StratifiedGroupKFold(5, shuffle=True, random_state=0).split(A, y, G))
f = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptR/exh3.joblib")
os.makedirs(os.path.dirname(f), exist_ok=True)
if os.path.exists(f): S = joblib.load(f)
else:
    S = {}
    for i, c in enumerate(COMBOS):
        pp = np.zeros(len(y))
        for a, b_ in F0: pp[b_] = fast().fit(XS[c][a], y[a]).predict_proba(XS[c][b_])[:, 1]
        S[c] = accuracy_score(y, pp > .5)
        if i % 200 == 0: print(f"  {i}/{len(COMBOS)} best so far {max(S.values()):.3f}", flush=True)
    joblib.dump(S, f)
s = pd.Series(S); print(f"single-split accuracy over 1140 combos: min {s.min():.3f} median {s.median():.3f} max {s.max():.3f}", flush=True)
# nested: choose the combination inside outer-training folds only (2 repeats)
acc_n = []
for rep in (21, 22):
    pp = np.zeros(len(y))
    for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=rep).split(A, y, G):
        inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=rep).split(a, y[a], G[a])); best, bs = None, -1
        for c in COMBOS:
            X = XS[c][a]; v = np.mean([accuracy_score(y[a][ib], fast().fit(X[ia], y[a][ia]).predict(X[ib])) for ia, ib in inner])
            if v > bs: best, bs = c, v
        pp[b_] = fast().fit(XS[best][a], y[a]).predict_proba(XS[best][b_])[:, 1]
    acc_n.append(accuracy_score(y, pp > .5)); print(f"  nested repeat: {acc_n[-1]:.3f}", flush=True)
# top-10 on fresh splits with the strong layer, all slopes + confident-only (nested cut-off)
L = "Vote(CatBoost+LightGBM)"; rows = []
for c in s.sort_values(ascending=False).index[:10]:
    X = XS[c]; acc, cov, accc = [], [], []
    for rep in (31, 32):
        pp, cut = np.zeros(len(y)), np.zeros(len(y))
        for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=rep).split(X, y, G):
            po = np.zeros(len(a))
            for ia, ib in StratifiedGroupKFold(3, shuffle=True, random_state=rep + 7).split(a, y[a], G[a]): po[ib] = LEARN[L]().fit(X[a][ia], y[a][ia]).predict_proba(X[a][ib])[:, 1]
            conf = np.abs(po - .5); c0 = conf.max()
            for cc in np.sort(np.unique(conf)):
                m = conf >= cc
                if m.sum() >= 10 and accuracy_score(y[a][m], po[m] > .5) >= .93: c0 = cc; break
            pp[b_] = LEARN[L]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]; cut[b_] = c0
        m = np.abs(pp - .5) >= cut; acc.append(accuracy_score(y, pp > .5)); cov.append(m.mean() * 100); accc.append(accuracy_score(y[m], pp[m] > .5))
    rows.append(dict(members=" | ".join(c), search_accuracy=S[c], fresh_accuracy_all=np.mean(acc), confident_coverage_pct=np.mean(cov), fresh_accuracy_confident=np.mean(accc)))
    print(rows[-1], flush=True)
T = pd.DataFrame(rows); T.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T14_exhaustive_k3_top10_fresh.csv"), index=False)
s.sort_values(ascending=False).rename("accuracy").to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T15_exhaustive_k3_all1140.csv"))
pd.Series(dict(nested_accuracy=np.mean(acc_n), search_min=s.min(), search_median=s.median(), search_max=s.max())).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T16_exhaustive_k3_summary.csv"))
print("DONE", flush=True)
