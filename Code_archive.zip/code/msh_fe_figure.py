"""Finite-element check figure: FE-SRM vs Bishop, calibrated equation vs FE, interaction index, Tandikat FE mechanism."""
import os, sys, json, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fe_layered import Layered
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/figures_manuscript/"; FE = ROOT + "/fe_results/"
plt.rcParams.update({"font.family": "Inter", "font.size": 8.2, "axes.titleweight": "semibold", "axes.titlesize": 8.8, "axes.titlelocation": "left",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#BDB6A8", "axes.grid": True, "grid.color": "#E6E1D8", "grid.linewidth": .5, "pdf.fonttype": 42, "legend.frameon": False})
INK2 = "#555B61"; FOREST, STEEL, COPPER, GRAPH = "#2F6B3A", "#4A7BA6", "#B5573B", "#3A3D42"
D = pd.read_csv(FE + "FE1_fe_vs_bishop_runs.csv"); T = pd.read_csv(FE + "FE2_comparison.csv"); I4 = pd.read_csv(FE + "FE4_interaction_FE_vs_Bishop.csv")
p = json.load(open(ROOT + "/calibrated_equation/C2_calibrated_parameters.json"))["lambda-dependent a,b,c"]
lam = D.c / (D.gamma * D.H * np.tan(np.radians(D.phi))); tb = np.tan(np.radians(D.beta))
F0 = D.set_index(["slope", "ru", "kh"]).FoS_FE.xs((0.0, 0.0), level=["ru", "kh"]); D["F0"] = D.slope.map(F0)
D["Feq"] = D.F0 * np.clip(1 - p[0] / (1 + p[1] * lam) * D.ru - p[2] / (1 + p[3] * lam) * D.kh * tb, 1e-3, None) / (1 + p[4] * (1 + p[5] * lam) * D.kh / tb)
f = plt.figure(figsize=(10.6, 7.4)); gs = f.add_gridspec(2, 3, height_ratios=[1, 1.1], hspace=.36, wspace=.34)
ax = [f.add_subplot(gs[0, i]) for i in range(3)] + [f.add_subplot(gs[1, :])]
grp = lambda d: np.where((d.ru == 0) & (d.kh == 0), "static", np.where(d.kh == 0, "pore pressure only", np.where(d.ru == 0, "seismic only", "combined")))
D["grp"] = grp(D); sty = {"static": (GRAPH, "o"), "pore pressure only": (STEEL, "s"), "seismic only": (COPPER, "^"), "combined": (FOREST, "D")}
d = D.dropna(subset=["FoS_FE"])
for g, (c, mk) in sty.items():
    e = d[d.grp == g]; ax[0].scatter(e.FoS_FE, e.FoS_Bishop, s=16, color=c, marker=mk, alpha=.8, lw=0, label=g)
    ax[1].scatter(e.FoS_FE, e.Feq, s=16, color=c, marker=mk, alpha=.8, lw=0)
for a_, ttl, yl, row in [(ax[0], "(a) Bishop vs finite elements", "Pseudo-static Bishop FoS", 0), (ax[1], "(b) Calibrated equation vs FE", "Calibrated equation FoS", 2)]:
    a_.plot([0, 3.2], [0, 3.2], "--", color=INK2, lw=.8); a_.set(xlim=(0.3, 3.2), ylim=(0.3, 3.2), xlabel="FE strength-reduction FoS", ylabel=yl, title=ttl)
    r = T.iloc[row]; a_.text(.04, .96, f"$R^2$ = {r.R2:.3f}\nMAPE = {r.MAPE_pct:.1f} %", transform=a_.transAxes, va="top", fontsize=7.4)
ax[0].legend(fontsize=6.8, loc="lower right", markerscale=1.2)
for meth, c, mk, ls in [("Bishop", GRAPH, "o", "--"), ("FE", FOREST, "s", "-")]:
    e = I4[I4.method == meth]; lab = [f"{a:g}/{b:g}" for a, b in zip(e.ru, e.kh)]
    ax[2].plot(range(len(e)), e.median_I, ls, marker=mk, color=c, ms=5, mfc="white" if meth == "Bishop" else c, label=meth)
ax[2].set_xticks(range(4), lab); ax[2].set(xlabel="$r_u$ / $k_h$", ylabel="Median interaction index $I$", title="(c) Interaction index, 16 slopes"); ax[2].axhline(1, color=INK2, lw=.7, ls=":"); ax[2].legend(fontsize=7)
# Tandikat mechanism
md = Layered(); T3 = pd.read_csv(FE + "FE3_Tandikat_layered.csv"); fos = T3[(T3.state == "rainfall + shaking") & T3.mesh.str.startswith("standard")].FoS_FE.iloc[0]
ok, it, u = md.solve(0.151, 0.14, fos + 0.04, itmax=600); ok2, it2, u0 = md.solve(0.151, 0.14, fos - 0.04, itmax=600)
du = u - u0; U = np.hypot(du[0::2], du[1::2])          # incremental displacement across the failure SRF = mechanism; polys = [md.coords[e[[0, 1, 2, 3, 4, 5, 6, 7]]][[0, 1, 2, 3, 4, 5, 6, 7]] for e in md.els]
polys = [md.coords[e][[0, 1, 2, 3, 4, 5, 6, 7]] for e in md.els]
val = np.array([U[e].mean() for e in md.els]); val = val / val.max()
pc = PolyCollection(polys, array=val, cmap="YlGn", edgecolors="#9A9A9A", linewidths=.15); ax[3].add_collection(pc)
lay = md.lay; ax[3].add_collection(PolyCollection([polys[i] for i in np.where(lay)[0]], facecolors="none", edgecolors="#7A5A2A", linewidths=.25))
ax[3].set_xlim(md.coords[:, 0].min(), md.coords[:, 0].max()); ax[3].set_ylim(-8, md.coords[:, 1].max() + 3); ax[3].set_aspect(.9); ax[3].grid(False)
cb = f.colorbar(pc, ax=ax[3], fraction=.02, pad=.01); cb.set_label("Normalised incremental displacement", fontsize=7); cb.ax.tick_params(labelsize=6.5)
ax[3].set(xlabel="x (m)", ylabel="y (m)", title=f"(d) Tandikat FE model: failure mechanism under rainfall + shaking (FE FoS = {fos:.2f}); 3 m pumice over stiff clay")
for e_ in ("png", "pdf"): f.savefig(OUT + "Fig_FE_check." + e_, dpi=600 if e_ == "png" else None, bbox_inches="tight", facecolor="white")
print("saved")
