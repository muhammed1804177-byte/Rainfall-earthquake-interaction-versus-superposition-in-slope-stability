"""Fig. 1 (manuscript): framework of the study, drawn in the Strata identity (msh_style.py). Vector PDF + 600 dpi PNG.
Layout follows the authors' sketch: input -> 20 models -> progressive 3..20 combinations -> selection (top row, left to right),
then mechanics anchoring -> validation -> final outputs (bottom row, right to left)."""
import os, sys
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_style as S
S.apply(); plt.rcParams["axes.grid"] = False
R = os.environ.get("MSH_OUT", os.path.dirname(HERE)) + "/"; OUT = R + "figures_final/"
INK, INK2 = S.INK, S.INK2
def tint(hexc, a):                                     # mix a colour with white
    import matplotlib.colors as mc; r, g, b = mc.to_rgb(hexc); return (1 - a + a * r, 1 - a + a * g, 1 - a + a * b)
fig = plt.figure(figsize=(7.48, 5.25)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 190); ax.set_ylim(0, 133); ax.axis("off")
def panel(x, y, w, h, title, edge, head=None, hh=9, tsize=8.2, lw=1.0):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=2.2", fc="white", ec=edge, lw=lw, zorder=1))
    ax.add_patch(FancyBboxPatch((x, y + h - hh), w, hh, boxstyle="round,pad=0,rounding_size=2.2", fc=head or tint(edge, .16), ec="none", zorder=2))
    ax.add_patch(plt.Rectangle((x + .4, y + h - hh), w - .8, 2.5, fc=head or tint(edge, .16), ec="none", zorder=2))
    ax.plot([x, x + w], [y + h - hh, y + h - hh], color=edge, lw=.6, zorder=3)
    ax.text(x + w / 2, y + h - hh / 2, title, ha="center", va="center", fontsize=tsize, fontweight="semibold", color=INK, zorder=4)
def chip(x, y, w, h, txt, fc, size=5.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.0", fc=fc, ec="none", zorder=3))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=size, color=S.text_on(fc), zorder=4)
def arrow(x1, y1, x2, y2, c=INK2):
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="-|>,head_width=.25,head_length=.5", color=c, lw=1.0, shrinkA=0, shrinkB=0), zorder=5)
def txt(x, y, s, size=6.4, c=INK2, **k): ax.text(x, y, s, fontsize=size, color=c, va="top", zorder=4, **k)

# ---------------- 1 input data
panel(3, 62, 42, 62, "Input data", S.STONE)
txt(6, 112, "Kaggle dataset: 120,000 slopes", 6.2, INK)
txt(6, 107.5, "train 84k · validation 9k ·\ncalibration 9k · test 18k (used once)", 5.7)
txt(6, 98.5, "Inputs: H, β, c, φ, γ, rᵤ, kₕ,\nrainfall, groundwater, weathering", 5.7)
txt(6, 89.5, "Loading conditions", 6.2, INK)
for i, (lab, c) in enumerate((("Rainfall-dominated (rᵤ ↑)", S.LAGOON), ("Seismic-dominated (kₕ ↑)", S.PLUM), ("Combined rainfall–seismic", S.OCHRE))):
    yy = 84.2 - i * 5.6; ax.add_patch(Circle((8, yy), 1.35, fc=c, ec="none", zorder=4)); ax.text(11.3, yy, lab, fontsize=5.9, va="center", color=INK2, zorder=4)
ax.plot([6, 42], [67.4 + 1.6, 67.4 + 1.6], color=S.GRID, lw=.6)
txt(6, 67.6, "Mechanics benchmark: 20,000 slopes,\npseudo-static Bishop (checked vs M–P)", 5.4)

# ---------------- 2 twenty models
panel(50, 62, 50, 62, "20 individual ML/DL models", S.BASALT, head=tint(S.BASALT, .10))
ML, DL, HY = "#D6D1C7", "#8E897F", "#4A5158"
names = [("XGBoost", ML), ("LightGBM", ML), ("Random Forest", ML), ("DNN", DL), ("1D-CNN", DL), ("LSTM", DL), ("GRU", DL), ("LSTM-GRU-DNN", DL),
         ("M1 CNN-BiLSTM", HY), ("M2 PG-CNN-DNN", HY), ("M3 CNN-Trans.", HY), ("M4 CNN-LSTM", HY), ("N1 PLE-ResNet", HY), ("N2 XGB-Res", HY),
         ("CNN-XGB", HY), ("LGD-XGB", HY), ("DNN-emb-XGB", HY), ("Rainfall", S.LAGOON), ("Seismic", S.PLUM), ("Compound", S.OCHRE)]
cw, chh, gx, gy = 15.3, 4.4, .75, 1.0
for i, (n, c) in enumerate(names):
    r_, k_ = divmod(i, 3); chip(51.6 + k_ * (cw + gx), 108.6 - r_ * (chh + gy), cw, chh, n, c, size=4.85)
for i, (lab, c) in enumerate((("Advanced ML", ML), ("Deep learning", DL), ("Hybrid DL", HY), ("Hazard specialists", S.OCHRE))):
    xx = 52.5 + (i % 2) * 24; yy = 71.0 - (i // 2) * 4.2
    if lab == "Hazard specialists":
        for j, cc in enumerate((S.LAGOON, S.PLUM, S.OCHRE)): ax.add_patch(plt.Rectangle((xx + j * 1.25, yy - 1.1), 1.25, 2.2, fc=cc, ec="none", zorder=4))
        ax.text(xx + 4.6, yy, lab, fontsize=5.6, va="center", color=INK2)
    else:
        ax.add_patch(plt.Rectangle((xx, yy - 1.1), 3.75, 2.2, fc=c, ec="none", zorder=4)); ax.text(xx + 4.6, yy, lab, fontsize=5.6, va="center", color=INK2)

# ---------------- 3 progressive combinations
panel(105, 62, 52, 62, "Progressive model combinations", S.TERRACOTTA)
stages = [("3-model combinations", "all subsets scored on validation"), ("4-model combinations", "cross-fitted meta-learners"),
          ("5-model combinations", "hazard-aware attention fusion"), ("20-model combination", "L = data + physics + interaction")]
ys = [104.5, 92, 79.5, 64.5]
for (t1, t2), yy in zip(stages, ys):
    ax.add_patch(FancyBboxPatch((109, yy), 38, 9.2, boxstyle="round,pad=0,rounding_size=1.4", fc=tint(S.TERRACOTTA, .06), ec=tint(S.TERRACOTTA, .55), lw=.7, zorder=3))
    ax.text(128, yy + 6.2, t1, ha="center", va="center", fontsize=6.4, fontweight="semibold", color=INK, zorder=4); ax.text(128, yy + 2.6, t2, ha="center", va="center", fontsize=5.4, color=INK2, zorder=4)
for a, b in ((104.5, 101.2), (92, 88.7)): arrow(128, a, 128, b)
[ax.add_patch(Circle((128, yy_), .45, fc=INK2, ec="none", zorder=4)) for yy_ in (78.0, 76.6, 75.2)]; arrow(128, 74.4, 128, 73.7)
# bracket
bx = 149.5; ax.plot([bx, bx + 1.6, bx + 1.6, bx], [113.7, 113.7, 64.5, 64.5], color=INK2, lw=.9); ax.plot([bx + 1.6, bx + 3], [89, 89], color=INK2, lw=.9)

# ---------------- 4 selection
ax.add_patch(FancyBboxPatch((159.5, 70), 28, 38, boxstyle="round,pad=0,rounding_size=2.2", fc=tint(S.TERRACOTTA, .10), ec=S.TERRACOTTA, lw=1.0, zorder=1))
ax.text(173.5, 101.5, "Select on\nvalidation", ha="center", va="center", fontsize=7.2, fontweight="semibold", color=INK, zorder=4, linespacing=1.15)
txt(162, 95.5, "Best hybrid:\nCNN–XGBoost +\nLSTM–GRU–DNN–\nXGBoost + RF,\nattention fusion\n\nNo gain beyond\n~3 experts", 5.6, INK2, linespacing=1.25)
arrow(152.6, 89, 159.3, 89)

# ---------------- 5 mechanics anchoring (bottom right)
panel(105, 6, 82, 50, "Mechanics anchoring and guards", S.BASALT, head=tint(S.BASALT, .10))
txt(108.5, 44.5, "Data branch (selected hybrid)  ×  mechanics branch:", 6.0, INK)
txt(108.5, 39.5, "Bishop surrogate prior × monotone hydrological calibration\n(rainfall −, groundwater depth +, rise rate −, weathering −)", 5.6)
ax.add_patch(FancyBboxPatch((108.5, 21.5), 75, 9.5, boxstyle="round,pad=0,rounding_size=1.4", fc=tint(S.TERRACOTTA, .12), ec=S.TERRACOTTA, lw=.9, zorder=3))
ax.text(146, 28.6, "log F = w·log F_data + (1 − w)·log F_mech", ha="center", va="center", fontsize=6.6, fontweight="semibold", color=INK, zorder=4)
ax.text(146, 24.2, "w = 0.325: smallest weight with validation R² ≥ 0.93", ha="center", va="center", fontsize=5.6, color=INK2, zorder=4)
txt(108.5, 18.3, "Monotone envelope on kₕ and rᵤ  ·  conformal intervals per regime\nApplicability-domain gate  ·  sensitivity audit against Bishop", 5.6)
arrow(173.5, 70, 173.5, 56.2)

# ---------------- 6 validation (bottom middle)
panel(50, 6, 50, 50, "Validation", S.STONE)
for i, (h_, b_) in enumerate((("Test set, 18,000 slopes", "used once; R² 0.934, 88.1 % accuracy"), ("rᵤ × kₕ factorial, 500 slopes", "12,500 direct Bishop solutions"),
                               ("363 real case histories", "grouped CV; calibrated P(failure)"), ("Tandikat 2009 landslide", "earthquake during rainfall"))):
    yy = 44.2 - i * 9.4; ax.add_patch(Circle((54, yy - 1.4), .9, fc=S.STONE, ec="none", zorder=4))
    ax.text(56.5, yy - 1.4, h_, fontsize=6.0, color=INK, va="center", fontweight="semibold", zorder=4); ax.text(56.5, yy - 5.0, b_, fontsize=5.5, color=INK2, va="center", zorder=4)
arrow(104.8, 31, 100.2, 31)

# ---------------- 7 final outputs (bottom left)
panel(3, 6, 42, 50, "Final prediction", S.TERRACOTTA)
outs = [("FoS and stability class", "dataset and mechanics scales"), ("Interval and verdict", "confident class or 'investigate'"),
        ("Interaction quantified", "index I, compound-only failures"), ("Reliability", "Pf, β and yield coefficient k$_y$")]
for i, (h_, b_) in enumerate(outs):
    yy = 44.2 - i * 9.4; ax.add_patch(Circle((7, yy - 1.4), .9, fc=S.TERRACOTTA, ec="none", zorder=4))
    ax.text(9.5, yy - 1.4, h_, fontsize=6.0, color=INK, va="center", fontweight="semibold", zorder=4); ax.text(9.5, yy - 5.0, b_, fontsize=5.5, color=INK2, va="center", zorder=4)
arrow(49.8, 31, 45.2, 31)
# top-row arrows
arrow(45, 93, 49.8, 93); arrow(100, 93, 104.8, 93)
ax.text(95, 130.3, "", fontsize=1)
fig.savefig(OUT + "Fig01_framework_journal.pdf", bbox_inches="tight", pad_inches=.03); fig.savefig(OUT + "Fig01_framework_journal.png", dpi=600, bbox_inches="tight", pad_inches=.03)
print("done")
