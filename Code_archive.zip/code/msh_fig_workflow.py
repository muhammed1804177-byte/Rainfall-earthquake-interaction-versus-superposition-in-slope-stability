"""Graphical workflow of the study (journal figure). All text inside boxes; blue-teal-purple palette.
Output: figures_final/Fig00_study_workflow.{png,pdf,svg}"""
import os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family": "Inter", "svg.fonttype": "none", "pdf.fonttype": 42})
R = os.environ.get("MSH_OUT", os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/figures_final/"
NAVY, TEAL, PURP, BLUE = "#1F3B73", "#1D7A72", "#4A3F9F", "#2F6FC0"
H_BLUE, H_TEAL, H_PURP = "#D7E6FA", "#CDEFEA", "#E4E1FA"; B_BLUE, B_TEAL, B_PURP = "#F4F8FE", "#F2FBF9", "#F6F5FE"
INK, INK2 = "#13284D", "#2E3F5C"
CHIP = ["#2E8C99", "#5B8FD6", "#45B3B8", "#7C6FD8", "#3E9C93", "#6C7FE0", "#5A9BD3", "#6A5ACD", "#7A63D6", "#3F86D4", "#7B6BDA", "#3FA39A",
        "#3E9C93", "#6E7BE0", "#7C6FD8", "#5B6FD6", "#8063D6", "#3FA39A", "#3F86D4", "#7C6FD8"]
MODELS = ["XGBoost", "LightGBM", "RF", "DNN", "1D-CNN", "LSTM", "GRU", "LGD", "M1", "M2", "M3", "M4",
          "N1", "N2", "CNN-XGB", "LGD-XGB", "DNN-XGB", "S-Rain", "S-Seismic", "S-Comp."]
fig, ax = plt.subplots(figsize=(15, 9.6)); ax.set_xlim(0, 15); ax.set_ylim(0, 9.6); ax.axis("off")
def panel(x, y, w, h, head, edge, hfill, bfill, hh=.62, fs=15.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=.14", fc=bfill, ec=edge, lw=2.2, zorder=1))
    ax.add_patch(FancyBboxPatch((x + .02, y + h - hh), w - .04, hh - .02, boxstyle="round,pad=0,rounding_size=.12", fc=hfill, ec="none", zorder=2))
    ax.add_patch(plt.Rectangle((x + .02, y + h - hh), w - .04, hh / 2, fc=hfill, ec="none", zorder=2))
    ax.text(x + w / 2, y + h - hh / 2, head, ha="center", va="center", fontsize=fs, fontweight="bold", color=INK, zorder=3, linespacing=1.1)
def sub(x, y, w, h, t1, t2=None, edge=PURP, fill="#ECEAFD"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=.1", fc=fill, ec=edge, lw=1.3, alpha=1, zorder=3))
    if t2: ax.text(x + w / 2, y + h * .62, t1, ha="center", va="center", fontsize=11.2, fontweight="bold", color=INK, zorder=4); ax.text(x + w / 2, y + h * .28, t2, ha="center", va="center", fontsize=9.6, color=INK2, zorder=4)
    else: ax.text(x + w / 2, y + h / 2, t1, ha="center", va="center", fontsize=11, fontweight="bold", color=INK, zorder=4, linespacing=1.25)
def arrow(x1, y1, x2, y2):
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="-|>,head_length=.55,head_width=.3", color=NAVY, lw=2.2, shrinkA=0, shrinkB=0), zorder=5)
# 1 input data
panel(.25, 5.05, 3.55, 3.6, "Input data", NAVY, H_BLUE, B_BLUE)
ax.text(.5, 7.62, "120,000 slopes; 11 geotechnical,\nhydrological and seismic inputs", fontsize=10.6, color=INK2, va="center", linespacing=1.35, zorder=3)
for i, (lab, c) in enumerate((("Rainfall-dominated", TEAL), ("Seismic-dominated", BLUE), ("Combined rainfall–seismic", PURP))):
    yy = 6.95 - i * .53; ax.scatter([.68], [yy], s=170, color=c, zorder=4, edgecolor="white", lw=1); ax.text(.95, yy, lab, fontsize=11.6, va="center", color=INK, zorder=4)
ax.text(.5, 5.33, "leakage-free split 84k / 9k / 9k / 18k", fontsize=9.6, color=INK2, va="center", style="italic", zorder=3)
# 2 twenty models
panel(4.3, 4.6, 4.15, 4.5, "20 individual\nML / DL models", TEAL, H_TEAL, B_TEAL, hh=1.0)
ax.add_patch(FancyBboxPatch((4.5, 4.78), 3.75, 3.1, boxstyle="round,pad=0,rounding_size=.1", fc="white", ec="#A9DCD5", lw=1.3, zorder=2))
for k, (m, c) in enumerate(zip(MODELS, CHIP)):
    r, q = divmod(k, 4); x0, y0 = 4.6 + q * .91, 7.28 - r * .58
    ax.add_patch(FancyBboxPatch((x0, y0), .84, .42, boxstyle="round,pad=0,rounding_size=.07", fc=c, ec="none", zorder=3))
    ax.text(x0 + .42, y0 + .21, m, ha="center", va="center", fontsize=8.4 if len(m) > 7 else 9.2, fontweight="semibold", color="white", zorder=4)
# 3 progressive combinations
panel(8.95, 3.55, 4.15, 5.75, "Progressive hybridisation", PURP, H_PURP, B_PURP)
for i, (a, b) in enumerate((("3-expert combinations", "all subsets, validation only"), ("4-expert combinations", "all subsets, validation only"), ("5-expert combinations", "all subsets, validation only"))):
    sub(9.25, 7.62 - i * 1.13, 3.55, .82, a, b)
    if i < 2: arrow(11.02, 7.62 - i * 1.13, 11.02, 7.62 - (i + 1) * 1.13 + .82 + .02)
for d in range(3): ax.scatter([11.02], [5.18 - d * .2], s=16, color=PURP, zorder=4)
arrow(11.02, 4.6, 11.02, 4.47); sub(9.25, 3.72, 3.55, .75, "20-expert combination", "all experts")
# 4 fusion selection
panel(13.4, 5.0, 1.38, 3.2, "Select", TEAL, H_TEAL, B_TEAL, fs=13)
ax.text(14.09, 6.3, "hazard-\naware\nattention\nfusion\n\nbest\nhybrid", ha="center", va="center", fontsize=10.4, color=INK, fontweight="semibold", linespacing=1.25, zorder=3)
# 5 mechanics anchoring
panel(9.35, .45, 5.4, 2.55, "Mechanics-anchored final model", NAVY, H_BLUE, B_BLUE, fs=14.5)
sub(9.6, 1.45, 2.35, .85, "Data branch", "best hybrid", edge=TEAL, fill="#E3F5F2"); sub(12.15, 1.45, 2.35, .85, "Mechanics branch", "Bishop + hydrology", edge=BLUE, fill="#E5EEFB")
ax.text(12.05, .82, "log-space blend · monotone envelope · conformal intervals", ha="center", va="center", fontsize=9.8, color=INK2, zorder=3)
# 6 validation
panel(4.3, .45, 4.55, 2.55, "Validation", NAVY, H_BLUE, B_BLUE, fs=14.5)
for i, t in enumerate(("18,000 unseen test slopes", "19,128 Morgenstern–Price solutions", "363 real slope-failure cases")):
    ax.text(4.6, 2.05 - i * .5, "●", fontsize=11, color=(TEAL, BLUE, PURP)[i], va="center", zorder=3); ax.text(4.9, 2.05 - i * .5, t, fontsize=11.2, color=INK, va="center", zorder=3)
# 7 outputs
panel(.25, .45, 3.55, 2.55, "Final outputs", TEAL, H_TEAL, B_TEAL, fs=14.5)
for i, t in enumerate(("FoS and stability class", "Failure probability", "Rainfall–seismic interaction")):
    ax.text(.55, 2.05 - i * .5, "●", fontsize=11, color=(TEAL, BLUE, PURP)[i], va="center", zorder=3); ax.text(.85, 2.05 - i * .5, t, fontsize=11.2, color=INK, va="center", zorder=3)
# arrows between panels
arrow(3.8, 6.85, 4.28, 6.85); arrow(8.45, 6.85, 8.93, 6.85)
ax.plot([13.1, 13.25, 13.25], [8.0, 8.0, 6.6], color=NAVY, lw=2.2, zorder=5); ax.plot([13.1, 13.25], [4.1, 4.1], color=NAVY, lw=2.2, zorder=5); ax.plot([13.25, 13.25], [4.1, 6.6], color=NAVY, lw=2.2, zorder=5)
arrow(13.25, 6.6, 13.38, 6.6)
ax.plot([14.09, 14.09], [5.0, 3.25], color=NAVY, lw=2.2, zorder=5); arrow(14.09, 3.25, 14.09, 3.02)
arrow(9.35, 1.72, 8.87, 1.72); arrow(4.3, 1.72, 3.82, 1.72)
os.makedirs(R, exist_ok=True)
for ext in ("png", "pdf", "svg"): plt.savefig(R + "Fig00_study_workflow." + ext, dpi=600 if ext == "png" else None, bbox_inches="tight", facecolor="white")
print("saved")
