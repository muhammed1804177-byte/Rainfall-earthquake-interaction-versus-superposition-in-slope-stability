"""Manuscript figure set (300 dpi PNG + vector PDF) in the "Strata" visual identity (see msh_style.py).
Built ONLY from the saved result tables (no model is retrained here). One colour per role in every figure:
  proposed framework = terracotta | rainfall = lagoon | seismic = plum | compound = ochre
  mechanics reference (Bishop / Morgenstern-Price) = basalt, dashed or hollow | other models = stone | neutral = sand
Identity never relies on colour alone: legends, direct labels, line styles, markers and hatching are used.
Run:  MSH_OUT=/mnt/user-data/outputs python3 code/msh_figures.py"""
import os, sys, json, glob, traceback
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch
from matplotlib.lines import Line2D
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_style as S
S.apply()
R = os.environ.get("MSH_OUT", os.path.dirname(HERE)) + "/"
OUT = R + "figures_final/"; os.makedirs(OUT, exist_ok=True)
for f in glob.glob(OUT + "Fig0*") + glob.glob(OUT + "Fig1*"): os.remove(f)   # Fig20+ come from msh_figures_review.py
DATA = os.environ.get("MSH_DATA", "/mnt/user-data/uploads/1791149933879_Slope_dataset_SVA.csv")
FW, FW2, RAIN, SEIS, COMP, MECH, BASE, NEUT = (S.ROLE[k] for k in ("framework", "framework_alt", "rainfall", "seismic", "compound", "mechanics", "baseline", "neutral"))
done, failed = [], []

def save(n, tight=True):
    if tight: plt.tight_layout()
    plt.savefig(OUT + n + ".png", dpi=300, bbox_inches="tight"); plt.savefig(OUT + n + ".pdf", bbox_inches="tight"); plt.close("all"); done.append(n)
def csv(p, **k): return pd.read_csv(R + p, **k)
def label(ax, x, y, s, **k):
    k.setdefault("fontsize", 7.4); k.setdefault("color", S.INK2); ax.text(x, y, s, **k)
def target(ax, y, s, horizontal=True, **k):
    ax.axhline(y, ls=(0, (4, 3)), color=MECH, lw=.9, zorder=2)
    label(ax, k.get("x", 1), y, s, transform=ax.get_yaxis_transform(), ha="right", va="bottom")
def nobars_grid(ax, axis="y"): ax.grid(axis=axis, visible=False)
def fig(name):
    """decorator: build one figure; a failure is logged and the remaining figures are still produced"""
    def wrap(f):
        try: f(); print("ok  ", name, flush=True)
        except Exception: failed.append(name); plt.close("all"); print("FAIL", name); traceback.print_exc()
        return f
    return wrap

# ------------------------------------------------------------------ Fig 1 framework workflow
@fig("Fig01")
def _():
    f, ax = plt.subplots(figsize=(10, 5.4)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 5.4)
    def box(x, y, w, h, head, body, c):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.06", fc="white", ec=c, lw=1.1))
        ax.add_patch(FancyBboxPatch((x, y + h - .34), w, .34, boxstyle="round,pad=0,rounding_size=0.06", fc=c, ec=c, lw=1.1))
        ax.add_patch(plt.Rectangle((x, y + h - .34), w, .17, fc=c, ec=c, lw=0))
        ax.text(x + .1, y + h - .17, head, ha="left", va="center", fontsize=7.8, fontweight="semibold", color=S.text_on(c))
        ax.text(x + .1, y + h - .45, body, ha="left", va="top", fontsize=7.2, color=S.INK, linespacing=1.35)
    def arr(x1, y1, x2, y2): ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="-|>", color=S.INK2, lw=.9, shrinkA=0, shrinkB=0))
    box(.1, 3.75, 2.3, 1.45, "1  Data", "Kaggle dataset, 120,000 slopes\nphysics-corrected FoS labels\n4 hazard-scenario families", BASE)
    box(.1, 2.0, 2.3, 1.45, "2  Leakage-free protocol", "train 84k | val 9k | calib 9k\ntest 18k (used once)\nselection on validation only", BASE)
    box(.1, .15, 2.3, 1.55, "External validation", "363 real case histories\n(grouped CV, never trained on)\n19,128 Morgenstern-Price runs\n128 rock slopes", RAIN)
    box(2.75, 3.75, 2.35, 1.45, "3  Mechanics layer", "pseudo-static Bishop LEM\nverified vs Morgenstern-Price\nMVB: 20,000 LHS slopes", MECH)
    box(2.75, 1.4, 2.35, 2.05, "4  20 expert models", "trees | MLP | CNN | RNN\nattention / Transformer\nphysics-guided | hybrids\nrainfall / seismic / compound\nspecialists", BASE)
    box(5.45, 3.75, 2.15, 1.45, "5  Progressive fusion", "3 -> 20 experts (validation)\nhazard-aware attention\nL = data + physics + interaction", FW)
    box(5.45, 1.4, 2.15, 2.05, "6  Mechanics anchoring", "Bishop prior × monotone\nhydrological calibration\nlog-space blend, w = 0.325\n(validation R² ≥ 0.93)\nenvelope (kₕ, rᵤ) + conformal", FW)
    box(7.95, 2.6, 1.95, 2.6, "7  Outputs", "FoS and class\nPf and reliability β\n90 / 95 % intervals\nrain × earthquake\ninteraction, k$_y$(rᵤ)\nconfident verdict\nor 'investigate'", COMP)
    box(2.75, .15, 4.85, 1.0, "Audits", "sensitivity audit vs Bishop | leave-one-family-out | strict grouping | cost", RAIN)
    for a in [(1.25, 3.75, 1.25, 3.45), (2.4, 2.7, 2.75, 2.7), (2.4, 4.45, 2.75, 4.45), (5.1, 4.45, 5.45, 4.45), (3.9, 3.75, 3.9, 3.45), (5.1, 2.4, 5.45, 2.4),
              (6.5, 3.75, 6.5, 3.45), (7.6, 3.2, 7.95, 3.6), (2.4, .65, 2.75, .65), (8.9, 1.15, 8.9, 2.6), (7.6, .65, 8.9, .65)]: arr(*a)
    ax.plot([8.9, 8.9], [.65, 1.15], color=S.INK2, lw=.9)
    ax.set_title("Physics-anchored hybrid framework for slope stability under combined rainfall–seismic loading"); save("Fig01_framework_workflow", tight=False)

# ------------------------------------------------------------------ Fig 2 dataset: scenario families
@fig("Fig02")
def _():
    d = pd.read_csv(DATA, usecols=["Rainfall_mm_day", "SeismicCoefficient"]); s = d.sample(15000, random_state=1)
    fam = pd.cut(s.SeismicCoefficient, [-1, .03, .10, .1201, 1], labels=["F1", "F2", "F3", "F4"], right=False)
    cols = S.ramp(S.EARTH_SEQ, 4, .3, .95); names = {"F1": "F1 low hazard", "F2": "F2 moderate", "F3": "F3 elevated", "F4": "F4 extreme compound"}
    f, axs = plt.subplots(1, 2, figsize=(10, 3.9), gridspec_kw=dict(width_ratios=[1.45, 1]))
    ax = axs[0]; ax.axhspan(.1201, .15, color=NEUT, zorder=0); ax.axvspan(160, 180, color=NEUT, zorder=0)
    label(ax, 300, .135, "no slopes in the dataset", ha="right", va="center", style="italic")
    for k, c in zip(names, cols):
        m = fam == k; ax.scatter(s.Rainfall_mm_day[m], s.SeismicCoefficient[m], s=2.5, color=c, lw=0, alpha=.7, rasterized=True, label=names[k])
    ax.set(xlabel="Rainfall (mm/day)", ylabel="Seismic coefficient kₕ", title="(a) Hazard space covered by the 120,000 slopes", xlim=(0, 325), ylim=(0, .305))
    ax.legend(markerscale=4, loc="upper left", handletextpad=.3)
    q = csv("q1_results/QF1_scenario_family_envelopes.csv", header=[0, 1], index_col=0).iloc[:, -2]; y = np.arange(len(q))
    ax = axs[1]; ax.barh(y, q.values, color=cols, height=.62)
    for i, v in enumerate(q.values): label(ax, v + 1.5, i, f"{v:.0f} %", va="center")
    ax.set_yticks(y, [names[n.split()[0]] for n in q.index]); ax.invert_yaxis(); nobars_grid(ax)
    ax.set(xlabel="Slopes with FoS < 1 (%)", title="(b) Failure share per family", xlim=(0, 112)); save("Fig02_dataset_hazard_families")

# ------------------------------------------------------------------ Fig 3 solver verification
@fig("Fig03")
def _():
    t = csv("mechanics_results/M1c_verification_points.csv"); st = csv("mechanics_results/M1_solver_verification_vs_MP.csv", index_col=0).iloc[:, 0]
    b = csv("mechanics_results/M1b_verification_by_kh.csv")
    f, axs = plt.subplots(1, 2, figsize=(9.6, 4), gridspec_kw=dict(width_ratios=[1.25, 1]))
    ax = axs[0]; khs = sorted(t.kh.unique()); cs = S.ramp(S.PLUM_SEQ, len(khs), .3, 1)
    lim = (0, min(6, t[["FoS_MorgensternPrice", "FoS_Bishop_PS"]].quantile(.995).max()))
    ax.plot(lim, lim, color=MECH, lw=1, ls=(0, (4, 3)), zorder=1)
    for k, c in zip(khs, cs):
        m = t.kh == k; ax.scatter(t.FoS_MorgensternPrice[m], t.FoS_Bishop_PS[m], s=6, color=c, lw=0, alpha=.85, label=f"{k:g}", rasterized=True)
    ax.set(xlim=lim, ylim=lim, xlabel="FoS, Morgenstern-Price (independent)", ylabel="FoS, pseudo-static Bishop (this study)", title="(a) 2,000 verification cases")
    ax.legend(title="kₕ", markerscale=2.5, loc="lower right", ncol=2, columnspacing=.6)
    label(ax, .03, .97, f"r = {st.pearson_r:.3f}   R² = {st.R2_vs_MP:.3f}\nmedian ratio {st.median_ratio_Bishop_over_MP:.3f}\n{st.within_10pct:.1f} % within ±10 %\nFoS<1 agreement {st.class_agreement_FoS_lt_1:.1f} %",
          transform=ax.transAxes, va="top", fontsize=7.4, color=S.INK)
    ax = axs[1]; x = np.arange(len(b)); ax.bar(x, b.MAPE_pct_FoS_ge_0_3, color=cs[:len(b)] if len(b) <= len(cs) else PLUM, width=.62)
    for i, v in enumerate(b.MAPE_pct_FoS_ge_0_3): label(ax, i, v + .1, f"{v:.1f}", ha="center", va="bottom")
    ax.set_xticks(x, [f"{k:g}" for k in b.kh]); nobars_grid(ax, "x"); ax.set(xlabel="Seismic coefficient kₕ", ylabel="MAPE vs Morgenstern-Price (%), FoS ≥ 0.3", title="(b) Agreement is uniform across kₕ")
    save("Fig03_solver_verification")

# ------------------------------------------------------------------ Fig 4 progressive hybridisation
@fig("Fig04")
def _():
    a = csv("framework_results/T3_best_per_k_validation.csv"); b = csv("realworld_combinations/T8_accuracy_by_k_LightGBM_layer.csv")
    f, axs = plt.subplots(1, 2, figsize=(10, 3.8))
    ax = axs[0]; ax.plot(a.k, a.average, "-o", color=BASE, ms=4, label="best simple average"); ax.plot(a.k, a.stacking, "-s", color=FW, ms=4, label="best stacking (framework)")
    ax.set(xlabel="Number of experts combined (k)", ylabel="Validation RMSE of FoS", title="(a) FoS prediction, 120,000 slopes"); ax.legend()
    ax = axs[1]; ax.fill_between(b.k, b.worst_acc * 100, b.best_acc * 100, color=FW, alpha=.16, lw=0, label="range over combinations")
    ax.plot(b.k, b.median_acc * 100, "-o", color=FW, ms=4, label="median combination"); target(ax, 93, "93 % target")
    ax.set(xlabel="Number of experts combined (k)", ylabel="Accuracy, 363 real slopes (%)", title="(b) Real slopes, all slopes, grouped CV", ylim=(75, 96)); ax.legend(loc="lower left")
    for x in axs: x.set_xticks(range(3, 21, 2))
    save("Fig04_progressive_hybridisation")

# ------------------------------------------------------------------ Fig 5 model comparison
@fig("Fig05")
def _():
    t = csv("MASTER_FINAL_leakage_free_comparison.csv", index_col=0).sort_values("RMSE").iloc[::-1]
    def short(i):
        if i.startswith("FINAL FRAMEWORK +"): return "Proposed framework + monotone envelope"
        if i.startswith("FINAL FRAMEWORK"): return "Proposed framework (5 seeds)"
        return i.replace("[literature] ", "").replace(" (20k train subset)", "").replace("Gated Mixture of Deep & Boosted Experts", "Gated Mixture of Experts")[:44]
    col = [FW if i.startswith("FINAL") else (MECH if i.startswith("[literature]") else BASE) for i in t.index]
    f, ax = plt.subplots(figsize=(7.4, 6.4)); y = np.arange(len(t))
    ax.barh(y, t.RMSE, color=col, height=.66)
    lo, hi = (t.RMSE - t.RMSE_CI_low).fillna(0).clip(lower=0), (t.RMSE_CI_high - t.RMSE).fillna(0).clip(lower=0)
    ax.errorbar(t.RMSE, y, xerr=[lo, hi], fmt="none", ecolor=S.INK2, lw=.7, capsize=1.5)
    for i, v in enumerate(t.RMSE): label(ax, v + hi.iloc[i] + .0004, i, f"{v:.4f}", va="center", fontsize=6.8)
    ax.set_yticks(y, [short(i) for i in t.index], fontsize=7.2); nobars_grid(ax); ax.set_xlim(.04, t.RMSE.max() * 1.07)
    ax.legend(handles=[Patch(color=FW, label="proposed framework"), Patch(color=BASE, label="expert models (this study)"), Patch(color=MECH, label="literature baselines, same protocol")], loc="center right")
    ax.set(xlabel="Test RMSE of FoS, 18,000 slopes (95 % bootstrap CI)", title="Model comparison on the leakage-free test set"); save("Fig05_model_comparison")

# ------------------------------------------------------------------ Fig 6 uncertainty
@fig("Fig06")
def _():
    t = csv("final_results/T7_uncertainty_with_envelope.csv"); t = t[t.model == t.model.iloc[-1]].reset_index(drop=True)
    f, axs = plt.subplots(1, 2, figsize=(8.6, 3.6)); x = np.arange(len(t))
    ax = axs[0]; ax.bar(x - .2, (1 - t.alpha) * 100, .38, color=NEUT, edgecolor=S.AXIS, lw=.8, label="nominal"); ax.bar(x + .2, t.coverage * 100, .38, color=FW, label="achieved")
    for i, cv in enumerate(t.coverage * 100): label(ax, i + .2, cv + .3, f"{cv:.1f}", ha="center", va="bottom")
    ax.set_xticks(x, [f"{int(round((1-a)*100))} % interval\n(±{h:.3f} FoS)" for a, h in zip(t.alpha, t.half_width)]); nobars_grid(ax, "x")
    ax.set(ylim=(80, 100), ylabel="Coverage, 18,000 test slopes (%)", title="(a) Split-conformal coverage"); ax.legend(loc="upper left", ncol=2)
    ax = axs[1]; c = t.confident_pct.values; ax.bar(x, c, .55, color=FW, label="confident class verdict"); ax.bar(x, 100 - c, .55, bottom=c, color=NEUT, edgecolor=S.AXIS, lw=.8, label="interval spans a class boundary")
    for i in x: label(ax, i, c[i] / 2, f"{c[i]:.1f} %\n{t.confident_accuracy[i]*100:.2f} % correct", ha="center", va="center", color="white", fontsize=7.2)
    ax.set_xticks(x, [f"{int(round((1-a)*100))} % interval" for a in t.alpha]); nobars_grid(ax, "x"); ax.set(ylim=(0, 100), ylabel="Share of test slopes (%)", title="(b) Confident verdicts")
    ax.legend(loc="upper center", bbox_to_anchor=(.5, -.13), ncol=1); save("Fig06_uncertainty")

# ------------------------------------------------------------------ Fig 7 physics consistency
@fig("Fig07")
def _():
    t = csv("final_results/T6_monotone_envelope.csv", index_col=0)
    keys = ["viol_PorePressureRatio", "viol_SeismicCoefficient", "viol_SlopeAngle_deg", "viol_Cohesion_kPa", "viol_FrictionAngle_deg", "mean_violation_pct"]
    lab = ["Pore pressure rᵤ", "Seismic kₕ", "Slope angle β", "Cohesion c", "Friction angle φ", "Mean"]; x = np.arange(len(keys)); w = .38
    f, ax = plt.subplots(figsize=(7.6, 3.6))
    ax.bar(x - w / 2 - .01, t.iloc[0][keys], w, color=BASE, label="framework before envelope"); ax.bar(x + w / 2 + .01, t.iloc[1][keys], w, color=FW, label="framework + monotone envelope (kₕ, rᵤ)")
    for i, k in enumerate(keys):
        label(ax, x[i] - w / 2, t.iloc[0][k] + .15, f"{t.iloc[0][k]:.1f}", ha="center", va="bottom"); label(ax, x[i] + w / 2, t.iloc[1][k] + .15, f"{t.iloc[1][k]:.1f}", ha="center", va="bottom")
    ax.set_xticks(x, lab); nobars_grid(ax, "x"); ax.set(ylabel="Monotonicity violations (% of test slopes)", title=f"Physical consistency (test R² {t.R2.iloc[0]:.4f} → {t.R2.iloc[1]:.4f})"); ax.legend()
    save("Fig07_physics_consistency")

# ------------------------------------------------------------------ Fig 8 ablation
@fig("Fig08")
def _():
    t = csv("final_results/T2_ablation_full_configuration.csv")
    lab = t.variant.str.replace("FULL: attention + residual + physics + interaction", "Full framework (all components)", regex=False).str.replace("- ", "without ", n=1, regex=False).str.slice(0, 44)
    full = t.variant.str.startswith("FULL").values; y = np.arange(len(t))
    f, axs = plt.subplots(1, 2, figsize=(10.4, 3.9), sharey=True)
    for ax, col, fmt, xl, ttl in ((axs[0], "val_RMSE", "{:.4f}", "Validation RMSE of FoS", "(a) Accuracy"), (axs[1], "antagonistic_pct", "{:.0f} %", "Implausible (antagonistic) rain x earthquake response, % slopes", "(b) Physical plausibility")):
        v = t[col].values; cc = np.where(full, FW, BASE)
        if col == "val_RMSE":   # tiny differences: dot plot, so no bar is truncated by the zoomed axis
            ax.hlines(y, v.min() * .985, v, color=S.GRID, lw=1.2); ax.scatter(v, y, s=48, color=cc, zorder=3)
            for i, vv in enumerate(v): label(ax, vv, i - .32, fmt.format(vv), ha="center", fontsize=6.9)
        else:
            ax.barh(y, v, color=cc, height=.62)
            for i, vv in enumerate(v): label(ax, vv, i, " " + fmt.format(vv), va="center")
        nobars_grid(ax); ax.set(xlabel=xl, title=ttl)
    axs[0].set_xlim(t.val_RMSE.min() * .985, t.val_RMSE.max() * 1.012); axs[1].set_xlim(0, t.antagonistic_pct.max() * 1.15)
    axs[0].set_yticks(y, lab); axs[0].invert_yaxis(); save("Fig08_ablation")

# ------------------------------------------------------------------ Fig 9 seismic response
@fig("Fig09")
def _():
    t = csv("unified_results/T3_seismic_vs_heldout_MP.csv", index_col=0); mp = [c for c in t if c.startswith("Morgenstern")][0]; gme = [c for c in t if c.startswith("N3")][0]
    others = [c for c in t if c not in (mp, gme)]; f, ax = plt.subplots(figsize=(5.8, 3.9))
    for c in others: ax.plot(t.index, t[c], color=BASE, lw=.7, alpha=.8, zorder=1)
    ax.plot(t.index, t[gme], "-o", color=FW, ms=4, zorder=3, label="GME (framework expert)")
    ax.plot(t.index, t[mp], "--o", color=MECH, ms=4.5, mfc="white", mew=1.2, zorder=4, label="Morgenstern-Price (held-out geometries)")
    ax.plot([], [], color=BASE, lw=.8, label=f"{len(others)} other ML/DL models")
    ax.set(xlabel="Seismic coefficient kₕ", ylabel="FoS(kₕ) / FoS(kₕ = 0)", title="Seismic response of data-trained models vs rigorous LEM"); ax.legend(loc="lower left")
    save("Fig09_seismic_response")

# ------------------------------------------------------------------ Fig 10 compound hazard cells
@fig("Fig10")
def _():
    g = csv("q1_results/Q8_compound_hazard_cells_test_set.csv")
    def nice(iv): lo, hi = [float(x) for x in iv.strip("([])").split(",")]; return f"{max(lo, 0):g}–{hi:g}"
    g["kh"], g["rain"] = g.kh.map(nice), g.rain.map(nice)
    ko = sorted(g.kh.unique(), key=lambda s: float(s.split("–")[0])); ro = sorted(g.rain.unique(), key=lambda s: float(s.split("–")[0]))
    f, axs = plt.subplots(1, 2, figsize=(11, 4.3), sharey=True)
    for ax, col, ttl in zip(axs, ["observed_failure_rate", "predicted_failure_rate"], ["(a) Observed (test labels)", "(b) Predicted by the framework"]):
        M = g.pivot(index="kh", columns="rain", values=col).reindex(index=ko, columns=ro).values
        for i, j in zip(*np.where(~np.isfinite(M))): ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fc="white", ec=S.GRID, hatch="////", lw=0))
        im = ax.imshow(M * 100, cmap=S.EARTH_SEQ, vmin=0, vmax=100, aspect="auto", origin="lower")
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                if np.isfinite(M[i, j]): ax.text(j, i, f"{M[i,j]*100:.0f}", ha="center", va="center", fontsize=7.6, color=S.text_on(S.EARTH_SEQ(M[i, j])))
                else: pass
        ax.set_xticks(range(len(ro)), ro, rotation=30, ha="right"); ax.set_yticks(range(len(ko)), ko); ax.grid(False); ax.set_xlim(-.5, len(ro) - .5); ax.set_ylim(-.5, len(ko) - .5); ax.set(xlabel="Rainfall (mm/day)", title=ttl)
        for sp in ax.spines.values(): sp.set_visible(False)
    axs[0].set_ylabel("Seismic coefficient kₕ"); cb = plt.colorbar(im, ax=axs, shrink=.85, pad=.02); cb.set_label("Test slopes with FoS < 1 (%)"); cb.outline.set_visible(False)
    f.text(.01, -.1, "Hatched cells: no slopes of that rainfall–kₕ combination exist in the dataset; nothing is extrapolated.", fontsize=7.4, color=S.INK2)
    save("Fig10_compound_hazard_cells", tight=False)

# ------------------------------------------------------------------ Fig 11 rain x earthquake interaction (mechanics)
@fig("Fig11")
def _():
    t = csv("mechanics_results/M6_ru_kh_interaction_grid.csv"); p = csv("mechanics_results/M6b_population_interaction.csv", index_col=0).iloc[:, 0]
    sl = list(dict.fromkeys(t.slope)); khs = [0, .1, .2, .3]; cs = S.ramp(S.PLUM_SEQ, len(khs), .3, 1)
    f, axs = plt.subplots(1, len(sl), figsize=(10.6, 3.7), sharey=True)
    for ax, s_ in zip(axs, sl):
        d = t[t.slope == s_]
        for k, c in zip(khs, cs):
            e = d[np.isclose(d.kh, k)].sort_values("ru"); ax.plot(e.ru, e.FoS_Bishop, "-", color=c, lw=1.8); ax.plot(e.ru, e.FoS_surrogate, ":", color=c, lw=1.4)
        ax.axhline(1, color=S.AXIS, lw=.8, zorder=1); ax.set(xlabel="Pore-pressure ratio rᵤ", title=s_.capitalize().replace(" deg", "°"), xlim=(0, .6))
    axs[0].set_ylabel("Factor of safety")
    axs[0].legend(handles=[Line2D([], [], color=c, lw=2, label=f"kₕ = {k:g}") for k, c in zip(khs, cs)], loc="upper right", title="seismic coefficient")
    axs[-1].legend(handles=[Line2D([], [], color=S.INK2, lw=1.8, label="Bishop LEM"), Line2D([], [], color=S.INK2, lw=1.4, ls=":", label="MVB surrogate")], loc="upper right")
    f.text(.01, -.05, f"Population of 400 slopes: rᵤ +0.2 lowers FoS by {p.median_drop_rain_pct:.1f} %, kₕ +0.1 by {p.median_drop_eq_pct:.1f} %, both by {p.median_drop_both_pct:.1f} %; "
           f"interaction index median {p.median_I_Bishop:.3f} (synergistic in {p.pct_synergistic_Bishop:.0f} % of slopes).", fontsize=7.4, color=S.INK2)
    save("Fig11_rainfall_seismic_interaction_mechanics")

# ------------------------------------------------------------------ Fig 12 feature importance
@fig("Fig12")
def _():
    t = csv("q1_results/Q5_importance_summary.csv", index_col=0).sort_values("mean_abs_SHAP"); y = np.arange(len(t)); col = [S.VAR_GROUP.get(i, BASE) for i in t.index]
    f, axs = plt.subplots(1, 2, figsize=(10, 3.9), sharey=True)
    for ax, c_, fmt, xl, ttl in ((axs[0], "mean_abs_SHAP", "{:.3f}", "mean |SHAP| (FoS units)", "(a) SHAP, final framework"), (axs[1], "permutation_RMSE_increase", "{:.3f}", "RMSE increase when permuted", "(b) Permutation importance")):
        v = t[c_].values; ax.barh(y, v, color=col, height=.62)
        for i, vv in enumerate(v): label(ax, max(vv, 0), i, " " + fmt.format(max(vv, 0)), va="center")
        nobars_grid(ax); ax.set(xlabel=xl, title=ttl, xlim=(0, v.max() * 1.2))
    axs[0].set_yticks(y, [S.VAR_LABEL.get(i, i) for i in t.index])
    axs[1].legend(handles=[Patch(color=MECH, label="geometry and strength"), Patch(color=RAIN, label="rainfall / hydrology"), Patch(color=SEIS, label="seismic")], loc="lower right")
    save("Fig12_feature_importance")

# ------------------------------------------------------------------ Fig 13 SHAP dependence for the two hazards
@fig("Fig13")
def _():
    t = csv("q1_results/Q5d_shap_values_200_test_slopes.csv"); f, axs = plt.subplots(1, 2, figsize=(9.6, 3.8))
    for ax, v, cv, cm, ttl in ((axs[0], "PorePressureRatio", "SeismicCoefficient", S.PLUM_SEQ, "(a) Rainfall pathway: rᵤ"), (axs[1], "SeismicCoefficient", "PorePressureRatio", S.LAGOON_SEQ, "(b) Seismic loading: kₕ")):
        sc = ax.scatter(t[v], t["shap_" + v], c=t[cv], cmap=cm, s=16, lw=.3, edgecolor="white"); ax.axhline(0, color=S.AXIS, lw=.8, zorder=1)
        ax.set(xlabel=S.VAR_LABEL[v], ylabel=f"SHAP value of {S.VAR_LABEL[v].split()[-1]} (FoS units)", title=ttl)
        cb = plt.colorbar(sc, ax=ax, pad=.02); cb.set_label(S.VAR_LABEL[cv]); cb.outline.set_visible(False)
    save("Fig13_shap_hazard_dependence")

# ------------------------------------------------------------------ Fig 14 mechanics-consistency audit
@fig("Fig14")
def _():
    a = csv("mechanics_results/M4_mechanics_consistency_audit.csv"); pf = csv("mechanics_results/M8b_accuracy_vs_mechanics_pareto.csv")
    ws = float(open(R + "mechanics_results/M8d_selected_blend.txt").read().split("\n")[0].split("=")[1]); sel = pf.iloc[(pf.w_data - ws).abs().idxmin()]
    var = ["c", "phi", "beta", "H", "gamma", "ru", "kh"]; vl = {"c": "Cohesion c", "phi": "Friction angle φ", "beta": "Slope angle β", "H": "Height H", "gamma": "Unit weight γ", "ru": "Pore pressure rᵤ", "kh": "Seismic kₕ"}
    fw = a[a.model == "Final framework"].set_index("variable").ratio_of_medians; mv = a[a.model.str.startswith("MVB")].set_index("variable").ratio_of_medians
    an = pd.Series({k: sel[f"ratio_{k}"] for k in var}); y = np.arange(len(var))[::-1]
    f, ax = plt.subplots(figsize=(6.8, 4.1)); ax.axvspan(.8, 1.25, color=NEUT, zorder=0); ax.axvline(1, color=MECH, ls=(0, (4, 3)), lw=1, zorder=1)
    for i, k in zip(y, var):
        vals = [fw[k], an[k]]; ax.plot([min(vals), max(vals)], [i, i], color=S.AXIS, lw=1.2, zorder=1)
    ax.scatter(fw[var].abs(), y, s=46, color=BASE, zorder=3, label="data-only framework (Kaggle labels)")
    ax.scatter(mv[var].abs(), y, s=46, facecolor="white", edgecolor=MECH, lw=1.3, zorder=3, label="MVB surrogate (trained on Bishop)")
    ax.scatter(an[var].abs(), y, s=56, color=FW, edgecolor="white", lw=.8, zorder=4, label=f"mechanics-anchored hybrid (w = {ws:g})")
    ax.set_xscale("log"); ax.set_xticks([.1, .2, .5, 1, 2], ["0.1", "0.2", "0.5", "1", "2"]); ax.set_xlim(.08, 2.2)
    ax.set_yticks(y, [vl[k] for k in var]); nobars_grid(ax); label(ax, 1.02, len(var) - .45, "Bishop = 1", fontsize=7)
    label(ax, .8 * 1.02, -.75, "±25 % band", fontsize=6.8, style="italic")
    ax.set(xlabel="Median log-sensitivity ∂lnFoS/∂x relative to Bishop LEM (log scale)", title="Mechanics-consistency audit on 300 test slopes", ylim=(-.9, len(var) - .2))
    ax.legend(loc="upper center", bbox_to_anchor=(.45, -.16), ncol=2, borderaxespad=0); save("Fig14_mechanics_consistency_audit")

# ------------------------------------------------------------------ Fig 15 Pareto
@fig("Fig15")
def _():
    t = csv("mechanics_results/M8b_accuracy_vs_mechanics_pareto.csv"); ws = float(open(R + "mechanics_results/M8d_selected_blend.txt").read().split("\n")[0].split("=")[1])
    f, ax = plt.subplots(figsize=(5.6, 4.1)); ax.plot(t.ratio_kh, t.R2, "-o", color=BASE, ms=3.5, label="blend: data-only ↔ mechanics-anchored")
    ax.axhline(.93, ls=(0, (4, 3)), color=MECH, lw=.9, zorder=2); label(ax, .02, .932, "R² = 0.93 benchmark", transform=ax.get_yaxis_transform(), va="bottom")
    j = (t.w_data - ws).abs().idxmin(); ax.scatter([t.ratio_kh[j]], [t.R2[j]], s=110, facecolor="none", edgecolor=FW, lw=2, zorder=4)
    ax.scatter([t.ratio_kh[j]], [t.R2[j]], s=26, color=FW, zorder=5, label=f"selected on validation (w = {ws:g})")
    for _, r in t.iloc[::4].iterrows(): label(ax, r.ratio_kh - .015, r.R2 - .002, f"w = {r.w_data:.1f}", fontsize=6.8, ha="right", va="top")
    ax.set_xlim(0, 1.03); ax.set(xlabel="Seismic sensitivity relative to Bishop (1 = mechanics)", ylabel="R² on Kaggle test labels", title="Data fit vs mechanics consistency"); ax.legend(loc="lower left")
    save("Fig15_pareto_data_vs_mechanics")

# ------------------------------------------------------------------ Fig 16 reliability
@fig("Fig16")
def _():
    t = csv("mechanics_results/M5_reliability_compound_hazard.csv", index_col=0); x = np.arange(len(t)); w = .38
    hz = [S.HAZARD[k.split()[0]] for k in t.index]; pb, pm = t.Pf_Bishop_MC.astype(float) * 100, t.Pf_MLP_1e6.astype(float) * 100
    f, ax = plt.subplots(figsize=(7.2, 3.9))
    ax.bar(x - w / 2 - .01, pb, w, color="white", edgecolor=MECH, hatch="////", lw=.9, label="direct Bishop Monte Carlo (2,000)")
    ax.bar(x + w / 2 + .01, pm, w, color=hz, label="surrogate Monte Carlo (10⁶)")
    for i in x:
        label(ax, i - w / 2, pb.iloc[i] + 1, f"{pb.iloc[i]:.1f}", ha="center", va="bottom")
        bm = t.beta_MLP_1e6.astype(float).iloc[i]; label(ax, i + w / 2, pm.iloc[i] + 1, f"{pm.iloc[i]:.{1 if pm.iloc[i] >= .1 else 4}f}\nβ = {bm:.2f}", ha="center", va="bottom", fontsize=6.9)
    ax.set_xticks(x, [s.replace(" (", "\n(").replace("r_u", "rᵤ").replace("kh", "kₕ") for s in t.index]); nobars_grid(ax, "x"); ax.set_ylim(0, 100)
    ax.legend(handles=[Patch(fc="white", ec=MECH, hatch="////", label="direct Bishop Monte Carlo (2,000 samples)"), Patch(color=RAIN, label="surrogate MC (10⁶): rainfall"), Patch(color=SEIS, label="surrogate MC (10⁶): seismic"), Patch(color=COMP, label="surrogate MC (10⁶): compound")], loc="upper left")
    ax.set(ylabel="Probability of failure (%)", title=f"Reliability under compound hazards (surrogate ≈ {float(t.speedup_MLP.astype(float).median()):,.0f}× faster per evaluation)")
    save("Fig16_reliability_compound_hazard")

# ------------------------------------------------------------------ Fig 17 leave-one-family-out
@fig("Fig17")
def _():
    t = csv("q1_results/QF3_leave_one_family_out.csv", index_col=[0, 1]).xs("LightGBM", level=1)
    f, ax = plt.subplots(figsize=(7.2, 3.6)); y = np.arange(len(t)); h = .38
    ax.barh(y - h / 2 - .01, t.RMSE_family_seen, h, color=BASE, label="family seen in training"); ax.barh(y + h / 2 + .01, t.RMSE_family_UNSEEN, h, color=FW, label="family left out of training")
    for i, (a_, b_) in enumerate(zip(t.RMSE_family_seen, t.RMSE_family_UNSEEN)): label(ax, a_, i - h / 2, f" {a_:.3f}", va="center"); label(ax, b_, i + h / 2, f" {b_:.3f}", va="center")
    ax.set_yticks(y, [i.replace("kh", "kₕ").replace("<=", "≤").replace(">=", "≥") for i in t.index]); nobars_grid(ax); ax.invert_yaxis(); ax.set_xlim(0, t.RMSE_family_UNSEEN.max() * 1.18)
    ax.set(xlabel="Test RMSE of FoS (LightGBM)", title="Generalisation to an unseen hazard-scenario family"); ax.legend(loc="center right"); save("Fig17_leave_one_family_out")

# ------------------------------------------------------------------ Fig 18 strict grouping
@fig("Fig18")
def _():
    t = csv("realworld_combinations/T10_strict_grouping_leakage_check.csv"); p = t.pivot_table(index=["grouping", "groups"], columns="config", values="Accuracy", sort=False)
    sty = {c: ((FW, "o", "-") if c.startswith("ALL-20") and "Vote" in c else (FW2, "s", "--") if c.startswith("ALL-20") else (BASE, "^", "-")) for c in p.columns}
    f, ax = plt.subplots(figsize=(7.2, 3.9)); xs = np.arange(len(p))
    for cn, s in p.items():
        c, m, ls = sty[cn]; ax.plot(xs, s.values * 100, ls, marker=m, color=c, ms=5, label=cn)
    ax.set_xticks(xs, [f"{g.split('(')[0].strip()}\n({n} groups)" for g, n in p.index], fontsize=7); target(ax, 93, "93 % target")
    ax.set(ylabel="Accuracy, 363 real slopes (%)", ylim=(55, 97), title="Real-world accuracy vs strictness of grouping related slopes"); ax.legend(loc="lower left"); save("Fig18_strict_grouping")

# ------------------------------------------------------------------ Fig 19 confident verdicts
@fig("Fig19")
def _():
    t = csv("realworld_combinations/T18_confident_slopes_5_repeats.csv"); t = t[~t.seed.astype(str).isin(["mean", "std"])].astype(float)
    n19 = len(csv("realworld_combinations/T19_slopes_confident_in_3plus_of_5_repeats.csv"))
    f, ax = plt.subplots(figsize=(5.8, 4))
    ax.scatter(t.coverage_pct, t.accuracy_all * 100, s=40, marker="^", color=BASE, zorder=3, label="all 363 slopes (no rule)")
    ax.scatter(t.coverage_pct, t.accuracy_confident * 100, s=48, color=FW2, edgecolor="white", lw=.8, zorder=3, label="all confident slopes")
    ax.scatter(t.coverage_pct, t.accuracy_named_confident * 100, s=48, marker="s", color=FW, edgecolor="white", lw=.8, zorder=4, label="named confident slopes")
    target(ax, 93, "93 %")
    ax.set(xlabel="Coverage: slopes given a confident verdict (%)", ylabel="Accuracy (%)", ylim=(78, 99), title="Confident-verdict rule, 5 grouped-CV repeats")
    ax.legend(loc="center", bbox_to_anchor=(.55, .42)); label(ax, .02, .97, f"{n19} slopes confident in ≥ 3 of 5 repeats", transform=ax.transAxes, va="top")
    save("Fig19_confident_verdicts")

S.swatch(OUT + "Palette_key_for_authors.png")
json.dump(dict(figures=done, failed=failed), open(OUT + "figure_list.json", "w"), indent=1); print("figures:", len(done), "failed:", failed)
