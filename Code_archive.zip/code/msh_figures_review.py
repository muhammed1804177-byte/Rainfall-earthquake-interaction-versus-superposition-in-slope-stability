"""Figures for the rainfall-seismic interaction core (I-series) and the editorial-review analyses (R-series, final model),
in the Strata identity (msh_style.py). Built from saved tables only. Output: figures_final/ (Fig20+)."""
import os, sys, json, traceback
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, LogNorm
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_style as S
S.apply()
R = os.environ.get("MSH_OUT", os.path.dirname(HERE)) + "/"; OUT = R + "figures_final/"; os.makedirs(OUT, exist_ok=True)
I, RV, FM = R + "interaction_results/", R + "review_results/", R + "final_model_results/"
FW, FW2, RAIN, SEIS, COMP, MECH, BASE, NEUT = (S.ROLE[k] for k in ("framework", "framework_alt", "rainfall", "seismic", "compound", "mechanics", "baseline", "neutral"))
done, failed = [], []
def save(n, tight=True):
    if tight: plt.tight_layout()
    plt.savefig(OUT + n + ".png", dpi=300, bbox_inches="tight"); plt.savefig(OUT + n + ".pdf", bbox_inches="tight"); plt.close("all"); done.append(n)
def label(ax, x, y, s, **k):
    k.setdefault("fontsize", 7.4); k.setdefault("color", S.INK2); ax.text(x, y, s, **k)
def fig(name):
    def wrap(f):
        try: f(); print("ok  ", name, flush=True)
        except Exception: failed.append(name); plt.close("all"); print("FAIL", name); traceback.print_exc()
        return f
    return wrap
DIV = LinearSegmentedColormap.from_list("int_div", ["#00524C", S.LAGOON, "#8CCBC4", S.SAND, "#E3A58C", S.TERRACOTTA, "#86331F"])
def heat(ax, M, rows, cols, cmap, norm=None, fmt="{:.0f}", vmin=None, vmax=None):
    im = ax.imshow(M, cmap=cmap, norm=norm, vmin=None if norm else vmin, vmax=None if norm else vmax, aspect="auto", origin="lower")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M[i, j]
            if np.isfinite(v): ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=7.2, color=S.text_on(im.cmap(im.norm(v))))
    ax.set_xticks(range(len(cols)), cols); ax.set_yticks(range(len(rows)), rows); ax.grid(False)
    for sp in ax.spines.values(): sp.set_visible(False)
    return im

# ------------------------------------------------------------------ Fig 20 factorial loading matrix
@fig("Fig20")
def _():
    t = pd.read_csv(I + "I1_factorial_loading_matrix_Bishop.csv"); ru, kh = sorted(t.ru.unique()), sorted(t.kh.unique())
    P = lambda c: t.pivot(index="ru", columns="kh", values=c).reindex(index=ru, columns=kh).values
    f, axs = plt.subplots(1, 3, figsize=(12.2, 3.9), gridspec_kw=dict(width_ratios=[1, 1.15, 1]))
    im = heat(axs[0], P("median_drop_pct"), [f"{v:g}" for v in ru], [f"{v:g}" for v in kh], S.EARTH_SEQ, vmin=0, vmax=60)
    axs[0].set(xlabel="Seismic coefficient kₕ", ylabel="Pore-pressure ratio rᵤ (rainfall)", title="(a) Median FoS reduction (%)")
    ax = axs[1]; cs = S.ramp(S.PLUM_SEQ, len(kh) - 1, .35, 1)
    for k_, c in zip(kh[1:], cs):
        e = t[np.isclose(t.kh, k_)].sort_values("ru"); ax.plot(e.ru, e.median_drop_pct, "-o", color=c, ms=3.5, label=f"kₕ {k_:g}")
        ax.plot(e.ru, e.additive_expected_drop_pct, ":", color=c, lw=1.4)
    e = t[np.isclose(t.kh, 0)].sort_values("ru"); ax.plot(e.ru, e.median_drop_pct, "-o", color=RAIN, ms=3.5, label="rainfall only")
    ax.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Median FoS reduction (%)", title="(b) Combined (solid) vs sum of single effects (dotted)")
    h, l = ax.get_legend_handles_labels(); h.append(Line2D([], [], color=S.INK2, ls=":", lw=1.4)); l.append("additive expectation"); ax.legend(h, l, loc="upper left", fontsize=7)
    M = P("failure_share_interaction_pp"); lim = max(1, np.nanmax(np.abs(M)))
    im3 = heat(axs[2], M, [f"{v:g}" for v in ru], [f"{v:g}" for v in kh], DIV, norm=TwoSlopeNorm(0, -lim, lim), fmt="{:+.0f}")
    axs[2].set(xlabel="Seismic coefficient kₕ", title="(c) Extra failures beyond additive (pp)")
    cb = plt.colorbar(im3, ax=axs[2], pad=.02, shrink=.9); cb.outline.set_visible(False); cb.set_label("terracotta = more failures than additive")
    save("Fig20_rainfall_seismic_factorial_matrix")

# ------------------------------------------------------------------ Fig 21 yield coefficient and critical rainfall
@fig("Fig21")
def _():
    a = pd.read_csv(I + "I2_yield_coefficient_vs_ru.csv"); b = pd.read_csv(I + "I2d_critical_ru_and_rainfall_vs_kh.csv"); r = pd.read_csv(I + "I2c_observed_rainfall_to_ru.csv")
    f, axs = plt.subplots(1, 3, figsize=(12.2, 3.8))
    ax = axs[0]; ax.plot(a.ru, a.median_ky_of_statically_stable, "-o", color=SEIS, ms=4, label="median k$_y$ (statically stable slopes)")
    ax.plot(a.ru, a.pct_ky_lt_0_15 / 100 * .3, alpha=0)  # keep scale
    ax.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Yield seismic coefficient k$_y$", title="(a) Wetting lowers the yield coefficient", ylim=(0, None))
    for x_, y_ in zip(a.ru, a.median_ky_of_statically_stable): label(ax, x_, y_ + .006, f"{y_:.2f}", ha="center", fontsize=6.8)
    ax2 = axs[1]; ax2.bar(a.ru, a.pct_ky_lt_0_15, width=.07, color=COMP, label="k$_y$ < 0.15 (fails at kₕ 0.15)"); ax2.bar(a.ru, a.pct_failing_static, width=.07, color=MECH, label="fails without earthquake")
    for x_, y_ in zip(a.ru, a.pct_ky_lt_0_15): label(ax2, x_, y_ + 1, f"{y_:.0f}", ha="center", fontsize=6.8)
    ax2.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Slopes (%)", title="(b) Share that a kₕ 0.15 event fails"); ax2.legend(loc="upper left", fontsize=7); ax2.grid(axis="x", visible=False)
    ax3 = axs[2]; ax3.fill_between(r.rain_mid, r.ru_q25, r.ru_q75, color=RAIN, alpha=.18, lw=0, label="observed rᵤ, IQR"); ax3.plot(r.rain_mid, r.ru_median, "-", color=RAIN, label="observed rᵤ, median")
    cs = S.ramp(S.PLUM_SEQ, len(b), .35, 1)
    for (_, row), c in zip(b.iterrows(), cs):
        if np.isfinite(row.median_critical_ru):
            ax3.plot([0, row.median_critical_rain_mm_day], [row.median_critical_ru] * 2, color=c, lw=1, ls=(0, (3, 2)))
            ax3.plot([row.median_critical_rain_mm_day], [row.median_critical_ru], "o", color=c, ms=4.5, mec="white", mew=.6, zorder=4, label=f"critical rᵤ, kₕ {row.kh:g} → {row.median_critical_rain_mm_day:.0f} mm/day")
    ax3.set(xlabel="Rainfall (mm/day)", ylabel="Pore-pressure ratio rᵤ", title="(c) Rainfall at which a given kₕ becomes critical", xlim=(0, 340), ylim=(0, .62)); ax3.axvspan(140, 180, color=S.SAND, zorder=0); label(ax3, 160, .02, "no data", ha="center", fontsize=6.6, style="italic"); ax3.legend(loc="upper left", fontsize=6.4)
    save("Fig21_yield_coefficient_and_critical_rainfall")

# ------------------------------------------------------------------ Fig 22 reliability interaction surface
@fig("Fig22")
def _():
    t = pd.read_csv(I + "I6_reliability_interaction_surface.csv"); ru, kh = sorted(t.ru.unique()), sorted(t.kh.unique())
    P = lambda c: t.pivot(index="ru", columns="kh", values=c).reindex(index=ru, columns=kh).values
    f, axs = plt.subplots(1, 2, figsize=(10.6, 4.1))
    pf = np.clip(P("Pf") * 100, 1e-3, 100); im = axs[0].imshow(pf, cmap=S.EARTH_SEQ, norm=LogNorm(1e-3, 100), aspect="auto", origin="lower",
                                                              extent=(kh[0] - .0125, kh[-1] + .0125, ru[0] - .025, ru[-1] + .025))
    cs = axs[0].contour(kh, ru, pf, levels=[1, 10, 50], colors=[S.INK], linewidths=.8); axs[0].clabel(cs, fmt=lambda v: f"Pf {v:g}%", fontsize=6.8)
    axs[0].grid(False); axs[0].set(xlabel="Seismic coefficient kₕ", ylabel="Pore-pressure ratio rᵤ", title="(a) Probability of failure, typical 35° slope")
    cb = plt.colorbar(im, ax=axs[0], pad=.02); cb.set_label("Pf (%)"); cb.outline.set_visible(False)
    rat = P("Pf_ratio_to_additive"); rat = np.where((P("Pf") < 1e-4) | (P("Pf_additive_expectation") < 1e-4), np.nan, rat)
    im2 = axs[1].imshow(np.log10(np.clip(rat, .1, 1000)), cmap=DIV, norm=TwoSlopeNorm(0, -1, 3), aspect="auto", origin="lower", extent=(kh[0] - .0125, kh[-1] + .0125, ru[0] - .025, ru[-1] + .025))
    axs[1].grid(False); axs[1].set(xlabel="Seismic coefficient kₕ", title="(b) Combined Pf ÷ additive expectation")
    cb2 = plt.colorbar(im2, ax=axs[1], pad=.02, ticks=[-1, 0, 1, 2, 3]); cb2.ax.set_yticklabels(["0.1×", "1×", "10×", "100×", "1000×"]); cb2.outline.set_visible(False)
    label(axs[1], .02, .97, "blank: Pf or its additive expectation < 0.01 %", transform=axs[1].transAxes, va="top", fontsize=6.8)
    save("Fig22_reliability_interaction_surface")

# ------------------------------------------------------------------ Fig 23 interaction strength (H statistic, SHAP interaction)
@fig("Fig23")
def _():
    h = pd.read_csv(I + "I4_Friedman_H_interaction_strength_logFoS.csv"); s = pd.read_csv(I + "I4b_SHAP_interaction_values_LightGBM.csv")
    XN = {"FS_infinite": "FS∞ (static margin)", "StabilityNumber_N": "stability number N", "FrictionRatio": "friction ratio"}
    nice = lambda p: " × ".join(XN.get(x.strip(), S.VAR_LABEL.get(x.strip(), x.strip())).replace("Seismic coefficient kₕ", "kₕ").replace("Pore-pressure ratio rᵤ", "rᵤ") for x in p.split(" x "))
    pairs = list(dict.fromkeys(h.pair)); y = np.arange(len(pairs)); f, axs = plt.subplots(1, 2, figsize=(11.4, 4.2), gridspec_kw=dict(width_ratios=[1.1, 1]))
    sty = {"Proposed framework": (BASE, None), "Mechanics-anchored hybrid": (FW, None), "Bishop (MVB surrogate)": ("white", "////")}
    hgt = .26
    for i, (m, (c, hatch)) in enumerate(sty.items()):
        v = h[h.model == m].set_index("pair").reindex(pairs).H2.values
        axs[0].barh(y + (i - 1) * hgt, v, hgt, color=c, hatch=hatch, edgecolor=MECH if hatch else c, lw=.8 if hatch else 0, label=m)
    axs[0].set_yticks(y, [nice(p) for p in pairs]); axs[0].invert_yaxis(); axs[0].grid(axis="y", visible=False)
    axs[0].set(xlabel="Friedman H² on log FoS (share of joint effect that is interaction)", title="(a) Interaction strength, data-supported slopes"); axs[0].legend(loc="lower right", fontsize=7)
    top = s.head(10).iloc[::-1]; col = [SEIS if "SeismicCoefficient" in p else (RAIN if any(k in p for k in ("Rain", "Pore", "Ground", "Weather")) else MECH) for p in top.pair]
    axs[1].barh(np.arange(len(top)), top.mean_abs_SHAP_interaction, color=col, height=.62); axs[1].set_yticks(np.arange(len(top)), [nice(p) for p in top.pair])
    axs[1].grid(axis="y", visible=False); axs[1].set(xlabel="mean |SHAP interaction| (FoS units)", title="(b) Top-10 SHAP interaction pairs")
    axs[1].legend(handles=[Patch(color=SEIS, label="involves kₕ"), Patch(color=RAIN, label="hydrology pair"), Patch(color=MECH, label="geometry / strength")], loc="lower right", fontsize=7)
    save("Fig23_interaction_strength")

# ------------------------------------------------------------------ Fig 24 vulnerability
@fig("Fig24")
def _():
    t = pd.read_csv(I + "I3b_vulnerability_by_geometry_and_strength.csv"); m = pd.read_csv(I + "I3_interaction_moderators.csv")
    bt = list(dict.fromkeys(t.beta_tertile)); nt = list(dict.fromkeys(t.cohesion_number_tertile))
    f, axs = plt.subplots(1, 2, figsize=(10.4, 3.9))
    M = t.pivot(index="cohesion_number_tertile", columns="beta_tertile", values="compound_only_failure_pct").reindex(index=nt, columns=bt).values
    im = heat(axs[0], M, ["low c/(γH)", "mid c/(γH)", "high c/(γH)"], ["gentle β", "medium β", "steep β"], S.EARTH_SEQ, vmin=0, vmax=max(5, np.nanmax(M)), fmt="{:.0f}%")
    axs[0].set(title="(a) Slopes failing ONLY under combined loading")
    y = np.arange(len(m)); axs[1].barh(y, m.spearman_with_relative_combined_drop, color=[MECH if v > 0 else BASE for v in m.spearman_with_relative_combined_drop], height=.6)
    axs[1].axvline(0, color=S.AXIS, lw=.8); axs[1].set_yticks(y, m.moderator.str.replace("beta", "β").str.replace("phi", "φ").str.replace("gamma", "γ")); axs[1].invert_yaxis(); axs[1].grid(axis="y", visible=False)
    for i, v in enumerate(m.spearman_with_relative_combined_drop): label(axs[1], v + (.02 if v >= 0 else -.02), i, f"{v:+.2f}", va="center", ha="left" if v >= 0 else "right")
    axs[1].set(xlabel="Spearman ρ with relative FoS loss under rᵤ 0.3 + kₕ 0.15", title="(b) What makes a slope lose more", xlim=(-1, 1))
    save("Fig24_vulnerability_to_combined_loading")

# ------------------------------------------------------------------ Fig 25 consistency under combined loading
@fig("Fig25")
def _():
    t = pd.read_csv(I + "I5_sensitivity_change_under_combined_loading_Bishop.csv"); v = pd.read_csv(I + "I5b_monotonicity_by_loading_regime.csv")
    conds = list(dict.fromkeys(t.condition)); hz = [S.HAZARD["static"], RAIN, SEIS, COMP]; vars_ = ["c", "phi", "beta"]; vl = {"c": "Cohesion c", "phi": "Friction angle φ", "beta": "Slope angle β"}
    f, axs = plt.subplots(1, 2, figsize=(10.8, 3.9)); x = np.arange(len(vars_)); w = .2
    for i, (cn, c) in enumerate(zip(conds, hz)):
        vals = t[t.condition == cn].set_index("variable").reindex(vars_).median_log_sensitivity.abs().values
        axs[0].bar(x + (i - 1.5) * w, vals, w, color=c, label=cn.replace("r_u", "rᵤ").replace("kh", "kₕ"))
    axs[0].set_xticks(x, [vl[k] for k in vars_]); axs[0].grid(axis="x", visible=False); axs[0].legend(fontsize=7, loc="upper left")
    axs[0].set(ylabel="|∂ ln FoS / ∂x| (Bishop, median of 200 slopes)", title="(a) Strength and geometry matter more when wet and shaken")
    vv = v.groupby(["regime", "model"]).violation_pct.mean().unstack()
    sty = {"Proposed framework": (BASE, "o", "-"), "Earlier anchored hybrid (unconstrained)": (FW2, "s", "--")}
    vv = vv.rename(columns={"Mechanics-anchored hybrid": "Earlier anchored hybrid (unconstrained)"})
    f6 = R + "final_model_results/F6_final_model_monotonicity_by_regime.csv"
    if os.path.exists(f6):
        g6 = pd.read_csv(f6).groupby(["regime", "model"]).violation_pct_abs_1e3.mean().unstack()
        vv = vv.join(g6.rename(columns={"final blend v2 + envelope (kh, r_u)": "Final model (monotone calibration + envelope)", "Bishop (MVB surrogate)": "Bishop (MVB surrogate)"})[["Final model (monotone calibration + envelope)", "Bishop (MVB surrogate)"]], how="left")
        sty.update({"Final model (monotone calibration + envelope)": (FW, "D", "-"), "Bishop (MVB surrogate)": (MECH, "o", ":")})
    regs = [r for r in ("low-hazard", "rainfall", "seismic", "compound") if r in vv.index]; vv = vv.reindex(regs)
    for m, (c, mk, ls) in sty.items():
        if m in vv: axs[1].plot(range(len(regs)), vv[m].values, ls, marker=mk, color=c, ms=5, mfc="white" if m.startswith("Bishop") else c, label=m)
    axs[1].set_xticks(range(len(regs)), regs); axs[1].set(ylabel="Mean monotonicity violations (%)", title="(b) Physical consistency per loading regime"); axs[1].legend(fontsize=7)
    save("Fig25_consistency_under_combined_loading")

# ------------------------------------------------------------------ Fig 26 robustness
@fig("Fig26")
def _():
    a = pd.read_csv(RV + "R3_input_noise_robustness.csv"); b = pd.read_csv(RV + "R4_missing_feature_robustness.csv")
    f, axs = plt.subplots(1, 2, figsize=(11, 3.9), gridspec_kw=dict(width_ratios=[.9, 1.2]))
    lv = list(dict.fromkeys(a.level)); sty = {"Proposed framework": (FW, "o", "-"), "LightGBM (data-only)": (BASE, "^", "-"), "Mechanics-anchored hybrid": (FW2, "s", "--"),
                                              "Mechanics reference (Bishop surrogate)": (MECH, "o", ":")}
    for m, (c, mk, ls) in sty.items():
        e = a[a.model == m].set_index("level").reindex(lv); axs[0].plot(range(len(lv)), e.prediction_shift_RMSE, ls, marker=mk, color=c, ms=5, mfc="white" if m.startswith("Mech") and "reference" in m else c, label=m)
    axs[0].set_xticks(range(len(lv)), ["clean", "good SI", "typical", "poor"]); axs[0].set(ylabel="RMSE between clean and noisy predictions", title="(a) Response to input measurement error"); axs[0].legend(fontsize=6.8)
    g = list(dict.fromkeys(b.missing)); y = np.arange(len(g)); hh = .38
    for i, (m, c) in enumerate((("Proposed framework", FW), ("LightGBM (data-only)", BASE))):
        e = b[b.model == m].set_index("missing").reindex(g); axs[1].barh(y + (i - .5) * hh, e.RMSE_increase.clip(lower=0), hh, color=c, label=m)
    axs[1].set_yticks(y, [s.split(" (")[0].replace("phi", "φ").replace("gamma", "γ").replace("beta", "β").replace("r_u", "rᵤ").replace("kh", "kₕ") for s in g]); axs[1].invert_yaxis(); axs[1].grid(axis="y", visible=False); axs[1].set_xscale("symlog", linthresh=.001)
    axs[1].set(xlabel="RMSE increase when the input is missing (median-imputed)", title="(b) Which inputs are indispensable"); axs[1].legend(fontsize=7, loc="upper right")
    save("Fig26_robustness_noise_and_missing_inputs")

# ------------------------------------------------------------------ Fig 27 ICE / PDP
@fig("Fig27")
def _():
    t = pd.read_csv(RV + "R6b_PDP_curves.csv"); f, axs = plt.subplots(1, 2, figsize=(10, 3.8), sharey=True)
    sty = {"Proposed framework": (BASE, "-", "o"), "Mechanics-anchored hybrid": (FW, "-", "D"), "Bishop (MVB surrogate)": (MECH, "--", "o")}
    for ax, var, ttl, c0 in ((axs[0], "SeismicCoefficient", "(a) Seismic coefficient kₕ", SEIS), (axs[1], "PorePressureRatio", "(b) Pore-pressure ratio rᵤ", RAIN)):
        for m, (c, ls, mk) in sty.items():
            e = t[(t.variable == var) & (t.model == m)]; ax.fill_between(e.x, e.q10, e.q90, color=c, alpha=.10, lw=0)
            ax.plot(e.x, e.PDP_norm, ls, marker=mk, color=c, ms=3.5, mfc="white" if m.startswith("Bishop") else c, label=m)
        ax.set(xlabel=ttl.split(") ")[1], title=ttl); ax.axhline(1, color=S.AXIS, lw=.8)
    axs[0].set_ylabel("FoS / FoS(x = 0)  (partial dependence, 10–90 % band)"); axs[0].legend(fontsize=7, loc="lower left")
    save("Fig27_ICE_partial_dependence_vs_mechanics")

# ------------------------------------------------------------------ Fig 28 real-world calibration and remediation
@fig("Fig28")
def _():
    r = pd.read_csv(RV + "R8b_reliability_diagram.csv"); c = pd.read_csv(RV + "R8_realworld_calibration_and_cost.csv", index_col=0); m = c.loc["mean"]
    t = pd.read_csv(RV + "R7_counterfactual_remediation.csv"); t = t[(t.target_FoS == 1.3) & (t.kh_band != "all")]
    f, axs = plt.subplots(1, 2, figsize=(10.4, 3.9))
    ax = axs[0]; ax.plot([0, 1], [0, 1], ls=(0, (4, 3)), color=MECH, lw=.9); ax.scatter(r.mean_predicted, r.observed_failure_rate, s=r.n * 1.2 + 10, color=FW, edgecolor="white", lw=.8, zorder=3)
    ax.set(xlabel="Predicted P(failure)", ylabel="Observed failure rate", title="(a) Calibration on 363 real slopes", xlim=(0, 1), ylim=(0, 1))
    label(ax, .03, .97, f"Brier {m.Brier:.3f} (no-skill {m.Brier_climatology:.3f})\nECE {m.ECE_10bins:.3f}   AUROC {m.AUROC:.3f}\nmarker area scales with slopes in bin", transform=ax.transAxes, va="top", color=S.INK)
    ax = axs[1]; x = np.arange(len(t)); w = .26
    ax.bar(x - w, t.pct_fixable_by_drainage_alone, w, color=RAIN, label="drainage alone"); ax.bar(x, t.pct_fixable_by_regrading_alone, w, color=MECH, label="regrading alone")
    ax.bar(x + w, t.pct_needing_both_or_structural, w, color=COMP, label="both / structural")
    for i, (a_, b_, c_) in enumerate(zip(t.pct_fixable_by_drainage_alone, t.pct_fixable_by_regrading_alone, t.pct_needing_both_or_structural)):
        for dx, v in ((-w, a_), (0, b_), (w, c_)): label(ax, i + dx, v + 1, f"{v:.0f}", ha="center", fontsize=6.8)
    ax.set_xticks(x, t.kh_band.str.replace("kh", "kₕ")); ax.grid(axis="x", visible=False); ax.legend(fontsize=7, loc="upper left")
    ax.set(ylabel="Slopes below FoS 1.3 (%)", title="(b) Remedy needed to reach FoS 1.3 (Bishop-verified)", ylim=(0, 100))
    save("Fig28_calibration_and_remediation")

# ------------------------------------------------------------------ Fig 29 residual diagnostics
@fig("Fig29")
def _():
    p = pd.read_csv(RV + "R2d_residual_points_3000.csv"); t = pd.read_csv(RV + "R2_residuals_by_subset.csv"); t = t[t.model == "Proposed framework"]
    f, axs = plt.subplots(1, 2, figsize=(10.4, 3.9)); fams = sorted(p.family.unique()); cs = S.ramp(S.EARTH_SEQ, 4, .3, .95)
    for fm, c in zip(fams, cs):
        e = p[p.family == fm]; axs[0].scatter(e.FoS_true, e.FoS_framework - e.FoS_true, s=4, color=c, lw=0, alpha=.7, label=fm, rasterized=True)
    axs[0].axhline(0, color=MECH, lw=.9, ls=(0, (4, 3))); axs[0].set(xlabel="True FoS (dataset)", ylabel="Residual (predicted − true)", title="(a) Residuals by scenario family", ylim=(-.3, .3))
    axs[0].legend(markerscale=3, fontsize=7, loc="upper right")
    b = t[t.subset.str.contains("FoS")]; y = np.arange(len(b))
    axs[1].barh(y, b.P95_abs_error, color=BASE, height=.55, label="P95 |error|"); axs[1].scatter(b.RMSE, y, color=FW, zorder=3, s=36, label="RMSE")
    axs[1].set_yticks(y, b.subset.str.replace("<=", "≤").str.replace(">=", "≥")); axs[1].invert_yaxis(); axs[1].grid(axis="y", visible=False); axs[1].legend(fontsize=7, loc="upper center", bbox_to_anchor=(.5, -.16), ncol=2)
    axs[1].set(xlabel="FoS error", title="(b) Error by FoS band")
    save("Fig29_residual_diagnostics")

json.dump(dict(figures=done, failed=failed), open(OUT + "figure_list_review.json", "w"), indent=1); print("figures:", done, "failed:", failed)
