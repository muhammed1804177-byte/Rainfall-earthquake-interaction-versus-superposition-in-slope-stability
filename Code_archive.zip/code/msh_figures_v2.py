"""Revision figures: interaction decomposition, independent Morgenstern-Price validation of the calibrated equation,
time-history Newmark check, and the Tandikat analysis tied to the 2009 ground motion."""
import os, sys, json
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap as LSC
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/figures_manuscript/"
plt.rcParams.update({"font.family": "Inter", "font.size": 8.2, "axes.titleweight": "semibold", "axes.titlesize": 8.8, "axes.titlelocation": "left",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#BDB6A8", "axes.grid": True, "grid.color": "#E6E1D8",
                     "grid.linewidth": .5, "pdf.fonttype": 42, "legend.frameon": False})
INK, INK2 = "#1F2328", "#555B61"
TEAL, AMBER, INDIGO = "#1F8A84", "#D99A1E", "#3F3D8F"        # factorial palette (teal, amber, indigo)
STEEL, ORANGE = "#3F72A3", "#CC6A28"                         # verification palette
OLIVE, COPPER, SLATE = "#9AAA3C", "#A3561E", "#46525F"       # yield palette
def save(f, n):
    for e in ("png", "pdf"): f.savefig(OUT + n + "." + e, dpi=600 if e == "png" else None, facecolor="white", bbox_inches="tight")
    plt.close(f); print("saved", n)

# ---------------- interaction decomposition ----------------
V = pd.read_csv(ROOT + "/interaction_v2/V1_interaction_decomposition_600_slopes.csv")
ru, kh = sorted(V.ru.unique()), sorted(V.kh.unique())
f, ax = plt.subplots(1, 3, figsize=(10.4, 3.5), gridspec_kw=dict(width_ratios=[1, 1.55, 1], wspace=.42))
M = V.pivot(index="ru", columns="kh", values="median_I").values
im = ax[0].imshow(M, origin="lower", cmap=LSC.from_list("i", ["#2B2A6B", "#6D6BB0", "#CFCDE8", "#F6F5F0"]), vmin=.98, vmax=1, aspect="auto")
for i in range(len(ru)):
    for j in range(len(kh)): ax[0].text(j, i, f"{M[i, j]:.3f}", ha="center", va="center", fontsize=6.6, color="white" if M[i, j] < .99 else INK)
ax[0].set_xticks(range(len(kh)), [f"{k:g}" for k in kh]); ax[0].set_yticks(range(len(ru)), [f"{r:g}" for r in ru]); ax[0].grid(False)
ax[0].set(xlabel="Seismic coefficient $k_h$", ylabel="Pore-pressure ratio $r_u$", title="(a) Median interaction index $I$")
cb = f.colorbar(im, ax=ax[0], fraction=.046, pad=.03); cb.ax.tick_params(labelsize=6.5)
S = V[(V.ru > 0) & (V.kh > 0)].copy(); S["lab"] = [f"{a:g}/{b:g}" for a, b in zip(S.ru, S.kh)]; x = np.arange(len(S))
b1 = S.pct_fail_single; b2 = S.pct_compound_only_by_superposition; b3 = S.pct_caused_by_interaction
ax[1].bar(x, b1, .72, color="#C9C6BC", label="fails under one hazard alone")
ax[1].bar(x, b2, .72, bottom=b1, color=TEAL, label="fails only when combined: superposition")
ax[1].bar(x, b3, .72, bottom=b1 + b2, color=AMBER, label="fails only because of the interaction")
ax[1].set_xticks(x, S.lab, rotation=90, fontsize=6.4); ax[1].grid(axis="x", visible=False)
ax[1].set(ylabel="Slopes failing under combined loading (%)", xlabel="$r_u$ / $k_h$", title="(b) Why combined loading fails slopes")
ax[1].legend(loc="upper left", fontsize=6.8)
for r_, c, mk in zip([.1, .2, .3, .4], ["#A9D3CF", TEAL, "#16615D", INDIGO], ["o", "s", "^", "D"]):
    d = V[(V.ru == r_) & (V.kh > 0)]; ax[2].plot(d.kh, d.median_interaction_share_of_loss_pct, "-", marker=mk, color=c, ms=4, label=f"$r_u$ = {r_:g}")
ax[2].set(xlabel="Seismic coefficient $k_h$", ylabel="Share of combined FoS loss (%)", title="(c) Loss caused by the interaction", ylim=(0, 2.2))
ax[2].legend(fontsize=7, loc="upper left")
save(f, "Fig_interaction_decomposition")

# ---------------- independent Morgenstern-Price validation ----------------
D = pd.read_csv(ROOT + "/validation_v2/V2b_MP_points.csv"); T2 = pd.read_csv(ROOT + "/validation_v2/V2_equation_vs_Morgenstern_Price.csv")
d = D[D.in_range]; f, ax = plt.subplots(1, 2, figsize=(8.6, 3.5), gridspec_kw=dict(wspace=.32))
for k, c in zip(sorted(d.kh.unique()), ["#A7C4E0", "#6F9DCB", STEEL, "#1F4E7A"]):
    e = d[d.kh == k]; ax[0].scatter(e.fmp, e.F_eq, s=5, color=c, alpha=.7, lw=0, label=f"$k_h$ = {k:g}")
lim = max(d.fmp.max(), d.F_eq.max()) * 1.03; ax[0].plot([0, lim], [0, lim], color=INK2, lw=.8, ls="--"); ax[0].set(xlim=(0, lim), ylim=(0, lim))
r = T2[(T2.subset == "inside calibration range") & (T2.model == "calibrated equation")].iloc[0]
ax[0].text(.04, .96, f"n = {int(r.n)}\n$R^2$ = {r.R2:.3f}, MAPE = {r.MAPE_pct:.1f} %\nFoS < 1 agreement = {r.class_agreement_pct:.1f} %", transform=ax[0].transAxes, va="top", fontsize=7.2)
ax[0].set(xlabel="Morgenstern–Price FoS (Waris et al.)", ylabel="Calibrated equation FoS", title="(a) Equation vs independent solutions"); ax[0].legend(loc="lower right", fontsize=6.8, markerscale=2.5)
err = lambda col: (D[col] / D.fmp - 1).where(D.fmp >= .3) * 100
for col, c, off, lab in [("F_eq", STEEL, -.012, "calibrated equation"), ("F_infinite", ORANGE, .012, "infinite-slope form")]:
    g = D.assign(e=err(col).abs()).groupby("kh").e.median(); ax[1].plot(g.index + off, g.values, "-o", color=c, ms=4.5, label=lab)
ax[1].axvspan(.205, .31, color="#EFE8DA", zorder=0); ax[1].text(.21, ax[1].get_ylim()[1] * .9 if ax[1].get_ylim()[1] > 0 else 5, "outside\ncalibration", fontsize=7, color=INK2, va="top")
ax[1].set(xlabel="Seismic coefficient $k_h$", ylabel="Median absolute error (%)", title="(b) Error by seismic coefficient (all slopes)"); ax[1].legend(fontsize=7, loc="upper left")
save(f, "Fig_equation_vs_Morgenstern_Price")

# ---------------- time-history Newmark check ----------------
TH = pd.read_csv(ROOT + "/case_tandikat/T9_time_history_newmark_event.csv"); POP = pd.read_csv(ROOT + "/case_tandikat/T10_population_time_history_vs_Jibson.csv")
mot = np.load(ROOT + "/case_tandikat/motions_pga028.npy"); t = np.arange(mot.shape[1]) * .01
f, ax = plt.subplots(1, 3, figsize=(10.6, 3.3), gridspec_kw=dict(width_ratios=[1.4, 1, 1], wspace=.38))
ax[0].plot(t, mot[0], color=SLATE, lw=.45)
for k, c, lab in [(.158, OLIVE, "$k_y$ dry = 0.158"), (.103, COPPER, "$k_y$ wet = 0.103")]: ax[0].axhline(k, color=c, lw=1.1, ls="--"); ax[0].text(0.5, k + .012, lab, color=c, fontsize=7, ha="left", bbox=dict(fc="white", ec="none", pad=.5))
ax[0].set(xlabel="Time (s)", ylabel="Acceleration (g)", title="(a) Synthetic motion, PGA 0.28 g", ylim=(-.32, .36))
cases = TH.case.tolist(); y = np.arange(len(cases)); med = TH.D_time_history_median_cm.replace(np.inf, np.nan)
cols = [OLIVE, COPPER, "#7A3E14", INDIGO]
for i, (m_, lo, hi) in enumerate(zip(med, TH.D_16pct_cm, TH.D_84pct_cm)):
    if np.isfinite(m_): ax[1].errorbar(m_, i, xerr=[[m_ - lo], [hi - m_]], fmt="o", color=cols[i], ms=5, capsize=2)
    else: ax[1].text(1.0, i, "runaway in all motions ($k_y$ → 0)", fontsize=7.2, color=cols[i], va="center")
    jb = TH.D_Jibson2007_cm.iloc[i]
    if np.isfinite(jb): ax[1].plot(jb, i, "D", mfc="white", mec=cols[i], ms=4.5)
ax[1].set_yticks(y, ["dry", "wet, $r_u$ 0.10", "wet, $r_u$ 0.20", "wet + cyclic $\\Delta r_u$"]); ax[1].set_ylim(-.5, 3.5); ax[1].invert_yaxis(); ax[1].set_xscale("log"); ax[1].set_xlim(.3, 300)
ax[1].plot([], [], "o", color=INK2, label="time history (median, 16–84 %)"); ax[1].plot([], [], "D", mfc="white", mec=INK2, label="Jibson (2007)"); ax[1].legend(fontsize=6.6, loc="upper right")
ax[1].set(xlabel="Newmark displacement (cm)", title="(b) Tandikat toe, 50 motions")
xx = np.arange(len(POP)); ax[2].bar(xx - .18, POP.pct_fail_or_gt5cm_TH, .36, color=SLATE, label="time history"); ax[2].bar(xx + .18, POP.pct_fail_or_gt5cm_Jibson, .36, color=OLIVE, label="Jibson (2007)")
for i, (a_, b_) in enumerate(zip(POP.pct_fail_or_gt5cm_TH, POP.pct_fail_or_gt5cm_Jibson)): ax[2].text(i - .18, a_ + .8, f"{a_:.0f}", ha="center", fontsize=6.8); ax[2].text(i + .18, b_ + .8, f"{b_:.0f}", ha="center", fontsize=6.8)
ax[2].set_xticks(xx, [f"$r_u$ = {r:g}" for r in POP.ru]); ax[2].grid(axis="x", visible=False)
ax[2].set(ylabel="Slopes with $D_N$ > 5 cm (%)", title="(c) Bishop $k_y$, PGA 0.30 g"); ax[2].legend(fontsize=7, loc="upper left")
save(f, "Fig_time_history_newmark")

# ---------------- Tandikat analysis tied to the event ----------------
th, ph = np.radians(30), np.radians(39); Tt, Pp = np.tan(th), np.tan(ph)
F = lambda r, k: Pp * (1 - r - k * Tt) / (Tt + k); KY = lambda r: np.maximum((Pp * (1 - r) - Tt) / (1 + Pp * Tt), 0); F0 = F(0, 0)
rr = np.linspace(0, .45, 300); f, ax = plt.subplots(1, 3, figsize=(10.6, 3.4), gridspec_kw=dict(wspace=.36))
for k, c, ls in [(0, SLATE, "-"), (.14, TEAL, "-")]: ax[0].plot(rr, F(rr, k), color=c, ls=ls, lw=1.5, label=f"$k_h$ = {k:g}" + (" (= 0.5 PGA)" if k else " (static)"))
ax[0].plot(rr, F(rr, 0) * F(0, .14) / F0, color=AMBER, ls="--", lw=1.2, label="$k_h$ = 0.14, no interaction")
ax[0].axhline(1, color=INK2, lw=.8, ls=":"); ax[0].axvline(.10, color="#BDB6A8", lw=.8)
for (r_, k_, lab, dx, dy) in [(0, 0, "dry 1.40", .015, .03), (.10, 0, "rain 1.26", .015, .03), (0, .14, "shaking 1.04", .02, .025), (.10, .14, "both 0.92", .015, -.07)]:
    ax[0].plot(r_, F(r_, k_), "o", mfc="white", mec=INK, ms=5); ax[0].text(r_ + dx, F(r_, k_) + dy, lab, fontsize=7)
ax[0].set(xlabel="Pore-pressure ratio on slip plane $\\tilde r_u$", ylabel="Factor of safety", ylim=(.55, 1.5), title="(a) Event state (toe)"); ax[0].legend(fontsize=6.6, loc="lower left")
for d_, c, ls in [(0, SLATE, "-"), (.1, TEAL, "--"), (.2, INDIGO, "-.")]:
    ax[1].plot(rr, KY(rr + d_ * (1 - rr)), color=c, ls=ls, lw=1.4, label=f"cyclic $\\Delta\\tilde r_u$ = {d_:g}")
ax[1].axhline(.14, color=COPPER, lw=.9, ls=":"); ax[1].text(.44, .145, "$k_h$ = 0.14", color=COPPER, fontsize=7, ha="right")
ax[1].axvline(.10, color="#BDB6A8", lw=.8); ax[1].set(xlabel="Pore-pressure ratio on slip plane $\\tilde r_u$", ylabel="Yield coefficient $k_y$", ylim=(0, .17), title="(b) Seismic capacity"); ax[1].legend(fontsize=6.8)
KH = np.linspace(.0, .25, 160); RR = np.linspace(0, .35, 160); A, B = np.meshgrid(RR, KH)
FF = F(A, B); cs = ax[2].contourf(A, B, FF, levels=[.5, .7, .8, .9, 1, 1.1, 1.2, 1.3, 1.5], cmap=LSC.from_list("f", ["#7A3E14", "#D9A15E", "#F3E6CF", "#CFE3E1", TEAL]))
ax[2].contour(A, B, FF, levels=[1], colors=INK, linewidths=1.4); ax[2].contour(A, B, F(A, 0) * F(0, B) / F0, levels=[1], colors=AMBER, linewidths=1.1, linestyles="--")
ax[2].plot(.10, .14, "o", mfc="white", mec=INK, ms=6); ax[2].text(.112, .145, "2009 event (toe)", fontsize=7)
ax[2].text(.012, .015, "$F$ = 1 (solid); no-interaction $F$ = 1 (dashed)", fontsize=6.6, color=INK2); ax[2].grid(False)
cb = f.colorbar(cs, ax=ax[2], fraction=.046, pad=.03); cb.set_label("Factor of safety", fontsize=7); cb.ax.tick_params(labelsize=6.5)
ax[2].set(xlabel="Pore-pressure ratio on slip plane $\\tilde r_u$", ylabel="Seismic coefficient $k_h$", title="(c) Sensitivity to $\\tilde r_u$ and $k_h$")
save(f, "Fig_Tandikat_analysis_v2")
