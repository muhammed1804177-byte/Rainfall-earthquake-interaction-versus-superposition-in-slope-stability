"""FINAL MODEL of the revised study: the user's attention-fusion framework as the data branch, blended in log space with
the mechanics-anchored branch (Bishop surrogate x environment calibration):  log F = w log F_framework + (1-w) log F_anchored.
w = smallest weight whose VALIDATION R2 >= 0.93 (the study's predefined benchmark). Then: monotone envelope (kh, r_u) check,
split-conformal intervals from the untouched calibration split, Bishop sensitivity audit. Test used once."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_review as RV
from sklearn.metrics import r2_score, accuracy_score, f1_score
from scipy.stats import spearmanr
U, MO, ME = RV.U, RV.MO, RV.ME; ROOT = RV.ROOT; OUT = ROOT + "/final_model_results/"; os.makedirs(OUT, exist_ok=True); CK = RV.WK + "/finalblend/"; os.makedirs(CK, exist_ok=True)
T0 = time.time()
def say(*a): print(f"[FB {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(n, fn):
    f = CK + n + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
y = U.sva.FoS.values; A = U.A_sva
SPL = {"val": U.s_va, "calib": U.s_ca, "test": U.s_te}
def anchored(X): return np.exp(RV.prior(X) + RV.MAH[RV.D_].predict(X[RV.ENV]))
def branches(X): return np.clip(MO.fw(X), .05, 20), np.clip(anchored(X), .05, 20)
BR = cached("branches", lambda: {k: branches(A.iloc[v].reset_index(drop=True)) for k, v in SPL.items()})
blend = lambda w, fa, fd: np.clip(np.exp(w * np.log(fa) + (1 - w) * np.log(fd)), .25, 5)
rows = []
for w in np.round(np.linspace(0, 1, 41), 3):
    p = blend(w, *BR["val"]); yv = y[U.s_va]; rows.append(dict(w=w, val_R2=r2_score(yv, p), val_accuracy=accuracy_score(U.to_class(yv), U.to_class(p))))
V = pd.DataFrame(rows); W = float(V[V.val_R2 >= .93].w.min()); V["selected"] = V.w == W; V.round(4).to_csv(OUT + "F1_weight_selection_validation.csv", index=False)
say("selected w =", W)
# test metrics (once)
yt = y[U.s_te]; pt = blend(W, *BR["test"]); yc = y[U.s_ca]; pc = blend(W, *BR["calib"])
res = []
for nm, p in (("Framework (data branch only)", np.clip(BR["test"][0], .25, 5)), ("Anchored branch only", np.clip(BR["test"][1], .25, 5)), (f"FINAL: framework-mechanics blend (w={W:g})", pt)):
    a, b = U.to_class(yt), U.to_class(p)
    res.append(dict(model=nm, R2=r2_score(yt, p), RMSE=float(np.sqrt(np.mean((yt - p) ** 2))), Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1),
                    unsafe_pct=np.mean((yt < 1) & (p >= 1.3)) * 100))
# conformal on the log scale from the untouched calibration split (relative intervals: wider where FoS is larger)
r_c = np.abs(np.log(yc) - np.log(pc)); cov = {}
for al in (.1, .05):
    q = np.quantile(r_c, np.ceil((len(r_c) + 1) * (1 - al)) / len(r_c)); lo, hi = pt * np.exp(-q), pt * np.exp(q)
    cov[f"coverage_{int((1-al)*100)}"] = float(np.mean((yt >= lo) & (yt <= hi))); cov[f"rel_halfwidth_{int((1-al)*100)}_pct"] = float((np.exp(q) - 1) * 100)
    cov[f"confident_pct_{int((1-al)*100)}"] = float(np.mean(U.to_class(lo) == U.to_class(hi)) * 100)
    m = U.to_class(lo) == U.to_class(hi); cov[f"confident_accuracy_{int((1-al)*100)}"] = float(np.mean(U.to_class(pt[m]) == U.to_class(yt[m])))
for r in res: r.update(cov if r["model"].startswith("FINAL") else {})
T = pd.DataFrame(res); T.round(5).to_csv(OUT + "F2_final_model_test.csv", index=False); say("\n" + T.round(4).to_string())
# sensitivity audit against Bishop (same 300 slopes and steps as M4)
S = U.TS["A"].sample(300, random_state=11).reset_index(drop=True)
MAP = {"c": "Cohesion_kPa", "phi": "FrictionAngle_deg", "beta": "SlopeAngle_deg", "H": "SlopeHeight_m", "gamma": "UnitWeight_kN_m3", "ru": "PorePressureRatio", "kh": "SeismicCoefficient"}
STEP = {"c": 3., "phi": 1.5, "beta": 2., "H": 2., "gamma": .5, "ru": .03, "kh": .02}
B = joblib.load(ME.CK + "m4_sens_BishopPSLEM.joblib")
def sens(f):
    out = {}
    for k, col in MAP.items():
        Dp, Dm = S.copy(), S.copy(); Dp[col] = np.clip(Dp[col] + STEP[k], U.LO_[col], U.HI_[col]); Dm[col] = np.clip(Dm[col] - STEP[k], U.LO_[col], U.HI_[col])
        Dp, Dm = U.recompute(Dp), U.recompute(Dm); dx = Dp[col].values - Dm[col].values
        out[k] = np.where(dx > 0, (np.log(f(Dp)) - np.log(f(Dm))) / np.where(dx > 0, dx, 1), np.nan)
    return out
SF = cached("sens_final", lambda: sens(lambda X: blend(W, *branches(X))))
au = []
for k in MAP:
    ok = np.isfinite(B[k]) & np.isfinite(SF[k]); au.append(dict(variable=k, ratio_to_Bishop=np.median(SF[k][ok]) / np.median(B[k][ok]), spearman_with_Bishop=spearmanr(B[k][ok], SF[k][ok])[0],
                                                               sign_agreement_pct=np.mean(np.sign(SF[k][ok]) == np.sign(B[k][ok])) * 100))
pd.DataFrame(au).round(4).to_csv(OUT + "F3_final_model_mechanics_audit.csv", index=False); say("\n" + pd.DataFrame(au).round(3).to_string())
# monotonicity of the final model (1,500 test slopes) before / after the envelope
X = U.TS["A"].sample(1500, random_state=7).reset_index(drop=True); fF = lambda Z: blend(W, *branches(Z))
def viol(f, X):
    base = f(X); r = {}
    for col, st, sg in (("PorePressureRatio", .05, -1), ("SeismicCoefficient", .03, -1), ("SlopeAngle_deg", 3, -1), ("Cohesion_kPa", 5, 1), ("FrictionAngle_deg", 2, 1)):
        Xp = X.copy(); Xp[col] = np.minimum(Xp[col] + st, U.HI_[col]); r[col] = float(np.mean(sg * (f(U.recompute(Xp)) - base) < -1e-3) * 100)
    r["mean"] = float(np.mean(list(r.values()))); return r
VI = cached("viol", lambda: {"final blend": viol(fF, X), "final blend + envelope": viol(lambda Z: MO.envelope(Z, f=fF), X.iloc[:500].reset_index(drop=True))})
pd.DataFrame(VI).T.round(3).to_csv(OUT + "F4_final_model_monotonicity.csv"); say(VI); say("DONE")
