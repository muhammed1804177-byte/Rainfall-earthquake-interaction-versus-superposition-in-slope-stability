"""Final-model physical-consistency fix (problem found in I5b: the anchored branch's environment calibration is not
monotone in rainfall, and the mechanics-anchored hybrid violates monotonicity in the compound regime).
Fix: the environment calibration is retrained with monotone constraints that encode hydrology
(rainfall -, groundwater depth +, groundwater rise rate -, weathering index -). Then the final blend
log F = w log F_framework + (1-w) [log P_mech + g_mono(environment)] is re-selected on validation (same rule: smallest
w with R2 >= 0.93), and evaluated once on test: accuracy, conformal intervals, Bishop sensitivity audit, monotonicity per
loading regime (absolute 1e-3 and relative 1 % thresholds, rainfall included through the observed rainfall -> r_u chain),
and reproduction of the mechanics rainfall x seismic interaction in an in-envelope 2 x 2 loading matrix."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_review as RV
import lightgbm as lgb
from scipy import stats
from sklearn.metrics import r2_score, accuracy_score, f1_score
U, MO, ME, FW = RV.U, RV.MO, RV.ME, RV.FW
ROOT = RV.ROOT; OUT = ROOT + "/final_model_results/"; CK = RV.WK + "/finalblend/"; T0 = time.time()
def say(*a): print(f"[FM {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(n, fn):
    f = CK + n + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
y = U.sva.FoS.values; A = U.A_sva; cls = U.to_class
SPL = {"train": U.s_tr, "val": U.s_va, "calib": U.s_ca, "test": U.s_te}
MONO = {"Rainfall_mm_day": -1, "GroundwaterDepth_m": 1, "GroundwaterRiseRate_m_day": -1, "WeatheringIndex": -1}
def fit_dm():
    Xtr, Xva = A.iloc[U.s_tr][RV.ENV], A.iloc[U.s_va][RV.ENV]
    ttr = np.log(y[U.s_tr]) - RV.prior(A.iloc[U.s_tr]); tva = np.log(y[U.s_va]) - RV.prior(A.iloc[U.s_va])
    m = lgb.LGBMRegressor(n_estimators=5000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=42, n_jobs=2,
                          monotone_constraints=[MONO.get(c, 0) for c in RV.ENV], monotone_constraints_method="advanced")
    return m.fit(Xtr, ttr, eval_set=[(Xva, tva)], callbacks=[lgb.early_stopping(150, verbose=False)])
DM = cached("d_mono", fit_dm)
def anch_v1(X): return np.clip(np.exp(RV.prior(X) + RV.MAH[RV.D_].predict(X[RV.ENV])), .05, 20)
def anch_v2(X): return np.clip(np.exp(RV.prior(X) + DM.predict(X[RV.ENV])), .05, 20)
BR = joblib.load(CK + "branches.joblib")                              # framework and v1 anchored predictions (val, calib, test)
A2 = cached("anch_v2", lambda: {k: anch_v2(A.iloc[SPL[k]].reset_index(drop=True)) for k in ("val", "calib", "test")})
blend = lambda w, fa, fd: np.clip(np.exp(w * np.log(fa) + (1 - w) * np.log(fd)), .25, 5)
WG = np.round(np.linspace(0, 1, 41), 3); sel = {}
for v, an in (("v1 (unconstrained calibration)", {k: BR[k][1] for k in BR}), ("v2 (monotone hydrology calibration)", A2)):
    vr = np.array([r2_score(y[U.s_va], blend(w, BR["val"][0], an["val"])) for w in WG]); sel[v] = (float(WG[np.argmax(vr >= .93)]), an)
rows = []; yt, yc = y[U.s_te], y[U.s_ca]
for v, (W, an) in sel.items():
    pt, pc = blend(W, BR["test"][0], an["test"]), blend(W, BR["calib"][0], an["calib"]); a, b = cls(yt), cls(pt)
    r = dict(model=f"final blend {v}", w=W, R2=r2_score(yt, pt), RMSE=float(np.sqrt(np.mean((yt - pt) ** 2))), Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1),
             unsafe_pct_true_lt1_pred_ge1_3=np.mean((yt < 1) & (pt >= 1.3)) * 100, anchored_branch_R2=r2_score(yt, np.clip(an["test"], .25, 5)))
    rc = np.abs(np.log(yc) - np.log(pc))
    for al in (.1, .05):
        q = np.quantile(rc, np.ceil((len(rc) + 1) * (1 - al)) / len(rc)); lo, hi = pt * np.exp(-q), pt * np.exp(q); m = cls(lo) == cls(hi); k = int(round((1 - al) * 100))
        r.update({f"coverage_{k}": np.mean((yt >= lo) & (yt <= hi)), f"rel_halfwidth_{k}_pct": (np.exp(q) - 1) * 100, f"confident_pct_{k}": m.mean() * 100, f"confident_accuracy_{k}": np.mean(cls(pt[m]) == cls(yt[m]))})
    rows.append(r)
T = pd.DataFrame(rows); T.round(4).to_csv(OUT + "F5_final_model_v1_vs_v2_test.csv", index=False); say("\n" + T.round(4).T.to_string())
W1, W2 = sel["v1 (unconstrained calibration)"][0], sel["v2 (monotone hydrology calibration)"][0]
f_v1 = lambda X: blend(W1, np.clip(MO.fw(X), .05, 20), anch_v1(X)); f_v2 = lambda X: blend(W2, np.clip(MO.fw(X), .05, 20), anch_v2(X))
# ---- monotonicity per loading regime
Ate = A.iloc[U.s_te][U.FEATS].reset_index(drop=True); REG = FW.REG_T
STP = {"PorePressureRatio": (.05, -1), "SeismicCoefficient": (.03, -1), "Rainfall_mm_day": (30, -1), "SlopeAngle_deg": (3, -1), "Cohesion_kPa": (5, 1), "FrictionAngle_deg": (2, 1)}
def chain(X): return U.recompute(X.assign(PorePressureRatio=np.clip(U.ru_m.predict(X[U.HYD]), .02, .6)))
def mono():
    rows = []
    for rg in ("low-hazard", "rainfall", "seismic", "compound"):
        X = Ate[REG == rg]; X = X.sample(min(600, len(X)), random_state=1).reset_index(drop=True)
        for m, f in (("final blend v1", f_v1), ("final blend v2", f_v2), ("final blend v2 + envelope (kh, r_u)", lambda Z: MO.envelope(Z, f=f_v2)), ("Bishop (MVB surrogate)", RV.mech)):
            X_ = X.iloc[:250] if "envelope" in m else X; base = f(X_)
            for v, (st, sg) in STP.items():
                Xp = X_.copy(); Xp[v] = np.minimum(Xp[v] + st, U.HI_[v]); Xp = U.recompute(Xp)
                if v == "Rainfall_mm_day": Xp, b0 = chain(Xp), f(chain(X_))
                else: b0 = base
                d = sg * (f(Xp) - b0)
                rows.append(dict(regime=rg, model=m, variable=v, violation_pct_abs_1e3=float(np.mean(d < -1e-3) * 100), violation_pct_rel_1pct=float(np.mean(d < -.01 * b0) * 100)))
        say("mono", rg)
    return pd.DataFrame(rows)
MT = cached("mono_regime", mono); MT.round(3).to_csv(OUT + "F6_final_model_monotonicity_by_regime.csv", index=False)
say("\n" + MT.pivot_table(index=["model", "variable"], columns="regime", values="violation_pct_abs_1e3").round(2).to_string())
# ---- Bishop sensitivity audit of v2
B = joblib.load(ME.CK + "m4_sens_BishopPSLEM.joblib"); SF = joblib.load(ME.CK + "m4_sens_Finalframework.joblib")
AUD = U.TS["A"].sample(300, random_state=11).reset_index(drop=True)
MAP = {"c": "Cohesion_kPa", "phi": "FrictionAngle_deg", "beta": "SlopeAngle_deg", "H": "SlopeHeight_m", "gamma": "UnitWeight_kN_m3", "ru": "PorePressureRatio", "kh": "SeismicCoefficient"}
STEP = {"c": 3., "phi": 1.5, "beta": 2., "H": 2., "gamma": .5, "ru": .03, "kh": .02}
def sens_d2():
    out = {}
    for k in MAP:
        Dp, Dm = AUD.copy(), AUD.copy(); Dp[MAP[k]] = np.clip(Dp[MAP[k]] + STEP[k], U.LO_[MAP[k]], U.HI_[MAP[k]]); Dm[MAP[k]] = np.clip(Dm[MAP[k]] - STEP[k], U.LO_[MAP[k]], U.HI_[MAP[k]])
        Dp, Dm = U.recompute(Dp), U.recompute(Dm); dx = Dp[MAP[k]].values - Dm[MAP[k]].values
        out[k] = np.where(dx > 0, (np.log(anch_v2(Dp)) - np.log(anch_v2(Dm))) / np.where(dx > 0, dx, 1), np.nan)
    return out
SD = cached("sens_d2", sens_d2); au = []
for k in MAP:
    s = W2 * SF[k] + (1 - W2) * SD[k]; ok = np.isfinite(s) & np.isfinite(B[k])
    au.append(dict(variable=k, ratio_to_Bishop=np.median(s[ok]) / np.median(B[k][ok]), spearman_with_Bishop=stats.spearmanr(s[ok], B[k][ok])[0], sign_agreement_pct=np.mean(np.sign(s[ok]) == np.sign(B[k][ok])) * 100))
pd.DataFrame(au).round(4).to_csv(OUT + "F7_final_model_v2_mechanics_audit.csv", index=False); say("\n" + pd.DataFrame(au).round(3).to_string())
# ---- in-envelope 2 x 2 loading matrix: does each model reproduce the mechanics interaction?
SELS = Ate[(Ate.SlopeAngle_deg.between(25.5, 34.5)) & (Ate.Cohesion_kPa.between(42, 68)) & (Ate.FrictionAngle_deg.between(30.5, 37.5))]
SELS = SELS.sample(min(400, len(SELS)), random_state=9).reset_index(drop=True)
COND = {"baseline": (.10, .02, 45.), "rainfall only": (.35, .02, 120.), "seismic only": (.10, .11, 45.), "rainfall + seismic": (.35, .11, 120.)}
def setc(X, c):
    ru, kh, rain = COND[c]; D = X.copy(); D["PorePressureRatio"], D["SeismicCoefficient"], D["Rainfall_mm_day"], D["GroundwaterDepth_m"] = ru, kh, rain, 10.; return U.recompute(D)
MODS = {"Proposed framework (data-only)": MO.fw, "Final blend v2": f_v2, "Bishop (MVB surrogate)": RV.mech}
R6 = cached("loading_2x2", lambda: {(m, c): np.clip(f(setc(SELS, c)), .05, 20) for m, f in MODS.items() for c in COND})
Fb = {c: R6[("Bishop (MVB surrogate)", c)] for c in COND}; Ib = Fb["rainfall + seismic"] * Fb["baseline"] / (Fb["rainfall only"] * Fb["seismic only"]); rows = []
for m in MODS:
    F_ = {c: R6[(m, c)] for c in COND}; I = F_["rainfall + seismic"] * F_["baseline"] / (F_["rainfall only"] * F_["seismic only"])
    d = {c: 1 - F_[c] / F_["baseline"] for c in COND}
    rows.append(dict(model=m, n=len(SELS), drop_rain_pct=np.median(d["rainfall only"]) * 100, drop_seismic_pct=np.median(d["seismic only"]) * 100, drop_combined_pct=np.median(d["rainfall + seismic"]) * 100,
                     additive_expectation_pct=np.median(d["rainfall only"] + d["seismic only"]) * 100, median_I=np.median(I), pct_synergistic_I_lt_0_995=np.mean(I < .995) * 100,
                     **{f"failure_pct_{c}": np.mean(F_[c] < 1) * 100 for c in COND},
                     compound_only_failure_pct=np.mean((F_["rainfall only"] >= 1) & (F_["seismic only"] >= 1) & (F_["rainfall + seismic"] < 1)) * 100,
                     spearman_I_with_Bishop=stats.spearmanr(I, Ib)[0]))
pd.DataFrame(rows).round(4).to_csv(OUT + "F8_loading_matrix_2x2_interaction_reproduction.csv", index=False); say("\n" + pd.DataFrame(rows).round(3).T.to_string()); say("DONE")
