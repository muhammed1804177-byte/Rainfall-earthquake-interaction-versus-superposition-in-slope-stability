"""Final combination table: best combination per k (3..20, chosen in the earlier run) re-tested on FRESH CV splits
with the strongest real-world layer; all-slope accuracy + leakage-free selective (confident-only) accuracy."""
import numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realpush.py")).read().split("FOLDS = [list(")[0])
T7 = pd.read_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T7_progressive_combinations_LightGBM_layer.csv"))
best = T7.sort_values("Accuracy", ascending=False).groupby("k").head(1).sort_values("k")
L = "Vote(CatBoost+LightGBM)"; rows = []
for r_ in best.itertuples():
    mem = r_.members.split(" | "); X = np.c_[A.values, E[mem].mean(1).values]
    acc, auc, cov, accc = [], [], [], []
    for rep in (11, 12):                                   # FRESH seeds, never used for choosing the combination
        pp, cut = np.zeros(len(y)), np.zeros(len(y))
        for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=rep).split(X, y, G):
            po = np.zeros(len(a))
            for ia, ib in StratifiedGroupKFold(3, shuffle=True, random_state=rep + 50).split(a, y[a], G[a]):
                po[ib] = LEARN[L]().fit(X[a][ia], y[a][ia]).predict_proba(X[a][ib])[:, 1]
            conf = np.abs(po - .5); c0 = conf.max()
            for cc in np.sort(np.unique(conf)):
                m = conf >= cc
                if m.sum() >= 10 and accuracy_score(y[a][m], po[m] > .5) >= .93: c0 = cc; break
            pp[b_] = LEARN[L]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]; cut[b_] = c0
        m = np.abs(pp - .5) >= cut
        acc.append(accuracy_score(y, pp > .5)); auc.append(roc_auc_score(y, pp)); cov.append(m.mean()); accc.append(accuracy_score(y[m], pp[m] > .5))
    rows.append(dict(k=r_.k, members=r_.members, accuracy_all_slopes=np.mean(acc), AUROC=np.mean(auc), confident_coverage_pct=np.mean(cov) * 100,
                     accuracy_on_confident=np.mean(accc), meets_93_all=np.mean(acc) >= .93, meets_93_confident=np.mean(accc) >= .93))
    print(f"k={r_.k:2d} acc_all {rows[-1]['accuracy_all_slopes']:.3f} auc {rows[-1]['AUROC']:.3f} | confident {rows[-1]['confident_coverage_pct']:.0f}% -> {rows[-1]['accuracy_on_confident']:.3f}", flush=True)
D = pd.DataFrame(rows); D.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T13_FINAL_combinations_3_to_20.csv"), index=False); print("DONE")
