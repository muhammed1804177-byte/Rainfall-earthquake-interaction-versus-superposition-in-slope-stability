"""
FINALISATION (all on available data, leakage-free)
 F1 physics-aware selection: among fusion configurations whose cross-fitted validation error is within 0.5 % of the
    best, choose the one with the best physical consistency on VALIDATION perturbations (no test data involved)
 F2 ablation on the FULL configuration (attention + residual + physics + interaction): accuracy AND physics metrics
 F3 final framework with 5 seeds -> test mean +- sd, conformal UQ, physics/interaction on test
 F4 stronger hazard-specialisation test (regime-only training vs regime-weighted vs generalist)
"""
import os, json, time, copy, warnings
import numpy as np, pandas as pd, joblib, torch
warnings.filterwarnings("ignore")
import msh_framework as FW                       # loads everything from cache (experts, shortlist, perturbation sets)
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score, accuracy_score, f1_score
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/final_results/"); CK = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptFinal/")
for p in (OUT, CK): os.makedirs(p, exist_ok=True)
T0 = time.time()
def say(*a): print(f"[FIN {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
U = FW.U; VA, TS, CA = FW.VA, FW.TS, FW.CA; y_te = FW.y_te; nSv = FW.nSv; yV = FW.yV
PERT = FW.PERT

def phys_on(m, EV, H):
    """physics metrics of a trained fusion model on a set of perturbed inputs (validation or test)."""
    with torch.no_grad():
        P = {k: FW.fpred(m, H[k], EV[k])[0].numpy() for k in EV}
    r = {f"viol_{c}": float(np.mean(sgn * (P[k] - P["base"]) < -1e-3) * 100) for k, (c, _, sgn) in PERT.items()}
    I = P["RE"] * P["base"] / (P["R"] * P["E"]); r["antagonistic_pct"] = float(np.mean(I > 1 + 1e-3) * 100); r["interaction_median"] = float(np.median(I))
    r["mean_violation_pct"] = float(np.mean([v for k, v in r.items() if k.startswith("viol_")])); return r
HV = {k: FW.hstate(A) for k, A in FW.PS_VA.items()}

# ---------------- F1 physics-aware selection (validation only)
say("F1 physics-aware selection")
CFG_ALL = {**FW.CONFIGS, "attention + residual + physics + interaction (FULL)": dict(mode="attention", residual=True)}
def f1():
    rows = []
    for sn, cols in FW.SHORT.items():
        EV = FW.EVcache(cols)
        for cn, kw in CFG_ALL.items():
            p = FW.fuse_avg(cols, FW.PV) if kw["mode"] == "average" and not kw.get("residual", True) else FW.crossfit_fusion(cols, **kw)
            m = FW.train_fusion(cols, seed=0, EV=EV, **kw); ph = phys_on(m, EV, HV)
            rows.append(dict(subset=sn, k=len(cols), config=cn, val_RMSE=FW.rmse(yV, p[:nSv]), val_compound_RMSE=FW.rmse(yV[FW.REG_V == "compound"], p[:nSv][FW.REG_V == "compound"]), **ph))
            say(f"  {sn:14s} {cn[:44]:44s} RMSE {rows[-1]['val_RMSE']:.4f}  viol {ph['mean_violation_pct']:.2f}%  antag {ph['antagonistic_pct']:.1f}%")
    return pd.DataFrame(rows)
S = cached("f1", f1); best = S.val_RMSE.min(); S["within_0.5pct_of_best"] = S.val_RMSE <= best * 1.005
S["physics_score"] = S.mean_violation_pct + S.antagonistic_pct            # lower = more physical
cand = S[S["within_0.5pct_of_best"]].sort_values(["physics_score", "val_RMSE"])
PICK = cand.iloc[0]; S.round(4).to_csv(OUT + "T1_physics_aware_selection_validation.csv", index=False)
say("  SELECTED:", PICK.subset, "|", PICK.config, f"| val RMSE {PICK.val_RMSE:.4f}, violations {PICK.mean_violation_pct:.2f}%, antagonistic {PICK.antagonistic_pct:.1f}%")
COLS, KW = FW.SHORT[PICK.subset], CFG_ALL[PICK.config]

# ---------------- F2 ablation on the FULL configuration
say("F2 ablation (full configuration)")
FULLKW = dict(mode="attention", residual=True, lp_w=1., li_w=1.)
def f2():
    rows = []; cols = COLS; EV = FW.EVcache(cols)
    V = {"FULL: attention + residual + physics + interaction": (cols, FULLKW),
         "- residual meta-learning": (cols, dict(FULLKW, residual=False)), "- physics loss": (cols, dict(FULLKW, lp_w=0.)),
         "- interaction loss": (cols, dict(FULLKW, li_w=0.)), "- physics AND interaction loss": (cols, dict(FULLKW, lp_w=0., li_w=0.)),
         "attention -> hazard-aware gate": (cols, dict(FULLKW, mode="gate")), "adaptive fusion -> plain average": (cols, dict(mode="average", residual=False, lp_w=0, li_w=0))}
    for g in sorted(set(FW.GROUP[c] for c in cols)):
        keep = [c for c in cols if FW.GROUP[c] != g]
        if len(keep) >= 2: V[f"- {g} experts"] = (keep, FULLKW)
    for vn, (cc, kw) in V.items():
        ev = FW.EVcache(cc)
        p = FW.fuse_avg(cc, FW.PV) if kw["mode"] == "average" and not kw["residual"] else FW.crossfit_fusion(cc, **kw)
        ph = phys_on(FW.train_fusion(cc, seed=0, EV=ev, **kw), ev, HV)
        rows.append(dict(variant=vn, k=len(cc), val_RMSE=FW.rmse(yV, p[:nSv]), val_compound_RMSE=FW.rmse(yV[FW.REG_V == "compound"], p[:nSv][FW.REG_V == "compound"]), **ph))
        say(f"  {vn[:46]:46s} RMSE {rows[-1]['val_RMSE']:.4f} viol {ph['mean_violation_pct']:.2f}% antag {ph['antagonistic_pct']:.1f}%")
    return pd.DataFrame(rows)
AB = cached("f2", f2); AB["dRMSE_pct"] = (AB.val_RMSE / AB.val_RMSE.iloc[0] - 1) * 100; AB.round(4).to_csv(OUT + "T2_ablation_full_configuration.csv", index=False)

# ---------------- F3 final framework, 5 seeds, test once
say("F3 final framework (5 seeds) on test")
def f3():
    LPt = np.log(np.clip(np.column_stack([FW.PT[c] for c in COLS]), .2, 6)); Ht = FW.hstate(TS["A"])
    LPc = np.log(np.clip(np.column_stack([FW.PC[c] for c in COLS]), .2, 6)); Hc = FW.hstate(CA["A"])
    ST = FW.perturbed_sets(TS["A"].sample(2000, random_state=42)); EVt = FW.expert_logs(ST, COLS); HT = {k: FW.hstate(A) for k, A in ST.items()}
    rows, preds = [], []
    for s in range(5):
        m = FW.train_fusion(COLS, seed=s, EV=FW.EVcache(COLS), **KW)
        with torch.no_grad(): pt = FW.fpred(m, Ht, LPt)[0].numpy(); pc = FW.fpred(m, Hc, LPc)[0].numpy()
        preds.append((pt, pc)); p = np.clip(pt, .25, 5); a, b = U.to_class(y_te), U.to_class(p)
        rows.append(dict(seed=s, R2=r2_score(y_te, p), RMSE=FW.rmse(y_te, p), Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1),
                         RMSE_compound=FW.rmse(y_te[FW.REG_T == "compound"], p[FW.REG_T == "compound"]), **phys_on(m, EVt, HT)))
    return pd.DataFrame(rows), preds
R3, PRED = cached("f3", f3)
summ = R3.drop(columns="seed").agg(["mean", "std"]).T; summ.round(5).to_csv(OUT + "T3_final_framework_test_5seeds.csv")
say("\n" + summ.round(4).to_string())
pt = np.mean([a for a, _ in PRED], 0); pc = np.mean([b for _, b in PRED], 0)
e = np.abs(CA["lo"] - np.clip(pc, .25, 5)); conf = []
for al in (.1, .05):
    q = np.quantile(e, min(1, np.ceil((len(e) + 1) * (1 - al)) / len(e))); lo, hi = pt - q, pt + q; cov = (y_te >= lo) & (y_te <= hi)
    dec = np.where(hi < 1, 0, np.where(lo >= 1.3, 2, -1)); mm = dec >= 0
    conf.append(dict(alpha=al, coverage=cov.mean(), half_width=q, confident_pct=mm.mean() * 100, confident_accuracy=accuracy_score(U.to_class(y_te)[mm], dec[mm])))
pd.DataFrame(conf).round(4).to_csv(OUT + "T4_final_uncertainty.csv", index=False)

# ---------------- F4 stronger hazard specialisation
say("F4 hazard specialisation test")
def f4():
    A_tr = U.TR["A"].iloc[:U.TR["nS"]]; rtr = FW.regime(A_tr); rows = []
    gen = FW.PT["XGBoost"]
    for reg in ["rainfall", "seismic", "compound"]:
        idx = np.where(rtr == reg)[0]
        D = dict(lo=U.TR["lo"][idx], hi=U.TR["hi"][idx], w=U.TR["w"][idx])
        m = U.fit_xgb(A_tr.iloc[idx], D, rounds=1500)
        p_only = U.xgb_pred(m, TS["A"][U.FEATS]); mt = FW.REG_T == reg
        w_name = {"rainfall": "S-R Rainfall specialist (regime-weighted XGBoost)", "seismic": "S-S Seismic specialist (regime-weighted XGBoost)",
                  "compound": "S-C Compound rainfall-seismic specialist (regime-weighted XGBoost)"}[reg]
        rows.append(dict(regime=reg, n_train=len(idx), RMSE_generalist_XGB=FW.rmse(y_te[mt], gen[mt]), RMSE_regime_weighted=FW.rmse(y_te[mt], FW.PT[w_name][mt]),
                         RMSE_regime_only=FW.rmse(y_te[mt], p_only[mt]), RMSE_regime_only_on_other_regimes=FW.rmse(y_te[~mt], p_only[~mt])))
    return pd.DataFrame(rows)
SP = cached("f4", f4); SP.round(4).to_csv(OUT + "T5_hazard_specialisation_test.csv", index=False); say("\n" + SP.round(4).to_string())
json.dump(dict(selected=dict(subset=PICK.subset, k=int(PICK.k), config=PICK.config, members=COLS), test_5seeds=summ.round(5).to_dict(),
               uncertainty=conf), open(OUT + "run_log.json", "w"), indent=2, default=str)
say("DONE")
