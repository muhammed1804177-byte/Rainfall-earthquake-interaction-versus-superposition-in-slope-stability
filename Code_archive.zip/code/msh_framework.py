"""
PHYSICS-INFORMED PROGRESSIVE HYBRID FRAMEWORK FOR MULTI-HAZARD SLOPE STABILITY
(rainfall-induced, seismic-induced and compound rainfall-seismic instability)

Builds on msh_unified.py (leakage-audited; all experts trained on identical SVA + real data).

 S1  hazard regimes (from TRAINING data only): rainfall-dominated, seismic-dominated, compound, low-hazard, mixed
 S2  20-expert pool = 17 generalist experts + 3 hazard specialists (rainfall / seismic / compound; regime-weighted
     interval-loss XGBoost); hazard group of every expert assigned from VALIDATION regime skill (evidence, not labels)
 S3  progressive hybridisation k = 3 ... 20: greedy forward path + 30 hazard-balanced random subsets + 10
     group-constrained subsets per k; fusion by averaging and non-negative stacking; scored by 5-fold cross-fitting
     on validation only
 S4  expensive fusion on the shortlist: hazard-aware adaptive gating, attention fusion, residual meta-learning, with
       L = L_data(interval) + lambda_p L_physics + lambda_int L_interaction + lambda_reg L_reg
     physics/interaction terms are evaluated on paired perturbations of the inputs (finite differences), so they
     also constrain non-differentiable experts (trees)
 S5  ablation (hazard groups, architecture components, loss terms)
 S6  test evaluation ONCE: R2/RMSE (target R2 >= 0.93), accuracy, precision, recall, F1, AUROC, AUPRC, Brier, ECE,
     per hazard regime, extreme subsets, Wilcoxon + bootstrap, conformal UQ (per regime), physics violation,
     interaction index, sensitivity, compute cost, external checks (rock slopes, held-out Morgenstern-Price, real test)
"""
import os, sys, json, time, copy, itertools, warnings
import numpy as np, pandas as pd, joblib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import msh_unified as U
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import torch, torch.nn as nn, torch.nn.functional as Fnn
from scipy.stats import wilcoxon, norm
from sklearn.model_selection import KFold
from sklearn.linear_model import Ridge
from sklearn.metrics import (r2_score, mean_squared_error, accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, average_precision_score, brier_score_loss)
warnings.filterwarnings("ignore")
SMOKE = U.SMOKE
OUT = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/smokeF/") if SMOKE else (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/framework_results/")
CK = OUT + "ck/" if SMOKE else (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptF/")
for p in (OUT, OUT + "figures", CK): os.makedirs(p, exist_ok=True)
RS = 42; T0 = time.time(); LOG = {}
def say(*a): print(f"[F {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): say(f"  [cache] {name}"); return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
def savefig(n): plt.tight_layout(); plt.savefig(OUT + "figures/" + n, dpi=160, bbox_inches="tight"); plt.close()
TR, VA, VA_M, CA, TS, TRL = U.TR, U.VA, U.VA_M, U.CA, U.TS, U.TRL
FEATS, recompute, real, r_te = U.FEATS, U.recompute, U.real, U.r_te
y_te, yR_te = TS["lo"], U.yR_te

# ============================================================ S1 hazard regimes (thresholds from training slopes only)
A_tr = TR["A"].iloc[:TR["nS"]]
Q = dict(ru75=A_tr.PorePressureRatio.quantile(.75), ru50=A_tr.PorePressureRatio.quantile(.5), rain90=A_tr.Rainfall_mm_day.quantile(.9),
         kh75=A_tr.SeismicCoefficient.quantile(.75), kh50=A_tr.SeismicCoefficient.quantile(.5))
def regime(A):
    wet = A.PorePressureRatio.values >= Q["ru75"]; dry = A.PorePressureRatio.values < Q["ru50"]
    eq = A.SeismicCoefficient.values >= Q["kh75"]; calm = A.SeismicCoefficient.values < Q["kh50"]
    return np.select([wet & eq, wet & calm, eq & dry, dry & calm], ["compound", "rainfall", "seismic", "low-hazard"], "mixed")
def extremes(A):
    return {"extreme rainfall (top 10%)": A.Rainfall_mm_day.values >= Q["rain90"], "strong seismic (kh>=0.2)": A.SeismicCoefficient.values >= .2,
            "extreme compound (both)": (A.Rainfall_mm_day.values >= Q["rain90"]) & (A.SeismicCoefficient.values >= .2)}
REG_V, REG_T = regime(VA["A"].iloc[:VA["nS"]]), regime(TS["A"])
LOG["regime_thresholds"] = {k: float(v) for k, v in Q.items()}
LOG["test_regime_counts"] = pd.Series(REG_T).value_counts().to_dict()
say("S1 regimes (test):", LOG["test_regime_counts"])

# ============================================================ S2 hazard specialists + expert pool
say("S2 hazard specialists")
def specialist(reg):
    rtr = regime(TR["A"].iloc[:TR["nS"]]); wt = TR["w"].copy(); wt[:TR["nS"]] *= np.where(rtr == reg, 5., 1.)
    D = dict(TR, w=wt); return U.fit_xgb(TR["A"], D, Dv=U.VA)
SPEC = {}
for reg, nm in [("rainfall", "S-R Rainfall specialist (regime-weighted XGBoost)"), ("seismic", "S-S Seismic specialist (regime-weighted XGBoost)"),
                ("compound", "S-C Compound rainfall-seismic specialist (regime-weighted XGBoost)")]:
    m = cached("spec_" + reg, lambda reg=reg: specialist(reg)); SPEC[nm] = (lambda A, m=m: U.xgb_pred(m, A[FEATS]))
ORIG = {n.lstrip("_"): n for n in U.BASE}                          # 17 generalists (incl. DNN-embedding-XGBoost)
GEN = list(ORIG)
EXPERTS = GEN + list(SPEC); assert len(EXPERTS) == 20, len(EXPERTS)
FN = {**{n: U.PRED[ORIG[n]] for n in GEN}, **SPEC}
PV = cached("PV", lambda: {**{n: U.PV[ORIG[n]] for n in GEN}, **{n: f(VA["A"]) for n, f in SPEC.items()}})
PT = cached("PT", lambda: {**{n: U.PT[ORIG[n]] for n in GEN}, **{n: f(TS["A"]) for n, f in SPEC.items()}})
PRT = cached("PRT", lambda: {**{n: U.PRT[ORIG[n]] for n in GEN}, **{n: f(TRL["A"]) for n, f in SPEC.items()}})
PC = cached("PC", lambda: {**{n: U.PC[ORIG[n]] for n in GEN}, **{n: f(CA["A"]) for n, f in SPEC.items()}})
nSv = VA["nS"]; yV = VA["lo"][:nSv]
def rmse(y, p): return mean_squared_error(y, np.clip(p, .25, 5)) ** .5
skill = pd.DataFrame({n: {r: rmse(yV[REG_V == r], PV[n][:nSv][REG_V == r]) for r in ["rainfall", "seismic", "compound", "low-hazard"]} for n in EXPERTS}).T
rel = skill / skill.median()                                         # <1 = better than the typical expert in that regime
GROUP = {}
for n in EXPERTS:
    r = rel.loc[n, ["rainfall", "seismic", "compound"]]; GROUP[n] = (r.idxmin() + "-focused") if r.min() < .97 else "generalist"
skill["hazard_group"] = pd.Series(GROUP); skill.round(4).to_csv(OUT + "T1_expert_regime_skill_validation.csv")
FAM = {n: ("tree" if n in ("XGBoost", "LightGBM", "RandomForest") or n.startswith("S-") else
           "tree+DL hybrid" if ("XGBoost" in n and n != "XGBoost") else
           "physics-guided" if n.startswith("M2") else "attention/transformer" if n[:2] in ("M1", "M3", "M4", "N1") else
           "recurrent" if n in ("LSTM", "GRU", "LSTM-GRU-DNN") else "convolutional" if n == "1D-CNN" else "MLP") for n in EXPERTS}
say("  hazard groups:", pd.Series(GROUP).value_counts().to_dict())

# ============================================================ S3 progressive hybridisation k = 3 ... 20
say("S3 progressive 3->20 search (validation, cross-fitted)")
LPV = {n: np.log(np.clip(PV[n], .2, 6)) for n in EXPERTS}
def iloss(p, D=VA_M): return U.iloss_np(p, D)
def fuse_avg(cols, P): return np.exp(np.mean([np.log(np.clip(P[c], .2, 6)) for c in cols], 0))
def fuse_stack_cf(cols):
    X = np.column_stack([PV[c] for c in cols]); o = np.zeros(len(X))
    for a, b in KFold(5, shuffle=True, random_state=RS).split(X): o[b] = U.fit_ridge(X, VA_M, a).predict(X[b])
    return o
def score(cols):
    pa, ps = fuse_avg(cols, PV), fuse_stack_cf(cols)
    out = {}
    for fz, p in (("average", pa), ("stacking", ps)):
        pc = np.clip(p[:nSv], .25, 5)
        out[fz] = dict(val_iloss=iloss(p), val_R2=r2_score(yV, pc), val_RMSE=rmse(yV, p[:nSv]),
                       val_accuracy_3class=accuracy_score(U.to_class(yV), U.to_class(pc)), val_accuracy_failure=accuracy_score(yV < 1, pc < 1),
                       val_real_AUC=np.nan, val_compound_RMSE=rmse(yV[REG_V == "compound"], p[:nSv][REG_V == "compound"]))
    return out
def search():
    rng = np.random.default_rng(RS); rows = []; seen = set()
    def add(cols, how):
        key = tuple(sorted(cols))
        if key in seen: return
        seen.add(key); s = score(list(cols))
        for fz, d in s.items(): rows.append(dict(k=len(cols), how=how, fusion=fz, members=" | ".join(sorted(cols)), **d))
    single = {n: iloss(PV[n]) for n in EXPERTS}; path = sorted(single, key=single.get)[:2]
    groups = sorted(set(GROUP.values()))
    for k in range(3, 21):
        best, bv = None, 1e9                                          # greedy forward step
        for n in EXPERTS:
            if n in path: continue
            v = iloss(fuse_stack_cf(path + [n]))
            if v < bv: best, bv = n, v
        path = path + [best]; add(path, "greedy")
        for _ in range(3 if SMOKE else 30):                            # hazard-balanced random subsets
            cols = [rng.choice([n for n in EXPERTS if GROUP[n] == g]) for g in rng.permutation(groups)][: min(k, len(groups))]
            rest = [n for n in EXPERTS if n not in cols]; cols = list(cols) + list(rng.choice(rest, k - len(cols), replace=False)); add(cols, "random-balanced")
        for g in groups:                                               # group-constrained (all of one group first)
            base = [n for n in EXPERTS if GROUP[n] == g][:k]; rest = [n for n in EXPERTS if n not in base]
            add(base + list(rng.choice(rest, k - len(base), replace=False)), f"anchored:{g}")
        say(f"  k={k} done, subsets so far {len(seen)}")
    return pd.DataFrame(rows)
SR = cached("search", search); SR.round(5).to_csv(OUT + "T2_progressive_search_validation.csv", index=False)
SR["meets_93pct_accuracy"] = (SR.val_accuracy_3class >= .93) & (SR.val_accuracy_failure >= .93)
B93 = SR.groupby(["k", "fusion"]).agg(evaluated=("members", "count"), meeting_93pct=("meets_93pct_accuracy", "sum"),
                                     best_acc3=("val_accuracy_3class", "max"), worst_acc3=("val_accuracy_3class", "min"),
                                     best_acc_fail=("val_accuracy_failure", "max"), best_R2=("val_R2", "max")).reset_index()
B93["pct_meeting"] = B93.meeting_93pct / B93.evaluated * 100; B93.round(4).to_csv(OUT + "T2b_benchmark_93pct_by_k_validation.csv", index=False)
LOG["combinations_meeting_93pct_validation"] = f"{int(SR.meets_93pct_accuracy.sum())} of {len(SR)} evaluated (subset x fusion)"
say("  93% accuracy benchmark:", LOG["combinations_meeting_93pct_validation"])
curve = SR.groupby(["k", "fusion"]).val_iloss.min().unstack(); curve.round(5).to_csv(OUT + "T3_best_per_k_validation.csv")
fig, ax = plt.subplots(figsize=(7, 4))
for fz in curve: ax.plot(curve.index, curve[fz], "o-", label=f"best {fz}")
ax.scatter(SR.k, SR.val_iloss, s=4, alpha=.25, c="gray", label="every evaluated subset")
ax.set(xlabel="number of experts k", ylabel="validation interval-RMSE (cross-fitted)", title="Progressive hybridisation 3 -> 20", xticks=range(3, 21)); ax.legend(fontsize=8)
savefig("F1_progressive_curve.png")
st = SR[SR.fusion == "stacking"].sort_values("val_iloss")
SHORT = {"best overall": st.iloc[0].members.split(" | ")}
for k in (3, 10):
    s_ = st[st.k == k]
    if len(s_): SHORT[f"best k={k}"] = s_.iloc[0].members.split(" | ")
SHORT["all 20 experts"] = EXPERTS
LOG["shortlist"] = {k: len(v) for k, v in SHORT.items()}; say("  shortlist:", LOG["shortlist"])

# ============================================================ S4 hazard-aware fusion with physics + interaction loss
say("S4 hazard-aware gating / attention / residual meta-learning")
HZ = ["Rainfall_mm_day", "GroundwaterDepth_m", "GroundwaterRiseRate_m_day", "PorePressureRatio", "SeismicCoefficient", "SlopeAngle_deg",
      "SlopeHeight_m", "Cohesion_kPa", "FrictionAngle_deg", "UnitWeight_kN_m3", "FS_infinite"]
HI_ = [U.fi[h] for h in HZ]
PERT = {"ru+": ("PorePressureRatio", .05, -1), "kh+": ("SeismicCoefficient", .03, -1), "beta+": ("SlopeAngle_deg", 3, -1),
        "c+": ("Cohesion_kPa", 5, +1), "phi+": ("FrictionAngle_deg", 2, +1)}
def perturbed_sets(A):
    S = {"base": A}
    for k, (c, d, _) in PERT.items(): D = A.copy(); D[c] = D[c] + d; S[k] = recompute(D)
    D = A.copy(); D["PorePressureRatio"] += .15; S["R"] = recompute(D)                 # interaction quadruple
    D = A.copy(); D["SeismicCoefficient"] += .10; S["E"] = recompute(D)
    D = A.copy(); D["PorePressureRatio"] += .15; D["SeismicCoefficient"] += .10; S["RE"] = recompute(D)
    return S
def expert_logs(S, cols): return {k: np.log(np.clip(np.column_stack([FN[c](A) for c in cols]), .2, 6)) for k, A in S.items()}
class Fusion(nn.Module):
    """mode: 'average' | 'gate' (hazard-aware MLP gating) | 'attention' (hazard-state query x expert keys).
       residual: bounded residual meta-learning correction on top of the fused prediction."""
    def __init__(s, K, mode="attention", residual=True, d=32):
        super().__init__(); s.mode, s.res = mode, residual; H = len(HI_)
        if mode == "gate": s.g = nn.Sequential(nn.Linear(H + K, 64), nn.ReLU(), nn.Linear(64, K))
        if mode == "attention":
            s.q = nn.Sequential(nn.Linear(H, d), nn.ReLU(), nn.Linear(d, d)); s.ek = nn.Parameter(torch.randn(K, d) * .1); s.pk = nn.Linear(1, d)
        if residual: s.r = nn.Sequential(nn.Linear(H + K + 1, 64), nn.ReLU(), nn.Linear(64, 1)); nn.init.zeros_(s.r[-1].weight); nn.init.zeros_(s.r[-1].bias)
    def forward(s, h, lp):
        K = lp.shape[1]
        if s.mode == "average": w = torch.full_like(lp, 1. / K)
        elif s.mode == "gate": w = torch.softmax(s.g(torch.cat([h, lp], 1)), 1)
        else:
            keys = s.ek.unsqueeze(0) + s.pk(lp.unsqueeze(-1)); w = torch.softmax((keys @ s.q(h).unsqueeze(-1)).squeeze(-1) / keys.shape[-1] ** .5, 1)
        f = (w * lp).sum(1)
        if s.res: f = f + .1 * torch.tanh(s.r(torch.cat([h, lp, f.unsqueeze(1)], 1)).squeeze(1))
        return torch.exp(f), w
def hstate(A): return torch.tensor(((A[HZ].values - HM) / HS), dtype=torch.float32)
HM, HS = TR["A"][HZ].values.mean(0), TR["A"][HZ].values.std(0) + 1e-9
def train_fusion(cols, mode="attention", residual=True, lp_w=1., li_w=1., reg_w=1e-4, idx=None, seed=0, EV=None):
    """L = L_data + lp*L_physics + li*L_interaction + reg*L_reg   (fitted on validation rows `idx`)."""
    torch.manual_seed(seed); rng = np.random.default_rng(seed); K = len(cols)
    EV = EV or EVcache(cols); idx = np.arange(len(VA["lo"])) if idx is None else idx
    tr_i = rng.permutation(idx); a, b = tr_i[: int(.85 * len(tr_i))], tr_i[int(.85 * len(tr_i)):]
    m = Fusion(K, mode, residual); 
    if mode == "average" and not residual: return m
    opt = torch.optim.Adam(m.parameters(), lr=2e-3)
    T = lambda v: torch.tensor(v, dtype=torch.float32)
    H = hstate(VA["A"]); L = {k: T(v) for k, v in EV.items()}; lo, hi, w = T(VA_M["lo"]), T(VA_M["hi"]), T(VA_M["w"])
    Hp = {k: hstate(A) for k, A in PS_VA.items()}
    def loss_fn(j):
        o, _ = m(H[j], L["base"][j]); ld = (w[j] * (Fnn.relu(lo[j] - o) ** 2 + Fnn.relu(o - hi[j]) ** 2)).sum() / w[j].sum()
        lph = 0.
        for k, (_, _, sgn) in PERT.items():
            ok, _ = m(Hp[k][j], L[k][j]); lph = lph + (Fnn.relu(-sgn * (ok - o)) ** 2).mean()
        oR, _ = m(Hp["R"][j], L["R"][j]); oE, _ = m(Hp["E"][j], L["E"][j]); oRE, _ = m(Hp["RE"][j], L["RE"][j])
        lin = (Fnn.relu(torch.log(oRE) + torch.log(o) - torch.log(oR) - torch.log(oE)) ** 2).mean() + (Fnn.relu(oRE - torch.minimum(oR, oE)) ** 2).mean()
        lreg = sum((p ** 2).sum() for p in m.parameters())
        return ld + lp_w * lph + li_w * lin + reg_w * lreg, ld
    best, bst, bad = 1e9, None, 0
    for ep in range(5 if SMOKE else 40):
        m.train(); pm = rng.permutation(a)
        for k in range(0, len(pm), 512):
            j = torch.tensor(pm[k:k + 512]); l, _ = loss_fn(j); opt.zero_grad(); l.backward(); opt.step()
        m.eval()
        with torch.no_grad(): v = loss_fn(torch.tensor(b))[0].item()
        if v < best - 1e-8: best, bst, bad = v, copy.deepcopy(m.state_dict()), 0
        else:
            bad += 1
            if bad >= 6: break
    m.load_state_dict(bst); m.eval(); return m
@torch.no_grad()
def fpred(m, H, LP): return m(H, torch.tensor(LP, dtype=torch.float32))
PS_VA = perturbed_sets(VA["A"])
_EVC = {}
def EVcache(cols):
    key = tuple(cols)
    if key not in _EVC:
        if "full" not in _EVC: _EVC["full"] = cached("EV_all", lambda: expert_logs(PS_VA, EXPERTS))
        full = _EVC["full"]; ix = [EXPERTS.index(c) for c in cols]
        _EVC[key] = {k: v[:, ix] for k, v in full.items()}
    return _EVC[key]
def crossfit_fusion(cols, **kw):
    EV = EVcache(cols); o = np.zeros(len(VA["lo"])); H = hstate(VA["A"])
    for a, b in KFold(3, shuffle=True, random_state=RS).split(o):
        m = train_fusion(cols, idx=a, EV=EV, **kw); o[b] = fpred(m, H[b], EV["base"][b])[0].numpy()
    return o
CONFIGS = {"average": dict(mode="average", residual=False, lp_w=0, li_w=0), "stacking-equivalent gate (no physics)": dict(mode="gate", residual=False, lp_w=0, li_w=0),
           "hazard-aware gate + physics + interaction": dict(mode="gate", residual=True), "attention + residual + physics + interaction (FULL)": dict(mode="attention", residual=True)}
def s4():
    rows = []
    for sn, cols in SHORT.items():
        for cn, kw in CONFIGS.items():
            p = fuse_avg(cols, PV) if kw["mode"] == "average" and not kw["residual"] else crossfit_fusion(cols, **kw)
            rows.append(dict(subset=sn, k=len(cols), config=cn, val_iloss=iloss(p), val_RMSE=rmse(yV, p[:nSv]), val_R2=r2_score(yV, np.clip(p[:nSv], .25, 5)),
                             val_compound_RMSE=rmse(yV[REG_V == "compound"], p[:nSv][REG_V == "compound"])))
            say(f"  {sn:16s} | {cn[:40]:40s} | val RMSE {rows[-1]['val_iloss']:.4f}  compound {rows[-1]['val_compound_RMSE']:.4f}")
    return pd.DataFrame(rows)
S4 = cached("s4", s4); S4.round(5).to_csv(OUT + "T4_fusion_shortlist_validation.csv", index=False)
S4["rank"] = S4.val_iloss.rank() + S4.val_compound_RMSE.rank()
pick = S4.sort_values("rank").iloc[0]; FINAL_SUB, FINAL_CFG = pick.subset, pick.config
LOG["final_selected_on_validation"] = dict(subset=FINAL_SUB, k=int(pick.k), config=FINAL_CFG); say("  FINAL (validation):", LOG["final_selected_on_validation"])
COLS = SHORT[FINAL_SUB]; KW = CONFIGS[FINAL_CFG]
t0 = time.time(); FINAL = [train_fusion(COLS, seed=s, **KW) for s in range(3)]; fuse_train_s = time.time() - t0

def framework_predict(A, cols=COLS, models=FINAL, return_w=False):
    LP = np.log(np.clip(np.column_stack([FN[c](A) for c in cols]), .2, 6)); H = hstate(A)
    o = [fpred(m, H, LP) for m in models]; p = np.mean([a.numpy() for a, _ in o], 0)
    return (p, np.mean([w.numpy() for _, w in o], 0)) if return_w else p

# ============================================================ S5 ablation (validation, cross-fitted)
say("S5 ablation")
def s5():
    rows = []; base_cols = COLS
    variants = {"FULL selected framework": (base_cols, KW)}
    for g in sorted(set(GROUP[c] for c in base_cols)):
        keep = [c for c in base_cols if GROUP[c] != g]
        if len(keep) >= 2: variants[f"- {g} experts"] = (keep, KW)
    for fam in sorted(set(FAM[c] for c in base_cols)):
        keep = [c for c in base_cols if FAM[c] != fam]
        if len(keep) >= 2: variants[f"- {fam} family"] = (keep, KW)
    variants["- residual meta-learning"] = (base_cols, dict(KW, residual=False))
    variants["- physics loss"] = (base_cols, dict(KW, lp_w=0))
    variants["- interaction loss"] = (base_cols, dict(KW, li_w=0))
    variants["attention -> gate" if KW["mode"] == "attention" else "gate -> attention"] = (base_cols, dict(KW, mode="gate" if KW["mode"] == "attention" else "attention"))
    variants["adaptive fusion -> plain average"] = (base_cols, dict(mode="average", residual=False, lp_w=0, li_w=0))
    for vn, (cols, kw) in variants.items():
        p = fuse_avg(cols, PV) if kw["mode"] == "average" and not kw["residual"] else crossfit_fusion(cols, **kw)
        rows.append(dict(variant=vn, k=len(cols), val_iloss=iloss(p), val_RMSE=rmse(yV, p[:nSv]),
                         val_compound_RMSE=rmse(yV[REG_V == "compound"], p[:nSv][REG_V == "compound"])))
    return pd.DataFrame(rows)
AB = cached("s5", s5); AB["d_iloss_%"] = (AB.val_iloss / AB.val_iloss.iloc[0] - 1) * 100; AB.round(4).to_csv(OUT + "T5_ablation_validation.csv", index=False)

# ============================================================ S6 test evaluation (once)
say("S6 test evaluation")
FW = "PROPOSED FRAMEWORK (" + FINAL_SUB + ", " + FINAL_CFG.split(" (")[0] + ")"
t0 = time.time(); p_fw, W_fw = framework_predict(TS["A"], return_w=True); infer_s = time.time() - t0
p_fw_R = framework_predict(TRL["A"]); p_fw_C = framework_predict(CA["A"])
best_single = min(EXPERTS, key=lambda n: iloss(PV[n])); PT_all = {**{n: PT[n] for n in EXPERTS}, "20-expert average": fuse_avg(EXPERTS, PT), FW: p_fw}
PRT_all = {**{n: PRT[n] for n in EXPERTS}, "20-expert average": fuse_avg(EXPERTS, PRT), FW: p_fw_R}
PC_all = {**{n: PC[n] for n in EXPERTS}, "20-expert average": fuse_avg(EXPERTS, PC), FW: p_fw_C}
def prob_fail(n, P, Pc):
    """P(FoS<1) from a Gaussian error model calibrated on the untouched calibration set."""
    sd = np.std(CA["lo"] - np.clip(Pc[n], .25, 5)); return norm.cdf((1 - np.clip(P[n], .25, 5)) / sd)
def ece(y, p, bins=10):
    e, edges = 0., np.linspace(0, 1, bins + 1)
    for a, b in zip(edges[:-1], edges[1:]):
        m = (p >= a) & (p < b) if b < 1 else (p >= a)
        if m.any(): e += m.mean() * abs(y[m].mean() - p[m].mean())
    return e
rows = {}
yb = (y_te < 1).astype(int)
for n in PT_all:
    p = np.clip(PT_all[n], .25, 5); c3t, c3p = U.to_class(y_te), U.to_class(p); pf = prob_fail(n, PT_all, PC_all); pfr = prob_fail(n, PRT_all, PC_all)
    rows[n] = dict(R2=r2_score(y_te, p), RMSE=rmse(y_te, p), meets_R2_0_93=r2_score(y_te, p) >= .93,
                   Accuracy_failure=accuracy_score(y_te < 1, p < 1),
                   meets_93pct_accuracy=(accuracy_score(c3t, c3p) >= .93) and (accuracy_score(y_te < 1, p < 1) >= .93),
                   Accuracy_3class=accuracy_score(c3t, c3p), Precision_macro=precision_score(c3t, c3p, average="macro"), Recall_macro=recall_score(c3t, c3p, average="macro"),
                   F1_macro=f1_score(c3t, c3p, average="macro"), F1_Marginal=f1_score(c3t == 1, c3p == 1),
                   AUROC_failure=roc_auc_score(yb, pf), AUPRC_failure=average_precision_score(yb, pf), Brier=brier_score_loss(yb, pf), ECE=ece(yb, pf),
                   Real_AUROC=roc_auc_score(yR_te, pfr), Real_AUPRC=average_precision_score(yR_te, pfr),
                   **(lambda pc: dict(Real_cal_Accuracy=accuracy_score(yR_te, pc > .5), Real_cal_Brier=brier_score_loss(yR_te, pc), Real_cal_ECE=U.ece(yR_te, pc)))(
                       U.real_calibrated(yR_te, PRT_all[n], U.real.group.values[r_te])))
    for rg in ["rainfall", "seismic", "compound", "low-hazard"]: rows[n][f"RMSE_{rg}"] = rmse(y_te[REG_T == rg], p[REG_T == rg])
    for en, m in extremes(TS["A"]).items():
        rows[n][f"R2_{en}"] = r2_score(y_te[m], p[m]) if m.sum() > 2 else np.nan; rows[n][f"RMSE_{en}"] = rmse(y_te[m], p[m]) if m.any() else np.nan
RES = pd.DataFrame(rows).T
rng = np.random.default_rng(RS); BI = [rng.integers(0, len(y_te), len(y_te)) for _ in range(500)]
e_fw = (np.clip(p_fw, .25, 5) - y_te) ** 2
for n in PT_all:
    p = np.clip(PT_all[n], .25, 5); r = [rmse(y_te[j], p[j]) for j in BI]; RES.loc[n, "RMSE_CI_low"], RES.loc[n, "RMSE_CI_high"] = np.percentile(r, [2.5, 97.5])
    RES.loc[n, "Wilcoxon_p_framework_better"] = np.nan if n == FW else wilcoxon(e_fw, (p - y_te) ** 2, alternative="less").pvalue
RES = RES.sort_values("RMSE"); RES.round(5).to_csv(OUT + "T6_TEST_framework_vs_all_experts.csv")
say("\n" + RES[["R2", "RMSE", "F1_Marginal", "AUROC_failure", "ECE", "Real_AUROC", "RMSE_compound", "R2_extreme compound (both)"]].round(4).head(12).to_string())

# conformal UQ (calibration set) incl. per regime and extremes
def conformal():
    e = np.abs(CA["lo"] - np.clip(p_fw_C, .25, 5)); out = []
    REG_C = regime(CA["A"])
    for a in (.1, .05):
        q = np.quantile(e, min(1, np.ceil((len(e) + 1) * (1 - a)) / len(e))); qr = {rg: np.quantile(e[REG_C == rg], min(1, np.ceil(((REG_C == rg).sum() + 1) * (1 - a)) / (REG_C == rg).sum())) for rg in np.unique(REG_C)}
        for nm, qq in (("global", np.full(len(y_te), q)), ("hazard-regime conditional", np.array([qr[r] for r in REG_T]))):
            lo, hi = p_fw - qq, p_fw + qq; cov = (y_te >= lo) & (y_te <= hi); dec = np.where(hi < 1, 0, np.where(lo >= 1.3, 2, -1)); m = dec >= 0
            row = dict(alpha=a, method=nm, coverage=cov.mean(), mean_half_width=qq.mean(), confident_pct=m.mean() * 100, confident_accuracy=accuracy_score(U.to_class(y_te)[m], dec[m]))
            for rg in ["rainfall", "seismic", "compound", "low-hazard"]: row[f"coverage_{rg}"] = cov[REG_T == rg].mean()
            for en, mm in extremes(TS["A"]).items(): row[f"coverage_{en}"] = cov[mm].mean() if mm.any() else np.nan
            out.append(row)
    return pd.DataFrame(out)
conformal().round(4).to_csv(OUT + "T7_uncertainty_conformal.csv", index=False)

# physics consistency + interaction index on test slopes
say("  physics & interaction on test")
XS = TS["A"].sample(min(2000, len(TS["A"])), random_state=RS)
def phys_eval(f):
    S = perturbed_sets(XS); P = {k: f(A) for k, A in S.items()}; r = {}
    for k, (c, _, sgn) in PERT.items(): r[f"viol_{c}"] = float(np.mean(sgn * (P[k] - P["base"]) < -1e-3) * 100)
    I = P["RE"] * P["base"] / (P["R"] * P["E"]); r["interaction_index_median"] = float(np.median(I)); r["antagonistic_pct (I>1)"] = float(np.mean(I > 1 + 1e-3) * 100)
    r["compound_not_worse_pct"] = float(np.mean(P["RE"] > np.minimum(P["R"], P["E"]) + 1e-3) * 100); return r
PH = pd.DataFrame({n: phys_eval(FN[n]) for n in [best_single] + [n for n in EXPERTS if n.startswith("S-")]} | {FW: phys_eval(lambda A: framework_predict(A))}).T
PH["mean_violation_%"] = PH.filter(like="viol_").mean(1); PH.round(3).to_csv(OUT + "T8_physics_interaction_test.csv")

# expert weights by regime (interpretability of the gating/attention)
WT = pd.DataFrame(W_fw, columns=COLS); WT["regime"] = REG_T; wr = WT.groupby("regime").mean().T; wr["group"] = [GROUP[c] for c in wr.index]
wr.round(3).to_csv(OUT + "T9_expert_weights_by_hazard_regime.csv")
fig, ax = plt.subplots(figsize=(9, max(4, .35 * len(COLS)))); im = ax.imshow(wr.drop(columns="group").values, cmap="viridis", aspect="auto")
ax.set_yticks(range(len(wr)), [f"{i[:34]} [{g}]" for i, g in zip(wr.index, wr.group)], fontsize=7); ax.set_xticks(range(wr.shape[1] - 1), wr.columns[:-1], rotation=20)
plt.colorbar(im, label="mean expert weight"); ax.set_title("Hazard-aware expert weighting (test slopes)"); savefig("F2_expert_weights_by_regime.png")

# sensitivity (permutation importance of the final framework, 2,000 test slopes)
def sens():
    base = rmse(y_te[XS.index], framework_predict(XS)) if False else None
    yy = y_te[TS["A"].index.get_indexer(XS.index)]; b0 = rmse(yy, framework_predict(XS)); out = {}
    for c in ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "Rainfall_mm_day", "GroundwaterDepth_m",
              "PorePressureRatio", "SeismicCoefficient", "WeatheringIndex"]:
        D = XS.copy(); D[c] = np.random.default_rng(RS).permutation(D[c].values); out[c] = rmse(yy, framework_predict(recompute(D))) - b0
    return out
SE = pd.Series(cached("sens", sens)).sort_values(ascending=False); SE.round(4).to_csv(OUT + "T10_sensitivity_permutation.csv")

# rainfall x seismic surface + critical rainfall (hazard chain from msh_unified)
G = pd.concat([TR["A"].iloc[:TR["nS"]].median().to_frame().T] * 33 * 16, ignore_index=True)
for c in FEATS:
    if c.startswith(("SoilType_", "VegetationCover_", "DrainageCondition_")): G[c] = 0.
G[["SoilType_Silty_Clay", "VegetationCover_Moderate", "DrainageCondition_Moderate"]] = 1.
Rg, Kg = np.linspace(0, 320, 33), np.linspace(0, .3, 16); rr, kk = np.meshgrid(Rg, Kg); G["Rainfall_mm_day"], G["SeismicCoefficient"] = rr.ravel(), kk.ravel()
SURF = cached("surface", lambda: U.chain(lambda A: framework_predict(A))(G).reshape(rr.shape))
crit = {round(k, 2): (float(Rg[np.where(SURF[j] < 1)[0][0]]) if (SURF[j] < 1).any() else np.nan) for j, k in enumerate(Kg)}
pd.Series(crit, name="critical rainfall (mm/day)").to_csv(OUT + "T11_critical_rainfall_vs_kh.csv")
fig, ax = plt.subplots(figsize=(6.5, 4.6)); cs = ax.contourf(rr, kk, np.clip(SURF, .5, 2), levels=np.linspace(.5, 2, 16), cmap="RdYlGn")
cl = ax.contour(rr, kk, SURF, levels=[1, 1.3], colors="k"); ax.clabel(cl, fmt="FoS=%.1f"); plt.colorbar(cs, label="FoS")
ax.set(xlabel="Rainfall (mm/day)", ylabel="kh", title="Compound rainfall-seismic response (framework)"); savefig("F3_rainfall_seismic_surface.png")

# external checks: rock slopes (Case I), held-out MP geometries, real test stress
def ext():
    pl = pd.read_csv(U.CFG["REAL"] + "3_planar_rock_slopes_seismic_149.csv"); pl = pl[pl.case_class == "REAL"]
    Xq = XS.iloc[:600]; f = lambda A: framework_predict(A); out = {}
    kv = np.round(np.arange(0, .31, .05), 2); v = np.array([f(Xq.assign(SeismicCoefficient=k)).mean() for k in kv])
    mpo = U.mp.iloc[U.g_ho]; mpc = mpo.groupby(mpo.kh.round(2)).ratio.median().reindex(kv).values
    out["seismic_RMSE_vs_heldout_MP"] = float(np.sqrt(np.nanmean((v / v[0] - mpc) ** 2)))
    Rt = real.iloc[r_te]; sc = {s: f(U.real_matrix(Rt, a, k)) for s, (a, k) in {"base": (0, 0), "rain": (.2, 0), "eq": (0, .15), "both": (.2, .15)}.items()}
    out["real_rain_lowers_FoS_%"] = float(np.mean(sc["rain"] <= sc["base"] + 1e-6) * 100); out["real_eq_lowers_FoS_%"] = float(np.mean(sc["eq"] <= sc["base"] + 1e-6) * 100)
    out["real_mean_FoS_failed"] = float(sc["base"][yR_te == 1].mean()); out["real_mean_FoS_stable"] = float(sc["base"][yR_te == 0].mean())
    return out
EXT = cached("ext", ext); C1 = pd.read_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/unified_results/T4_case_study_I_rock_slopes.csv"), index_col=0) if os.path.exists((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/unified_results/T4_case_study_I_rock_slopes.csv")) else None

# compute cost
TIMES = {}
for f in os.listdir(U.CK):
    if f.endswith(".pt") and not f.endswith("_tr.pt"):
        try: TIMES[f[:-3]] = len(torch.load(U.CK + f, weights_only=False)["h"])
        except Exception: pass
LOG.update(compute=dict(fusion_training_s=round(fuse_train_s, 1), framework_inference_s_per_1000=round(infer_s / len(y_te) * 1000, 4),
                        experts_used=len(COLS), expert_epochs=TIMES), external=EXT, best_single_expert_on_validation=best_single,
           R2_benchmark_0_93_met={n: bool(RES.loc[n, "meets_R2_0_93"]) for n in [FW, best_single]}, minutes=round((time.time() - T0) / 60, 1))
json.dump(LOG, open(OUT + "run_log.json", "w"), indent=2, default=str); say("DONE")
