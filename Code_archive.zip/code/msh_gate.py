"""Applicability-domain gate: a slope is in domain when it lies inside at least one scenario-family envelope of the
training slopes AND its Mahalanobis distance is within the 99th percentile of the training slopes."""
import numpy as np
def family(X):
    k = X.SeismicCoefficient.values; return np.select([k < .03, k < .10, k < .1201], ["F1", "F2", "F3"], "F4")
class Gate:
    def __init__(s, Xtr, cols):
        s.cols = cols; fam = family(Xtr); s.env = {f: (Xtr[fam == f][cols].min(), Xtr[fam == f][cols].max()) for f in sorted(set(fam))}
        Z = Xtr[cols].values; s.mu, s.sd = Z.mean(0), Z.std(0) + 1e-9; Zs = (Z - s.mu) / s.sd
        s.Ci = np.linalg.pinv(np.cov(Zs.T)); d = s.maha(Xtr); s.thr = np.quantile(d, .99)
    def maha(s, X):
        Zs = (X[s.cols].values - s.mu) / s.sd; return np.sqrt(np.einsum("ij,jk,ik->i", Zs, s.Ci, Zs))
    def inside_env(s, X):
        ok = np.zeros(len(X), bool)
        for lo, hi in s.env.values(): ok |= ((X[s.cols] >= lo - 1e-9) & (X[s.cols] <= hi + 1e-9)).all(1).values
        return ok
    def ok(s, X): return s.inside_env(X) & (s.maha(X) <= s.thr)
