"""Graphical abstract (Elsevier: min. 1328 x 531 px, readable at 5 x 13 cm)."""
import os, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs")
plt.rcParams.update({"font.family": "Inter", "font.size": 9})
INK = "#1F2328"; TEAL, AMBER, GREY, INDIGO = "#1F8A84", "#D99A1E", "#C9C6BC", "#3F3D8F"
fig = plt.figure(figsize=(13.3, 5.3), dpi=200)
im = Image.open(ROOT + "/figures_manuscript/Fig02_study_slope_model.png"); w, h = im.size; im = im.crop((int(.25 * w), int(.06 * h), int(.83 * w), int(.53 * h)))
a0 = fig.add_axes([0.0, 0.08, 0.33, 0.8]); a0.imshow(im); a0.axis("off"); a0.set_title("Rainfall raises $r_u$; earthquake adds $k_h$", fontsize=11, fontweight="semibold", color=INK)
V = pd.read_csv(ROOT + "/interaction_v2/V1_interaction_decomposition_600_slopes.csv"); S = V[((V.ru == .2) | (V.ru == .3) | (V.ru == .4)) & (V.kh == .2)]
a1 = fig.add_axes([0.38, 0.17, 0.25, 0.66]); x = np.arange(len(S))
a1.bar(x, S.pct_fail_single, .6, color=GREY, label="fails under one hazard")
a1.bar(x, S.pct_compound_only_by_superposition, .6, bottom=S.pct_fail_single, color=TEAL, label="fails only combined: superposition")
a1.bar(x, S.pct_caused_by_interaction, .6, bottom=S.pct_fail_single + S.pct_compound_only_by_superposition, color=AMBER, label="fails because of interaction")
a1.set_xticks(x, [f"$r_u$ {r:g}\n$k_h$ 0.2" for r in S.ru]); a1.set_ylabel("Slopes failing (%)"); a1.spines[["top", "right"]].set_visible(False)
a1.legend(fontsize=7.5, loc="upper left", frameon=False); a1.set_title("Why combined loading fails slopes", fontsize=11, fontweight="semibold", color=INK)
a2 = fig.add_axes([0.66, 0.08, 0.34, 0.84]); a2.axis("off")
a2.text(0.02, 0.93, "Calibrated design equation", fontsize=11, fontweight="semibold", color=INK)
a2.text(0.02, 0.74, r"$\dfrac{F_{RE}}{F_0}=\dfrac{1-a\,r_u-b\,k_h\tan\beta}{1+c\,k_h/\tan\beta}$", fontsize=15, color=INK)
a2.text(0.02, 0.56, r"$a,b,c=f(\lambda_{c\varphi})$;  independent MP check $R^2$ = 0.997", fontsize=9.5, color="#555B61")
a2.text(0.02, 0.40, "Interaction lowers stability ($I$ < 1) but explains\n< 2 % of the FoS loss; superposition fails up\nto 21 % of slopes that pass both single checks", fontsize=9.5, color=INK, va="top")
a2.text(0.02, 0.16, "Iburi 2018: dry tephra explains < 4 % of landslides,\na wetted cover about 60 %", fontsize=9.5, color=INDIGO, fontweight="semibold", va="top")
a2.text(0.02, 0.03, "Tandikat 2009: $F_R$ 1.26, $F_E$ 1.04, $F_{RE}$ 0.93", fontsize=9.5, color=INDIGO, fontweight="semibold")
fig.savefig(ROOT + "/manuscript/Graphical_abstract.png", dpi=200, facecolor="white"); fig.savefig(ROOT + "/manuscript/Graphical_abstract.pdf", facecolor="white"); print("ok")
