"""Post-review improvements (P-series), all leakage-free:
P1 applicability-domain gate: inside a scenario-family envelope AND Mahalanobis distance <= 99th percentile of training
   slopes. Evaluated on the test set (flag rate, error in/out), on each family held out (can the gate detect a family it
   never saw?), on the 363 real slopes (6 shared properties) and on the Tandikat case.
P2 real-world probability recalibration: isotonic and Platt maps fitted inside grouped cross-validation on the
   out-of-fold probabilities of each of the 5 repeats (the map never sees the fold it is applied to).
P3 regime-conditional (Mondrian) split-conformal intervals for the final model (calibration split only): coverage per
   loading regime and per scenario family, global vs Mondrian.
P4 cyclic pore-pressure scenario on the mechanics factorial: shaking adds Delta r_u to wet slopes (r_u >= 0.2),
   as observed for saturated loose pumice at Tandikat; effect on the interaction index and compound-only failures."""
import os, sys, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_review as RV
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.metrics import brier_score_loss, roc_auc_score
U, FW, ME = RV.U, RV.FW, RV.ME
ROOT = RV.ROOT; OUT = ROOT + "/improvement_results/"; os.makedirs(OUT, exist_ok=True)
A, y = U.A_sva, U.sva.FoS.values; cls = U.to_class
NUM = ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "WeatheringIndex", "Rainfall_mm_day",
       "GroundwaterRiseRate_m_day", "GroundwaterDepth_m", "PorePressureRatio", "SeismicCoefficient"]
def family(X):
    k = X.SeismicCoefficient.values; return np.select([k < .03, k < .10, k < .1201], ["F1", "F2", "F3"], "F4")

# ================================================================ P1 applicability-domain gate
from msh_gate import Gate
Xtr, Xte = A.iloc[U.s_tr].reset_index(drop=True), A.iloc[U.s_te].reset_index(drop=True)
G = Gate(Xtr, NUM)
ok_te = G.ok(Xte); pF = np.clip(RV.P["Proposed framework"], .25, 5)
r1 = [dict(test="18,000 test slopes (in-distribution)", n=len(Xte), pct_flagged=100 - ok_te.mean() * 100, RMSE_accepted=RV.rmse(y[U.s_te][ok_te], pF[ok_te]),
           RMSE_flagged=RV.rmse(y[U.s_te][~ok_te], pF[~ok_te]) if (~ok_te).any() else np.nan)]
for f in ("F1", "F2", "F3", "F4"):                                 # gate built WITHOUT family f: does it flag family f?
    ftr = family(Xtr); g = Gate(Xtr[ftr != f].reset_index(drop=True), NUM); m = family(Xte) == f
    r1.append(dict(test=f"held-out family {f} (gate built without it)", n=int(m.sum()), pct_flagged=100 - g.ok(Xte[m]).mean() * 100,
                   pct_flagged_same_family_seen=100 - G.ok(Xte[m]).mean() * 100))
real = U.real.copy(); C6 = ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "PorePressureRatio"]
g6 = Gate(Xtr, C6); okr = g6.ok(real.rename(columns={})[C6].assign(SeismicCoefficient=0.0))
r1.append(dict(test="363 real case histories (6 shared properties)", n=len(real), pct_flagged=100 - okr.mean() * 100))
tand = pd.DataFrame([dict(SlopeHeight_m=90, SlopeAngle_deg=30, UnitWeight_kN_m3=15.0, Cohesion_kPa=0.0, FrictionAngle_deg=39, PorePressureRatio=.3, SeismicCoefficient=.1)])
r1.append(dict(test="Tandikat 2009 case (H 90 m, c' 0)", n=1, pct_flagged=100 - g6.ok(tand).mean() * 100))
P1 = pd.DataFrame(r1); P1.round(4).to_csv(OUT + "P1_applicability_gate.csv", index=False); print(P1.round(3).to_string())
# which properties put real slopes outside?
lo, hi = Xtr[C6].min(), Xtr[C6].max()
pd.Series({c: float(np.mean((real[c] < lo[c]) | (real[c] > hi[c])) * 100) for c in C6}).round(2).to_csv(OUT + "P1b_real_slopes_outside_range_by_property.csv")

# ================================================================ P2 recalibration of real-world probabilities
yr = real.fail.values.astype(int); grp = real.group.values; rows, rel = [], []
def ece(p, t):
    b = np.clip(np.digitize(p, np.linspace(0, 1, 11)) - 1, 0, 9); return sum(np.mean(b == i) * abs(p[b == i].mean() - t[b == i].mean()) for i in range(10) if np.any(b == i))
for s in (11, 12, 13, 14, 15):
    p = joblib.load(RV.WK + f"/ckptU3/conf_run_{s}.joblib")[0]; qi, qp = np.zeros_like(p), np.zeros_like(p)
    for tr, te in GroupKFold(5).split(p, yr, grp):
        qi[te] = IsotonicRegression(out_of_bounds="clip", y_min=.001, y_max=.999).fit(p[tr], yr[tr]).predict(p[te])
        lr = LogisticRegression().fit(np.log(np.clip(p[tr], 1e-4, 1 - 1e-4) / (1 - np.clip(p[tr], 1e-4, 1 - 1e-4)))[:, None], yr[tr])
        qp[te] = lr.predict_proba(np.log(np.clip(p[te], 1e-4, 1 - 1e-4) / (1 - np.clip(p[te], 1e-4, 1 - 1e-4)))[:, None])[:, 1]
    for nm, q in (("uncalibrated", p), ("Platt (grouped CV)", qp), ("isotonic (grouped CV)", qi)):
        rows.append(dict(seed=s, method=nm, Brier=brier_score_loss(yr, q), ECE=ece(q, yr), AUROC=roc_auc_score(yr, q)))
    if s == 11:
        for nm, q in (("uncalibrated", p), ("Platt (grouped CV)", qp)):
            b = np.clip(np.digitize(q, np.linspace(0, 1, 11)) - 1, 0, 9)
            for i in range(10):
                if np.any(b == i): rel.append(dict(method=nm, mean_predicted=q[b == i].mean(), observed=yr[b == i].mean(), n=int((b == i).sum())))
P2 = pd.DataFrame(rows); P2s = P2.groupby("method")[["Brier", "ECE", "AUROC"]].agg(["mean", "std"]); P2s.round(4).to_csv(OUT + "P2_realworld_recalibration.csv")
pd.DataFrame(rel).round(4).to_csv(OUT + "P2b_reliability_after_recalibration.csv", index=False); print(P2s.round(4))

# ================================================================ P3 Mondrian conformal for the final model
BR = joblib.load(RV.WK + "/finalblend/branches.joblib"); A2 = joblib.load(RV.WK + "/finalblend/anch_v2.joblib"); W2 = float(pd.read_csv(ROOT + "/final_model_results/F5_final_model_v1_vs_v2_test.csv").w.iloc[1])
blend = lambda fa, fd: np.clip(np.exp(W2 * np.log(fa) + (1 - W2) * np.log(fd)), .25, 5)
Aca, Ate = A.iloc[U.s_ca].reset_index(drop=True), A.iloc[U.s_te].reset_index(drop=True); yc, yt = y[U.s_ca], y[U.s_te]
pc, pt = blend(BR["calib"][0], A2["calib"]), blend(BR["test"][0], A2["test"]); rc = np.abs(np.log(yc) - np.log(pc))
Rc, Rt, Fc, Ft = FW.regime(Aca), FW.regime(Ate), family(Aca), family(Ate)
qf = lambda r, a: np.quantile(r, min(1, np.ceil((len(r) + 1) * (1 - a)) / len(r)))
rows = []
for a in (.10, .05):
    qg = qf(rc, a)
    for lab, gc, gt in (("regime", Rc, Rt), ("family", Fc, Ft)):
        for g in sorted(set(gt)):
            m = gt == g; qm = qf(rc[gc == g], a)
            cov = lambda q: np.mean((yt[m] >= pt[m] * np.exp(-q)) & (yt[m] <= pt[m] * np.exp(q)))
            rows.append(dict(level=f"{int(round((1-a)*100))}%", grouping=lab, group=g, n_test=int(m.sum()), coverage_global=cov(qg), coverage_mondrian=cov(qm),
                             rel_halfwidth_global_pct=(np.exp(qg) - 1) * 100, rel_halfwidth_mondrian_pct=(np.exp(qm) - 1) * 100))
P3 = pd.DataFrame(rows); P3.round(4).to_csv(OUT + "P3_final_model_mondrian_conformal.csv", index=False); print(P3.round(3).to_string())

# ================================================================ P4 cyclic pore-pressure scenario (mechanics factorial)
POP = ME.D.iloc[ME.i_te][ME.COLS].reset_index(drop=True); f = lambda d: np.clip(ME.pred(ME.BEST, ME.feats(d)), .05, 20)
F0, FR, FE = f(POP.assign(ru=0., kh=0.)), f(POP.assign(ru=.3, kh=0.)), f(POP.assign(ru=0., kh=.15)); rows = []
for d in (0., .05, .1, .2):
    FRE = f(POP.assign(ru=min(.6, .3 + d), kh=.15)); I = FRE * F0 / (FR * FE)
    rows.append(dict(delta_ru_from_shaking=d, median_I=np.median(I), pct_synergistic=np.mean(I < .99) * 100, failure_pct_combined=np.mean(FRE < 1) * 100,
                     compound_only_failure_pct=np.mean((FR >= 1) & (FE >= 1) & (FRE < 1)) * 100, median_combined_loss_pct=np.median(1 - FRE / F0) * 100))
P4 = pd.DataFrame(rows); P4.round(4).to_csv(OUT + "P4_cyclic_pore_pressure_scenario.csv", index=False); print(P4.round(3).to_string()); print("IMP DONE")
