"""Central theme: rainfall-seismic INTERACTION in slope stability (I-series). Run after msh_review.py.
I1 factorial loading matrix on 500 gap-free slopes, direct pseudo-static Bishop: r_u {0..0.4} x kh {0..0.2};
   additive and multiplicative interaction of FoS, interaction of the failure share, seismic damage after wetting,
   regression interaction term with bootstrap CI.
I2 yield (critical) seismic coefficient k_y versus r_u, critical r_u versus kh, and the rainfall at which a given kh
   becomes critical (rainfall -> r_u from the observed Kaggle relation, not extrapolated).
I3 which slopes are vulnerable to the compound condition (moderators of the interaction).
I4 model-based interaction strength: Friedman H-statistic for rainfall/r_u/GW/beta/c/phi x kh (framework, mechanics-
   anchored hybrid, Bishop surrogate), SHAP interaction values (data-only LightGBM), 2-D partial dependence of rainfall x kh
   through the hydrological chain inside the data-supported region.
I5 physical consistency under combined loading: Bishop log-sensitivities to c, phi, beta under baseline / rainfall /
   seismic / combined; monotonicity violations of the data models per loading regime.
I6 reliability interaction: P_f and beta over an r_u x kh grid (surrogate Monte Carlo) against the additive expectation."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_review as RV        # loads framework, mechanics, hybrid and the review caches (no recomputation)
ME, U, MO, FW = RV.ME, RV.U, RV.MO, RV.FW
from scipy import stats
from scipy.stats import norm
ROOT = RV.ROOT; OUT = ROOT + "/interaction_results/"; os.makedirs(OUT, exist_ok=True); CK = RV.WK + "/interaction/"; os.makedirs(CK, exist_ok=True); T0 = time.time()
def say(*a): print(f"[INT {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(n, fn):
    f = CK + n + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
sur = lambda d: ME.pred(ME.BEST, ME.feats(d))
POP = ME.D.iloc[ME.i_te][ME.COLS].sample(500, random_state=13).reset_index(drop=True)
RUL, KHL = [0., .1, .2, .3, .4], [0., .05, .1, .15, .2]

# ---------------------------------------------------------------- I1 factorial matrix (direct Bishop)
def i1():
    out = {}
    for a in RUL:
        for b in KHL:
            P = POP.assign(ru=a, kh=b)[ME.COLS].values; out[(a, b)] = ME.bishop_many(P, f"i1_{a:.2f}_{b:.2f}")
    return out
F = cached("i1", i1); F0 = F[(0., 0.)]; say("I1 Bishop grid ready")
rows = []; rng = np.random.default_rng(0); BS = rng.integers(0, len(POP), (1000, len(POP)))
for a in RUL:
    for b in KHL:
        R, E, RE = F[(a, 0.)], F[(0., b)], F[(a, b)]
        add = RE - R - E + F0                      # additive interaction (FoS units); < 0 = combined worse than the sum
        mul = RE * F0 / (R * E)                    # multiplicative interaction; < 1 = combined worse than the product
        fr = lambda x: np.mean(x < 1) * 100
        rows.append(dict(ru=a, kh=b, condition=("baseline" if a == 0 and b == 0 else "rainfall only" if b == 0 else "seismic only" if a == 0 else "rainfall + seismic"),
                         median_FoS=np.median(RE), median_drop_pct=np.median(1 - RE / F0) * 100, pct_FoS_lt_1=fr(RE),
                         additive_expected_drop_pct=np.median((1 - R / F0) + (1 - E / F0)) * 100,
                         median_additive_interaction=np.median(add), additive_CI_low=np.quantile([np.median(add[i]) for i in BS[:300]], .025), additive_CI_high=np.quantile([np.median(add[i]) for i in BS[:300]], .975),
                         median_multiplicative_I=np.median(mul), I_CI_low=np.quantile([np.median(mul[i]) for i in BS[:300]], .025), I_CI_high=np.quantile([np.median(mul[i]) for i in BS[:300]], .975),
                         pct_slopes_superadditive=np.mean(add < -1e-3) * 100, pct_slopes_supermultiplicative=np.mean(mul < 1 - 1e-3) * 100,
                         failure_share_interaction_pp=fr(RE) - fr(R) - fr(E) + fr(F0), compound_only_failures_pct=np.mean((RE < 1) & (R >= 1) & (E >= 1)) * 100))
T1 = pd.DataFrame(rows); T1.round(4).to_csv(OUT + "I1_factorial_loading_matrix_Bishop.csv", index=False)
# seismic damage after wetting: FoS loss from kh 0 -> 0.15 at each r_u (absolute, relative, and per unit kh)
sd = []
for a in RUL:
    d_abs = F[(a, 0.)] - F[(a, .15)]; d_rel = d_abs / F[(a, 0.)]
    sd.append(dict(ru=a, median_FoS_before=np.median(F[(a, 0.)]), median_abs_FoS_loss_kh0_to_0_15=np.median(d_abs), median_rel_loss_pct=np.median(d_rel) * 100,
                   pct_stable_slopes_pushed_below_1=np.mean((F[(a, 0.)] >= 1) & (F[(a, .15)] < 1)) / max(np.mean(F[(a, 0.)] >= 1), 1e-9) * 100))
T1b = pd.DataFrame(sd); T1b.round(4).to_csv(OUT + "I1b_seismic_damage_after_wetting.csv", index=False)
# regression interaction term: log FoS = a_i + b ru + c kh + d ru*kh (slope fixed effects), cluster bootstrap over slopes
def fe_reg(transform):
    Y = np.array([[transform(F[(a, b)]) for a in RUL for b in KHL]])[0].T          # (n_slopes, 25)
    ru = np.repeat(RUL, len(KHL)); kh = np.tile(KHL, len(RUL)); X = np.c_[ru, kh, ru * kh]; Xc = X - X.mean(0)
    def fit(Yb):
        Yc = Yb - Yb.mean(1, keepdims=True); beta = np.linalg.lstsq(np.tile(Xc, (len(Yb), 1)), Yc.ravel(), rcond=None)[0]; return beta
    b = fit(Y); bb = np.array([fit(Y[i]) for i in BS[:300]])
    return dict(ru=b[0], kh=b[1], ru_x_kh=b[2], ru_x_kh_CI_low=np.quantile(bb[:, 2], .025), ru_x_kh_CI_high=np.quantile(bb[:, 2], .975),
                share_variance_from_interaction_pct=float(np.var(b[2] * (Xc[:, 2])) / np.var(Xc @ b) * 100))
T1c = pd.DataFrame({"log FoS (multiplicative scale)": fe_reg(np.log), "FoS (additive scale)": fe_reg(lambda x: x)}).T
T1c.round(5).to_csv(OUT + "I1c_regression_interaction_term.csv"); say("I1 done\n", T1c.round(4).to_string())

# ---------------------------------------------------------------- I2 yield coefficient and critical rainfall
BIG = ME.D.iloc[ME.i_te][ME.COLS].reset_index(drop=True)
def bisect(fun, lo, hi, n=22):
    lo, hi = lo.copy(), hi.copy()
    for _ in range(n):
        mid = (lo + hi) / 2; ok = fun(mid) >= 1; lo = np.where(ok, mid, lo); hi = np.where(ok, hi, mid)
    return (lo + hi) / 2
def i2():
    rows, KY = [], {}
    for a in [0, .1, .2, .3, .4, .5, .6]:
        D = BIG.assign(ru=a); f0, f3 = sur(D.assign(kh=0.)), sur(D.assign(kh=.3))
        ky = bisect(lambda k: sur(D.assign(kh=k)), np.zeros(len(D)), np.full(len(D), .3)); ky = np.where(f0 < 1, 0., np.where(f3 >= 1, np.nan, ky))
        KY[a] = ky
        rows.append(dict(ru=a, pct_failing_static=np.mean(f0 < 1) * 100, pct_ky_gt_0_3=np.mean(f3 >= 1) * 100, median_ky_of_statically_stable=np.nanmedian(np.where(f0 >= 1, ky, np.nan)),
                         pct_ky_lt_0_1=np.mean(np.nan_to_num(ky, nan=9) < .1) * 100, pct_ky_lt_0_15=np.mean(np.nan_to_num(ky, nan=9) < .15) * 100))
    # Bishop check of k_y for 40 slopes at r_u = 0.2
    sub = BIG.assign(ru=.2).sample(40, random_state=4).reset_index(drop=True); kys = KY[.2][sub.index] if False else None
    idx = BIG.sample(40, random_state=4).index.values; Ds = BIG.iloc[idx].assign(ru=.2).reset_index(drop=True)
    kb = []
    for r in Ds.itertuples():
        if ME.bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru=.2, kh=0) < 1: kb.append(0.); continue
        if ME.bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru=.2, kh=.3) >= 1: kb.append(np.nan); continue
        lo, hi = 0., .3
        for _ in range(10):
            m = (lo + hi) / 2
            if ME.bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru=.2, kh=m) >= 1: lo = m
            else: hi = m
        kb.append((lo + hi) / 2)
    kb = np.array(kb); ks = KY[.2][idx]; ok = np.isfinite(kb) & np.isfinite(ks)
    chk = dict(n=int(ok.sum()), MAE_ky=float(np.mean(np.abs(kb[ok] - ks[ok]))), r=float(np.corrcoef(kb[ok], ks[ok])[0, 1]))
    # critical r_u at fixed kh
    cr = []
    for b in [0, .05, .1, .15, .2]:
        D = BIG.assign(kh=b); g0, g6 = sur(D.assign(ru=0.)), sur(D.assign(ru=.6))
        rc = bisect(lambda r: sur(D.assign(ru=r)), np.zeros(len(D)), np.full(len(D), .6)); rc = np.where(g0 < 1, 0., np.where(g6 >= 1, np.nan, rc))
        cr.append(rc)
    return pd.DataFrame(rows), chk, KY, cr
T2, CHK2, KY, CR = cached("i2", i2); T2.round(4).to_csv(OUT + "I2_yield_coefficient_vs_ru.csv", index=False); pd.Series(CHK2).round(4).to_csv(OUT + "I2b_ky_check_vs_Bishop.csv")
# observed rainfall -> r_u relation in the Kaggle training data (median and IQR per rainfall bin)
tr = U.A_sva.iloc[U.s_tr]; bins = np.arange(0, 341, 20); rb = pd.cut(tr.Rainfall_mm_day, bins)
RR = tr.groupby(rb, observed=True).PorePressureRatio.agg(["median", lambda s: s.quantile(.25), lambda s: s.quantile(.75), "size"]); RR.columns = ["ru_median", "ru_q25", "ru_q75", "n"]
RR["rain_mid"] = [i.mid for i in RR.index]; RR = RR.reset_index(drop=True); RR.round(4).to_csv(OUT + "I2c_observed_rainfall_to_ru.csv", index=False)
mono = np.maximum.accumulate(RR.ru_median.values)
def rain_for(ru):   # inverse of the (monotone envelope of the) observed median relation; NaN outside the observed range
    return np.where((ru >= mono[0]) & (ru <= mono[-1]), np.interp(ru, mono + np.arange(len(mono)) * 1e-9, RR.rain_mid.values), np.nan)
crit = []
for b, rc in zip([0, .05, .1, .15, .2], CR):
    st = np.isfinite(rc) & (rc > 0); rr = rain_for(rc[st])
    crit.append(dict(kh=b, pct_failing_dry=np.mean(rc == 0) * 100, pct_never_critical_ru_le_0_6=np.mean(np.isnan(rc)) * 100, median_critical_ru=np.nanmedian(rc[st]),
                     q25_critical_ru=np.nanquantile(rc[st], .25), median_critical_rain_mm_day=np.nanmedian(rr), q25_critical_rain=np.nanquantile(rr, .25),
                     pct_critical_rain_within_observed=np.mean(np.isfinite(rr)) * 100))
T2d = pd.DataFrame(crit); T2d.round(4).to_csv(OUT + "I2d_critical_ru_and_rainfall_vs_kh.csv", index=False); say("I2 done\n", T2.round(3).to_string(), "\n", T2d.round(3).to_string(), CHK2)

# ---------------------------------------------------------------- I3 vulnerability moderators (Bishop, r_u 0.3 & kh 0.15)
R, E, RE = F[(.3, 0.)], F[(0., .15)], F[(.3, .15)]; add = RE - R - E + F0; mul = RE * F0 / (R * E)
N_ = POP.c / (POP.gamma * POP.H); co = (RE < 1) & (R >= 1) & (E >= 1)
mod = []
for nm, v in (("slope angle beta", POP.beta), ("friction angle phi", POP.phi), ("stability number c/(gamma H)", N_), ("cohesion c", POP.c), ("height H", POP.H), ("baseline FoS", pd.Series(F0))):
    mod.append(dict(moderator=nm, spearman_with_additive_interaction=stats.spearmanr(v, add)[0], spearman_with_multiplicative_I=stats.spearmanr(v, mul)[0],
                    spearman_with_relative_combined_drop=stats.spearmanr(v, 1 - RE / F0)[0],
                    median_in_compound_only_failures=np.median(v[co]), median_in_others=np.median(v[~co])))
T3 = pd.DataFrame(mod); T3.round(4).to_csv(OUT + "I3_interaction_moderators.csv", index=False)
cells = []
bq, nq = pd.qcut(POP.beta, 3, labels=["gentle", "medium", "steep"]), pd.qcut(N_, 3, labels=["low c/(gamma H)", "mid", "high c/(gamma H)"])
for b_ in bq.cat.categories:
    for n_ in nq.cat.categories:
        m = ((bq == b_) & (nq == n_)).values
        cells.append(dict(beta_tertile=b_, cohesion_number_tertile=n_, n=int(m.sum()), median_combined_drop_pct=np.median(1 - RE[m] / F0[m]) * 100,
                          median_I=np.median(mul[m]), compound_only_failure_pct=np.mean(co[m]) * 100, near_critical_pct_F0_1_to_1_5=np.mean((F0[m] >= 1) & (F0[m] < 1.5)) * 100))
pd.DataFrame(cells).round(3).to_csv(OUT + "I3b_vulnerability_by_geometry_and_strength.csv", index=False); say("I3 done\n", T3.round(3).to_string())

# ---------------------------------------------------------------- I4 model-based interaction strength
Ate = RV.Ate; SUPP = Ate[RV.FAM != "F4 extreme compound"].sample(150, random_state=8).reset_index(drop=True)
def H2(f, X, j, k):
    n = len(X); vj, vk = X[j].values, X[k].values
    def pd1(col, vals):
        reps = [U.recompute(X.assign(**{col: v})) for v in vals]; return f(pd.concat(reps, ignore_index=True)).reshape(n, n).mean(1)
    def pd2():
        reps = [U.recompute(X.assign(**{j: a, k: b})) for a, b in zip(vj, vk)]; return f(pd.concat(reps, ignore_index=True)).reshape(n, n).mean(1)
    pj, pk, pjk = pd1(j, vj), pd1(k, vk), pd2(); pj, pk, pjk = pj - pj.mean(), pk - pk.mean(), pjk - pjk.mean()
    return float(np.sum((pjk - pj - pk) ** 2) / np.sum(pjk ** 2))
PAIRS = [("Rainfall_mm_day", "SeismicCoefficient"), ("PorePressureRatio", "SeismicCoefficient"), ("GroundwaterDepth_m", "SeismicCoefficient"),
         ("SlopeAngle_deg", "SeismicCoefficient"), ("Cohesion_kPa", "SeismicCoefficient"), ("FrictionAngle_deg", "SeismicCoefficient"), ("Rainfall_mm_day", "PorePressureRatio")]
lg = lambda A: np.log(np.clip(A, .05, 20))
MODS = {"Proposed framework": lambda A: lg(MO.fw(A)), "Mechanics-anchored hybrid": lambda A: lg(RV.mah(A)), "Bishop (MVB surrogate)": lambda A: lg(RV.mech(A))}
def i4():
    rows = []
    for m, f in MODS.items():
        for j, k in PAIRS:
            if m.startswith("Bishop") and j in ("Rainfall_mm_day", "GroundwaterDepth_m"): rows.append(dict(model=m, pair=f"{j} x {k}", H2=0.)); continue
            rows.append(dict(model=m, pair=f"{j} x {k}", H2=H2(f, SUPP, j, k))); say(m, j, k, round(rows[-1]["H2"], 4))
    return pd.DataFrame(rows)
T4 = cached("i4_H", i4); T4.round(4).to_csv(OUT + "I4_Friedman_H_interaction_strength_logFoS.csv", index=False)
def i4s():
    import shap
    X = Ate[RV.FAM != "F4 extreme compound"].sample(500, random_state=9)[U.FEATS]; S = shap.TreeExplainer(RV.MAH[RV.A_]).shap_interaction_values(X)
    M = np.abs(S).mean(0); names = list(X.columns); out = []
    for i in range(len(names)):
        for jj in range(i + 1, len(names)): out.append(dict(pair=f"{names[i]} x {names[jj]}", mean_abs_SHAP_interaction=2 * M[i, jj]))
    T = pd.DataFrame(out).sort_values("mean_abs_SHAP_interaction", ascending=False).reset_index(drop=True); T["rank"] = T.index + 1
    main = pd.Series(np.diag(M), index=names).sort_values(ascending=False); return T, main
T4s, MAIN = cached("i4_shap", i4s); T4s.round(5).to_csv(OUT + "I4b_SHAP_interaction_values_LightGBM.csv", index=False); MAIN.round(5).to_csv(OUT + "I4c_SHAP_main_effects_LightGBM.csv")
# 2-D partial dependence rainfall x kh through the hydrological chain (r_u from the rainfall chain), supported region only
RAIN, KH2 = [0, 35, 70, 105, 140], [0, .03, .06, .09, .12]
def i4p():
    X = Ate[RV.FAM != "F4 extreme compound"].sample(300, random_state=10).reset_index(drop=True); out = {}
    for m, f in (("Proposed framework", MO.fw), ("Mechanics-anchored hybrid", RV.mah), ("Bishop (MVB surrogate)", RV.mech)):
        G = np.zeros((len(RAIN), len(KH2)))
        for i, r in enumerate(RAIN):
            Xr = X.assign(Rainfall_mm_day=float(r)); Xr = Xr.assign(PorePressureRatio=np.clip(U.ru_m.predict(Xr[U.HYD]), .02, .6))
            reps = [U.recompute(Xr.assign(SeismicCoefficient=b)) for b in KH2]; G[i] = np.clip(f(pd.concat(reps, ignore_index=True)), .05, 20).reshape(len(KH2), len(X)).mean(1)
        out[m] = G
    return out
PD2 = cached("i4_pd2", i4p); rows = []
for m, G in PD2.items():
    for i, r in enumerate(RAIN):
        for j, b in enumerate(KH2):
            rows.append(dict(model=m, rain=r, kh=b, PD_FoS=G[i, j], additive_interaction=G[i, j] - G[i, 0] - G[0, j] + G[0, 0], multiplicative_I=G[i, j] * G[0, 0] / (G[i, 0] * G[0, j])))
pd.DataFrame(rows).round(5).to_csv(OUT + "I4d_2D_PDP_rain_x_kh_chain.csv", index=False); say("I4 done\n", T4.round(3).to_string())

# ---------------------------------------------------------------- I5 consistency under combined loading
S5 = POP.sample(200, random_state=6).reset_index(drop=True); CONDS = {"baseline": (0., 0.), "rainfall (r_u 0.3)": (.3, 0.), "seismic (kh 0.15)": (0., .15), "combined": (.3, .15)}
STEPV = {"c": 3., "phi": 1.5, "beta": 2.}
def i5():
    out = {}
    for cn, (a, b) in CONDS.items():
        for v, st in STEPV.items():
            Dp, Dm = S5.assign(ru=a, kh=b), S5.assign(ru=a, kh=b); Dp[v] = Dp[v] + st; Dm[v] = Dm[v] - st
            fp, fm = ME.bishop_many(Dp[ME.COLS].values, f"i5_{cn[:4]}_{v}_p"), ME.bishop_many(Dm[ME.COLS].values, f"i5_{cn[:4]}_{v}_m")
            out[(cn, v)] = (np.log(np.clip(fp, .05, 50)) - np.log(np.clip(fm, .05, 50))) / (2 * st)
    return out
SN = cached("i5", i5); rows = []
for cn in CONDS:
    for v in STEPV: rows.append(dict(condition=cn, variable=v, median_log_sensitivity=np.median(SN[(cn, v)]), ratio_to_baseline=np.median(SN[(cn, v)]) / np.median(SN[("baseline", v)])))
T5 = pd.DataFrame(rows); T5.round(5).to_csv(OUT + "I5_sensitivity_change_under_combined_loading_Bishop.csv", index=False)
# monotonicity of data models per Kaggle loading regime
REG = FW.REG_T; STP = {"PorePressureRatio": (.05, -1), "SeismicCoefficient": (.03, -1), "Rainfall_mm_day": (30, -1), "SlopeAngle_deg": (3, -1), "Cohesion_kPa": (5, 1), "FrictionAngle_deg": (2, 1)}
def i5b():
    rows = []
    for rg in ("low-hazard", "rainfall", "seismic", "compound"):
        X = Ate[REG == rg]; X = X.sample(min(800, len(X)), random_state=1).reset_index(drop=True)
        for m, f in (("Proposed framework", MO.fw), ("Proposed framework + envelope", MO.envelope), ("Mechanics-anchored hybrid", RV.mah)):
            if m.endswith("envelope"): X_ = X.iloc[:300]
            else: X_ = X
            base = f(X_)
            for v, (st, sg) in STP.items():
                Xp = X_.copy(); Xp[v] = np.minimum(Xp[v] + st, U.HI_[v]); Xp = U.recompute(Xp)
                if v == "Rainfall_mm_day": Xp = U.recompute(Xp.assign(PorePressureRatio=np.clip(U.ru_m.predict(Xp[U.HYD]), .02, .6))); b0 = f(U.recompute(X_.assign(PorePressureRatio=np.clip(U.ru_m.predict(X_[U.HYD]), .02, .6))))
                else: b0 = base
                rows.append(dict(regime=rg, model=m, variable=v, violation_pct=float(np.mean(sg * (f(Xp) - b0) < -1e-3) * 100)))
    return pd.DataFrame(rows)
T5b = cached("i5b", i5b); T5b.round(3).to_csv(OUT + "I5b_monotonicity_by_loading_regime.csv", index=False); say("I5 done\n", T5.round(4).to_string())

# ---------------------------------------------------------------- I6 reliability interaction surface
def i6():
    RUg, KHg = np.round(np.arange(0, .501, .05), 3), np.round(np.arange(0, .2501, .025), 3); c_, p_ = ME.samples(100_000, 17); PF = np.zeros((len(RUg), len(KHg)))
    for i, a in enumerate(RUg):
        for j, b in enumerate(KHg):
            Db = pd.DataFrame(dict(H=ME.REF["H"], beta=ME.REF["beta"], c=c_, phi=p_, gamma=ME.REF["gamma"], ru=a, kh=b)); PF[i, j] = np.mean(sur(Db) < 1)
    return RUg, KHg, PF
RUg, KHg, PF = cached("i6", i6); rows = []
for i, a in enumerate(RUg):
    for j, b in enumerate(KHg):
        add = min(PF[i, 0] + PF[0, j] - PF[0, 0], 1); bt = lambda p: -norm.ppf(np.clip(p, 1e-7, 1 - 1e-7))
        rows.append(dict(ru=a, kh=b, Pf=PF[i, j], Pf_additive_expectation=add, Pf_ratio_to_additive=PF[i, j] / max(add, 1e-6), beta=bt(PF[i, j]),
                         beta_additive_expectation=bt(PF[i, 0]) + bt(PF[0, j]) - bt(PF[0, 0])))
pd.DataFrame(rows).round(6).to_csv(OUT + "I6_reliability_interaction_surface.csv", index=False); say("I6 done"); say("DONE")
