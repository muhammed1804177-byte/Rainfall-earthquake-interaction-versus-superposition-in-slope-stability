"""Interaction decomposition on the 600-slope x 25-cell pseudo-static Bishop factorial (15,000 runs).
Separates failures caused by combining two loads (superposition under the no-interaction, multiplicative null
F_null = F_R F_E / F0) from failures caused by the interaction itself (F_RE < 1 <= F_null)."""
import os, numpy as np, pandas as pd
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/interaction_v2/"
R = pd.read_csv(ROOT + "/calibrated_equation/bishop_factorial_runs.csv")
P = R.pivot_table(index="slope", columns=["ru", "kh"], values="FoS")
F0 = P[(0.0, 0.0)]; keep = F0 < 10; P = P[keep]; F0 = F0[keep]
rng = np.random.default_rng(1); rows = []
for ru in [0, .1, .2, .3, .4]:
    for kh in [0, .05, .1, .15, .2]:
        FR, FE, FRE = P[(ru, 0.0)], P[(0.0, kh)], P[(ru, kh)]
        I = FRE * F0 / (FR * FE); null = FR * FE / F0
        loss = (F0 - FRE) / F0 * 100; add = ((F0 - FR) + (F0 - FE)) / F0 * 100
        boot = [np.median(rng.choice(I.values, len(I))) for _ in range(1000)]
        single = (FR < 1) | (FE < 1)
        comp = (FRE < 1) & ~single                       # fail only when combined
        inter = (FRE < 1) & (null >= 1)                  # would not fail without interaction
        share = np.where(F0 - FRE > 1e-9, (null - FRE) / (F0 - FRE) * 100, 0)
        rows.append(dict(ru=ru, kh=kh, n=len(F0), median_loss_pct=np.median(loss), additive_expectation_pct=np.median(add),
                         median_I=np.median(I), I_CI_low=np.percentile(boot, 2.5), I_CI_high=np.percentile(boot, 97.5),
                         pct_I_lt_1=(I < 1 - 1e-9).mean() * 100 if ru * kh > 0 else 0.0,
                         pct_fail_static=(F0 < 1).mean() * 100, pct_fail_single=single.mean() * 100, pct_fail_combined=(FRE < 1).mean() * 100,
                         pct_compound_only=comp.mean() * 100, pct_compound_only_by_superposition=(comp & ~inter).mean() * 100,
                         pct_caused_by_interaction=inter.mean() * 100, median_interaction_share_of_loss_pct=np.median(share) if ru * kh > 0 else 0.0,
                         median_FoS_combined=np.median(FRE)))
T = pd.DataFrame(rows).round(3); T.to_csv(OUT + "V1_interaction_decomposition_600_slopes.csv", index=False)
# where do interaction-caused failures occur: static FoS of those slopes
ru, kh = .3, .15; FR, FE, FRE = P[(ru, 0.0)], P[(0.0, kh)], P[(ru, kh)]; null = FR * FE / F0
m = (FRE < 1) & (null >= 1)
print(T[["ru", "kh", "median_loss_pct", "additive_expectation_pct", "median_I", "pct_I_lt_1", "pct_fail_combined", "pct_compound_only", "pct_caused_by_interaction", "median_interaction_share_of_loss_pct"]].to_string())
print("near-critical null FoS of interaction-caused failures:", null[m].round(3).tolist()[:10])
