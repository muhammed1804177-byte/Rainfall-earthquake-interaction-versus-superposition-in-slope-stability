"""Published-method baselines re-run under the SAME leakage-free protocol (identical splits, features, test touched once):
  GWO-SVR  (grey-wolf-optimised RBF support-vector regression; common in slope-ML papers)
  PSO-ANN  (particle-swarm-optimised multilayer perceptron)
  Physics baselines: infinite-slope FS and Bishop simplified (no learning)
Hyper-parameters are optimised on the VALIDATION set only; SVR is trained on a 20,000-slope subset (O(n^2) cost)."""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_unified.py")).read()
exec(src.split("# ===================================================================== 6. tree models")[0])
import pandas as pd
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from bishop import bishop_fos
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTF = ROOT + "/final_results/"
rng = np.random.default_rng(42); sub = rng.choice(TR["nS"], 20000, replace=False); vsub = rng.choice(VA["nS"], 4000, replace=False)
Ztr, ytr = TR["Z"][sub], TR["lo"][sub]; Zv, yv = VA["Z"][vsub], VA["lo"][vsub]; Zte, yte = TS["Z"], TS["lo"]
def gwo(f, lo, hi, wolves=6, iters=8, seed=0):
    r = np.random.default_rng(seed); D = len(lo); X = r.uniform(lo, hi, (wolves, D)); F = np.array([f(x) for x in X])
    for t in range(iters):
        o = np.argsort(F); A_, B_, C_ = X[o[0]], X[o[1]], X[o[2]]; a = 2 - 2 * t / iters
        for i in range(wolves):
            new = np.zeros(D)
            for L in (A_, B_, C_):
                r1, r2 = r.random(D), r.random(D); A1, C1 = 2 * a * r1 - a, 2 * r2; new += L - A1 * np.abs(C1 * L - X[i])
            X[i] = np.clip(new / 3, lo, hi); F[i] = f(X[i])
        say(f"  GWO iter {t+1}: best {F.min():.4f}")
    return X[np.argmin(F)], F.min()
def pso(f, lo, hi, n=6, iters=8, seed=0):
    r = np.random.default_rng(seed); D = len(lo); X = r.uniform(lo, hi, (n, D)); V = np.zeros_like(X); F = np.array([f(x) for x in X])
    P, PF = X.copy(), F.copy(); g = P[np.argmin(PF)]
    for t in range(iters):
        V = .7 * V + 1.5 * r.random((n, D)) * (P - X) + 1.5 * r.random((n, D)) * (g - X); X = np.clip(X + V, lo, hi)
        F = np.array([f(x) for x in X]); m = F < PF; P[m], PF[m] = X[m], F[m]; g = P[np.argmin(PF)]
        say(f"  PSO iter {t+1}: best {PF.min():.4f}")
    return g, PF.min()
rm = lambda y_, p: mean_squared_error(y_, np.clip(p, .25, 5)) ** .5
t0 = time.time()
fsvr = lambda x: rm(yv, SVR(C=10 ** x[0], gamma=10 ** x[1], epsilon=10 ** x[2], cache_size=1000).fit(Ztr[:6000], ytr[:6000]).predict(Zv))
xs, _ = cached('lit_gwo_svr', lambda: gwo(fsvr, np.array([-1., -3., -3.]), np.array([3., 0., -1.])))
svr = SVR(C=10 ** xs[0], gamma=10 ** xs[1], epsilon=10 ** xs[2], cache_size=2000).fit(Ztr, ytr); t_svr = time.time() - t0
t0 = time.time()
def fann(x): return rm(yv, MLPRegressor(hidden_layer_sizes=(int(x[0]), int(x[0]) // 2), alpha=10 ** x[1], learning_rate_init=10 ** x[2], max_iter=60, early_stopping=True,
                                      random_state=0).fit(Ztr, ytr).predict(Zv))
xa, _ = cached('lit_pso_ann', lambda: pso(fann, np.array([16., -6., -4.]), np.array([256., -2., -2.])))
ann = MLPRegressor(hidden_layer_sizes=(int(xa[0]), int(xa[0]) // 2), alpha=10 ** xa[1], learning_rate_init=10 ** xa[2], max_iter=200, early_stopping=True, random_state=0).fit(TR["Z"][:TR["nS"]], TR["lo"][:TR["nS"]]); t_ann = time.time() - t0
P = {"GWO-SVR (20k train subset)": svr.predict(Zte), "PSO-ANN": ann.predict(Zte), "Infinite-slope FS (physics, no learning)": TS["A"].FS_infinite.values}
bi = rng.choice(len(yte), 1500, replace=False)
bis = np.array([bishop_fos(r.SlopeHeight_m, r.SlopeAngle_deg, r.Cohesion_kPa, r.FrictionAngle_deg, r.UnitWeight_kN_m3, r.PorePressureRatio) for r in TS["A"].iloc[bi].itertuples()])
rows = {}
for n, p in P.items():
    p = np.clip(p, .25, 5); a, b = to_class(yte), to_class(p)
    rows[n] = dict(R2=r2_score(yte, p), RMSE=rm(yte, p), Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1), Real_AUROC=np.nan)
p = np.clip(bis, .25, 5); rows["Bishop simplified (physics, no learning; 1,500 test slopes)"] = dict(R2=r2_score(yte[bi], p), RMSE=rm(yte[bi], p),
    Accuracy=accuracy_score(to_class(yte[bi]), to_class(p)), F1_Marginal=f1_score(to_class(yte[bi]) == 1, to_class(p) == 1), Real_AUROC=np.nan)
yR = real.fail.values; AR = real_matrix(real); ZR = scaler.transform(AR[FEATS]).astype(np.float32)
for n, m in (("GWO-SVR (20k train subset)", svr), ("PSO-ANN", ann)): rows[n]["Real_AUROC"] = roc_auc_score(yR, -m.predict(ZR))
rows["GWO-SVR (20k train subset)"]["train_s"] = t_svr; rows["PSO-ANN"]["train_s"] = t_ann
R = pd.DataFrame(rows).T; R.to_csv(OUTF + "T11_literature_baselines_same_protocol.csv"); say("\n" + R.round(4).to_string()); say("DONE")
