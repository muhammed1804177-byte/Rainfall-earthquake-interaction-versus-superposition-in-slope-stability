"""Test comparison of the original vs Optuna-re-tuned M1 (CNN-BiLSTM-SE-Attention) under the final leakage-free protocol.
Rebuilds ONLY the data pipeline of msh_unified.py (splits, seismic correction, features) - no other experts are trained -
then trains both M1 configurations with identical data, loss, early stopping and seed. Resumable (per-epoch checkpoints)."""
import os, json, sys
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "msh_unified.py")).read()
part1 = src.split("# ===================================================================== 6. tree models")[0]
part7 = src.split("# ===================================================================== 7. deep models")[1].split('say("7  deep models")')[0].split("\n", 1)[1]
exec(part1); exec(part7)
import pandas as pd
from sklearn.metrics import r2_score
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTF = ROOT + "/final_results/"; os.makedirs(OUTF, exist_ok=True)
tr = pd.read_csv(OUTF + "T9_M1_optuna_40_trials.csv"); bp = tr[tr.state == "COMPLETE"].sort_values("value").iloc[0]
SF = Space("fos")
CONF = {"M1 original (12-trial search)": (dict(CFG["M1"]), CFG["M1"]["lr"], CFG["M1"]["bs"]),
        "M1 re-tuned (40-trial search)": (dict(d=int(bp.d), C=int(bp.C), H=int(bp.H), drop=float(bp["drop"])), float(bp.lr), int(bp.bs))}
y = TS["lo"]; rows = {}
for name, (p, lr, bs) in CONF.items():
    tag = "M1orig" if "original" in name else "M1retuned"
    m = train_dl(tag, lambda p=p: M1(p), SF, lr=lr, bs=bs)
    pr = np.clip(dl_fn(m, SF)(TS["A"]), .25, 5); a, b = to_class(y), to_class(pr)
    rows[name] = dict(d=p["d"], C=p["C"], H=p["H"], dropout=round(p["drop"], 3), lr=lr, batch=bs, params=sum(q.numel() for q in m.parameters()),
                      R2=r2_score(y, pr), RMSE=mean_squared_error(y, pr) ** .5, MAE=mean_absolute_error(y, pr), Accuracy=accuracy_score(a, b),
                      F1_Marginal=f1_score(a == 1, b == 1), Recall_Failure=recall_score(a == 0, b == 0))
    say(name, {k: round(v, 4) if isinstance(v, float) else v for k, v in rows[name].items()})
R = pd.DataFrame(rows).T; R.to_csv(OUTF + "T10_M1_retuned_vs_original.csv"); say("\n" + R.to_string()); say("DONE")
