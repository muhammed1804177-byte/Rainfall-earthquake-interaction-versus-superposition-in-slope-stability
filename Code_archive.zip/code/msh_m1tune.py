"""Expanded Optuna search for M1 (CNN-BiLSTM-SE-Attention) under the final leakage-free protocol.
40 trials (TPE + median pruning, SQLite -> resumable) on 30,000 training slopes x 6 epochs, scored on validation only;
best configuration retrained on all 84,000 training slopes; test evaluated once and compared with the original M1."""
import os, json, time, warnings
import numpy as np, pandas as pd, torch, torch.nn.functional as Fnn, optuna
warnings.filterwarnings("ignore"); optuna.logging.set_verbosity(optuna.logging.WARNING)
import msh_unified as U
from sklearn.metrics import r2_score, accuracy_score
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/final_results/"); T0 = time.time()
def say(*a): print(f"[M1T {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
rng = np.random.default_rng(42); sub = rng.choice(len(U.TR["Z"]), 30000, replace=False)
Xs, LOs, HIs, Ws = (torch.tensor(U.TR["Z"][sub]), torch.tensor(U.SF.enc(U.TR["lo"][sub]), dtype=torch.float32),
                    torch.tensor(U.SF.enc(U.TR["hi"][sub]), dtype=torch.float32), torch.tensor(U.TR["w"][sub], dtype=torch.float32))
def objective(t):
    p = dict(d=t.suggest_categorical("d", [16, 24, 32, 48]), C=t.suggest_categorical("C", [48, 64, 96, 128]), H=t.suggest_categorical("H", [32, 48, 64, 96]),
             drop=t.suggest_float("drop", 0., .35)); lr = t.suggest_float("lr", 3e-4, 6e-3, log=True); bs = t.suggest_categorical("bs", [256, 512, 1024])
    torch.manual_seed(0); m = U.M1(p); opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=t.suggest_float("wd", 1e-6, 1e-3, log=True)); best = 1e9
    for ep in range(6):
        m.train(); pm = torch.randperm(len(Xs))
        for k in range(0, len(Xs), bs):
            b = pm[k:k + bs]; o = m(Xs[b]); loss = (Ws[b] * (Fnn.relu(LOs[b] - o) ** 2 + Fnn.relu(o - HIs[b]) ** 2)).sum() / Ws[b].sum()
            opt.zero_grad(); loss.backward(); opt.step()
        v = U.iloss_np(U.SF.dec(U.net_out(m, U.VA["Z"])), U.VA); best = min(best, v); t.report(v, ep)
        if t.should_prune(): raise optuna.TrialPruned()
    return best
st = optuna.create_study(study_name="m1u", storage="sqlite:///" + __import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptFinal/m1tune.db", load_if_exists=True, direction="minimize",
                         sampler=optuna.samplers.TPESampler(seed=42), pruner=optuna.pruners.MedianPruner(n_startup_trials=6, n_warmup_steps=2))
st.enqueue_trial(dict(d=16, C=96, H=64, drop=.18, lr=.0042, bs=512, wd=1e-4), skip_if_exists=True)      # original M1 settings as trial 0
done = len([t for t in st.trials if t.state in (optuna.trial.TrialState.COMPLETE, optuna.trial.TrialState.PRUNED)])
st.optimize(objective, n_trials=max(0, 40 - done), callbacks=[lambda s, t: say(f"trial {t.number} {t.state.name} {t.value}")])
bp = st.best_params; say("best:", bp, st.best_value)
pd.DataFrame([dict(n=t.number, value=t.value, state=t.state.name, **t.params) for t in st.trials]).to_csv(OUT + "T9_M1_optuna_40_trials.csv", index=False)
mt = U.train_dl("M1_retuned", lambda: U.M1(dict(d=bp["d"], C=bp["C"], H=bp["H"], drop=bp["drop"])), U.SF, lr=bp["lr"], bs=bp["bs"])
p_new = np.clip(U.dl_fn(mt, U.SF)(U.TS["A"]), .25, 5); p_old = np.clip(U.PT["M1 CNN-BiLSTM-SE-Attention"], .25, 5); y = U.TS["lo"]
R = pd.DataFrame({"M1 original (12 trials, 20k rows)": dict(RMSE=U.mean_squared_error(y, p_old) ** .5, R2=r2_score(y, p_old), Accuracy=accuracy_score(U.to_class(y), U.to_class(p_old))),
                  "M1 re-tuned (40 trials, 30k rows)": dict(RMSE=U.mean_squared_error(y, p_new) ** .5, R2=r2_score(y, p_new), Accuracy=accuracy_score(U.to_class(y), U.to_class(p_new)))}).T
R.round(5).to_csv(OUT + "T10_M1_retuned_vs_original.csv"); say("\n" + R.round(4).to_string()); say("DONE")
