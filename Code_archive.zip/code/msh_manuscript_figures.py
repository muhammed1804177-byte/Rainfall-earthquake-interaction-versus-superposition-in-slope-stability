"""Manuscript figure set (main text, Fig. 1-14), each figure in its own named palette chosen by the authors.
Every palette was checked with the colour-vision-deficiency validator (all pairs: CVD dE >= 9, normal vision dE >= 15) after
small shade adjustments. Built from saved result tables and caches only (no retraining).
Output: figures_manuscript/Fig01..Fig14 (PNG 600 dpi + PDF)."""
import os, sys, shutil, json, traceback
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap as LSC, TwoSlopeNorm, LogNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from scipy.stats import spearmanr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_style as S
S.apply()
R = os.environ.get("MSH_OUT", os.path.dirname(HERE)) + "/"; WK = os.environ.get("MSH_WORK", R + ".work") + "/"
OUT = R + "figures_manuscript/"; os.makedirs(OUT, exist_ok=True)
INK, INK2, GRIDC, AXC = S.INK, S.INK2, S.GRID, S.AXIS
PAL = {  # validated shades of the requested named palettes
    "hazard": dict(sage="#9DB596", slate="#46525F", terra="#B5573B"),
    "verif": dict(steel="#3F72A3", orange="#CC6A28"),
    "fact": dict(teal="#1F8A84", amber="#D99A1E", indigo="#3F3D8F"),
    "yield": dict(olive="#9AAA3C", copper="#A3561E", slate="#46525F"),
    "rel": dict(midnight="#1F2A50", sage="#7FA07A"),
    "vuln": dict(plum="#7B3F73", moss="#6F7F3A", rose="#C9848A"),
    "sens": dict(forest="#2F6B3A", steel="#4A7BA6"),
    "inter": dict(jade="#1F9E78", indigo="#3F3D8F", terra="#B5573B"),
    "mech": dict(graphite="#3A3D42", cobalt="#2350A8", gold="#C9A227"),
    "comp": dict(slate="#A3ADB8", teal="#0F7F75", amber="#D99A1E"),
    "cov": dict(cobalt="#2350A8", sage="#9DB596", copper="#9A5520"),
    "cal": dict(blue="#5B7DA8", olive="#A8B54E", terra="#9E4630"),
    "rem": dict(emerald="#1E8A5A", slate="#4F5D6B", sand="#C8A877")}
seq = lambda *c: LSC.from_list("s", ["#FFFFFF", *c])
done, failed = [], []
def save(n, tight=True):
    if tight: plt.tight_layout()
    for e in ("png", "pdf"): plt.savefig(OUT + n + "." + e, dpi=600 if e == "png" else None, bbox_inches="tight")
    plt.close("all"); done.append(n)
def fig(name):
    def w(f):
        try: f(); print("ok", name, flush=True)
        except Exception: failed.append(name); plt.close("all"); print("FAIL", name); traceback.print_exc()
        return f
    return w
def lab(ax, x, y, s, **k): k.setdefault("fontsize", 7.4); k.setdefault("color", INK2); ax.text(x, y, s, **k)
def heat(ax, M, rows, cols, cmap, norm=None, fmt="{:.0f}", vmin=None, vmax=None):
    im = ax.imshow(M, cmap=cmap, norm=norm, vmin=None if norm else vmin, vmax=None if norm else vmax, aspect="auto", origin="lower")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M[i, j]
            if np.isfinite(v): ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=7.2, color=S.text_on(im.cmap(im.norm(v))))
    ax.set_xticks(range(len(cols)), cols); ax.set_yticks(range(len(rows)), rows); ax.grid(False)
    for sp in ax.spines.values(): sp.set_visible(False)
    return im
I_, RV_, F_, M_, Q_, P_ = (R + d + "/" for d in ("interaction_results", "review_results", "final_model_results", "mechanics_results", "q1_results", "improvement_results"))

# Fig 1 workflow (already drawn in the blue-teal-purple style)
for e in ("png", "pdf", "svg"):
    src = R + "figures_final/Fig00_study_workflow." + e
    if os.path.exists(src): shutil.copy(src, OUT + "Fig01_study_workflow." + e)
done.append("Fig01_study_workflow")

@fig("Fig02")
def _():
    p = PAL["hazard"]; d = pd.read_csv(os.environ.get("MSH_DATA", "/mnt/user-data/uploads") + "/1791149933879_Slope_dataset_SVA.csv", usecols=["Rainfall_mm_day", "SeismicCoefficient"]).sample(15000, random_state=1)
    k = d.SeismicCoefficient; fam = np.select([k < .03, k < .10, k < .1201], ["F1", "F2", "F3"], "F4")
    col = {"F1": p["sage"], "F2": p["slate"], "F3": "#D08A70", "F4": p["terra"]}; nm = {"F1": "F1 low hazard", "F2": "F2 moderate", "F3": "F3 elevated", "F4": "F4 extreme compound"}
    f, axs = plt.subplots(1, 2, figsize=(10, 3.9), gridspec_kw=dict(width_ratios=[1.45, 1])); ax = axs[0]
    ax.axhspan(.1201, .15, color="#EEF0EC", zorder=0); ax.axvspan(160, 180, color="#EEF0EC", zorder=0); lab(ax, 300, .135, "no slopes in the dataset", ha="right", va="center", style="italic")
    for f_ in nm: m = fam == f_; ax.scatter(d.Rainfall_mm_day[m], k[m], s=2.5, color=col[f_], lw=0, alpha=.75, rasterized=True, label=nm[f_])
    ax.set(xlabel="Rainfall (mm/day)", ylabel="Seismic coefficient kₕ", title="(a) Hazard space of the 120,000 slopes", xlim=(0, 325), ylim=(0, .305)); ax.legend(markerscale=4, loc="upper left")
    q = pd.read_csv(Q_ + "QF1_scenario_family_envelopes.csv", header=[0, 1], index_col=0).iloc[:, -2]; y = np.arange(len(q)); ax = axs[1]
    ax.barh(y, q.values, color=[col[n.split()[0]] for n in q.index], height=.62)
    for i, v in enumerate(q.values): lab(ax, v + 1.5, i, f"{v:.0f} %", va="center")
    ax.set_yticks(y, [nm[n.split()[0]] for n in q.index]); ax.invert_yaxis(); ax.grid(axis="y", visible=False); ax.set(xlabel="Slopes with FoS < 1 (%)", title="(b) Failure share per family", xlim=(0, 112))
    save("Fig02_hazard_space_and_families")

@fig("Fig03")
def _():
    p = PAL["verif"]; t = pd.read_csv(M_ + "M1c_verification_points.csv"); st = pd.read_csv(M_ + "M1_solver_verification_vs_MP.csv", index_col=0).iloc[:, 0]; b = pd.read_csv(M_ + "M1b_verification_by_kh.csv")
    f, axs = plt.subplots(1, 2, figsize=(9.6, 4), gridspec_kw=dict(width_ratios=[1.25, 1])); ax = axs[0]; khs = sorted(t.kh.unique())
    cs = [LSC.from_list("b", ["#B9CFE6", p["steel"], "#1D3D5E"])(x) for x in np.linspace(0, 1, len(khs))]; lim = (0, min(6, t[["FoS_MorgensternPrice", "FoS_Bishop_PS"]].quantile(.995).max()))
    ax.plot(lim, lim, color=p["orange"], lw=1.4, ls=(0, (4, 3)), zorder=4, label="1 : 1")
    for k_, c in zip(khs, cs): m = t.kh == k_; ax.scatter(t.FoS_MorgensternPrice[m], t.FoS_Bishop_PS[m], s=6, color=c, lw=0, alpha=.85, rasterized=True, label=f"kₕ {k_:g}")
    ax.set(xlim=lim, ylim=lim, xlabel="FoS, Morgenstern–Price (independent)", ylabel="FoS, pseudo-static Bishop (this study)", title="(a) 2,000 verification cases")
    ax.legend(markerscale=2.5, loc="lower right", ncol=2, fontsize=7)
    lab(ax, .03, .97, f"r = {st.pearson_r:.3f}   R² = {st.R2_vs_MP:.3f}\nmedian ratio {st.median_ratio_Bishop_over_MP:.3f}\n{st.within_10pct:.1f} % within ±10 %\nFoS < 1 agreement {st.class_agreement_FoS_lt_1:.1f} %", transform=ax.transAxes, va="top", color=INK)
    ax = axs[1]; x = np.arange(len(b)); ax.bar(x, b.MAPE_pct_FoS_ge_0_3, color=p["steel"], width=.62); ax.axhline(st.MAPE_pct_FoS_ge_0_3, color=p["orange"], lw=1.4, ls=(0, (4, 3)))
    lab(ax, len(b) - .5, st.MAPE_pct_FoS_ge_0_3 + .12, f"overall {st.MAPE_pct_FoS_ge_0_3:.1f} %", ha="right", color=p["orange"])
    for i, v in enumerate(b.MAPE_pct_FoS_ge_0_3): lab(ax, i, v / 2, f"{v:.1f}", ha="center", color="white", fontsize=7)
    ax.set_xticks(x, [f"{k:g}" for k in b.kh]); ax.grid(axis="x", visible=False); ax.set(xlabel="Seismic coefficient kₕ", ylabel="MAPE vs Morgenstern–Price (%)", title="(b) Agreement is uniform across kₕ")
    save("Fig03_solver_verification")

@fig("Fig04")
def _():
    p = PAL["fact"]; t = pd.read_csv(I_ + "I1_factorial_loading_matrix_Bishop.csv"); ru, kh = sorted(t.ru.unique()), sorted(t.kh.unique())
    P = lambda c: t.pivot(index="ru", columns="kh", values=c).reindex(index=ru, columns=kh).values
    f, axs = plt.subplots(1, 3, figsize=(12.2, 3.9), gridspec_kw=dict(width_ratios=[1, 1.15, 1]))
    heat(axs[0], P("median_drop_pct"), [f"{v:g}" for v in ru], [f"{v:g}" for v in kh], seq("#BFE3E0", p["teal"], "#0B4A47"), vmin=0, vmax=60)
    axs[0].set(xlabel="Seismic coefficient kₕ", ylabel="Pore-pressure ratio rᵤ", title="(a) Median FoS reduction (%)")
    ax = axs[1]; cs = [LSC.from_list("i", ["#A9A7DE", p["indigo"], "#211F5A"])(x) for x in np.linspace(0, 1, len(kh) - 1)]
    for k_, c in zip(kh[1:], cs):
        e = t[np.isclose(t.kh, k_)].sort_values("ru"); ax.plot(e.ru, e.median_drop_pct, "-o", color=c, ms=3.5, label=f"kₕ {k_:g}"); ax.plot(e.ru, e.additive_expected_drop_pct, ":", color=c, lw=1.4)
    e = t[np.isclose(t.kh, 0)].sort_values("ru"); ax.plot(e.ru, e.median_drop_pct, "-o", color=p["teal"], ms=3.5, label="rainfall only")
    h, l = ax.get_legend_handles_labels(); h.append(Line2D([], [], color=INK2, ls=":", lw=1.4)); l.append("sum of single effects"); ax.legend(h, l, loc="upper left", fontsize=7)
    ax.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Median FoS reduction (%)", title="(b) Combined (solid) vs additive (dotted)")
    M = P("failure_share_interaction_pp"); lim = max(1, np.nanmax(np.abs(M)))
    im = heat(axs[2], M, [f"{v:g}" for v in ru], [f"{v:g}" for v in kh], LSC.from_list("d", [(0, p["teal"]), (.25, "#9FD1CD"), (.5, "#F4F4F2"), (.75, "#EFC66F"), (1, "#8A5A06")]), norm=TwoSlopeNorm(0, -lim, lim), fmt="{:+.0f}")
    axs[2].set(xlabel="Seismic coefficient kₕ", title="(c) Extra failures beyond additive (pp)"); cb = plt.colorbar(im, ax=axs[2], pad=.02, shrink=.9); cb.outline.set_visible(False); cb.set_label("percentage points")
    save("Fig04_rainfall_seismic_factorial")

@fig("Fig05")
def _():
    p = PAL["yield"]; a = pd.read_csv(I_ + "I2_yield_coefficient_vs_ru.csv"); b = pd.read_csv(I_ + "I2d_critical_ru_and_rainfall_vs_kh.csv"); r = pd.read_csv(I_ + "I2c_observed_rainfall_to_ru.csv")
    f, axs = plt.subplots(1, 3, figsize=(12.2, 3.8)); ax = axs[0]
    ax.plot(a.ru, a.median_ky_of_statically_stable, "-o", color=p["olive"], ms=4.5)
    for x_, y_ in zip(a.ru, a.median_ky_of_statically_stable): lab(ax, x_, y_ + .006, f"{y_:.2f}", ha="center", fontsize=6.8)
    ax.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Median yield coefficient k$_y$", title="(a) Wetting lowers the yield coefficient", ylim=(0, .2))
    ax = axs[1]; ax.bar(a.ru, a.pct_failing_static, width=.07, color=p["slate"], label="fails without earthquake")
    ax.bar(a.ru, a.pct_ky_lt_0_15 - a.pct_failing_static, width=.07, bottom=a.pct_failing_static, color=p["copper"], label="fails at kₕ 0.15 (k$_y$ < 0.15)")
    for x_, y_ in zip(a.ru, a.pct_ky_lt_0_15): lab(ax, x_, y_ + 1, f"{y_:.0f}", ha="center", fontsize=6.8)
    ax.set(xlabel="Pore-pressure ratio rᵤ", ylabel="Slopes (%)", title="(b) Share that a kₕ 0.15 event fails"); ax.legend(loc="upper left", fontsize=7); ax.grid(axis="x", visible=False)
    ax = axs[2]; ax.axvspan(140, 180, color="#EEF0EA", zorder=0); lab(ax, 160, .02, "no data", ha="center", fontsize=6.6, style="italic")
    ax.fill_between(r.rain_mid, r.ru_q25, r.ru_q75, color=p["olive"], alpha=.22, lw=0, label="observed rᵤ, IQR"); ax.plot(r.rain_mid, r.ru_median, "-", color=p["olive"], label="observed rᵤ, median")
    cs = [LSC.from_list("c", ["#E3B48F", p["copper"], "#5A2D0C"])(x) for x in np.linspace(0, 1, len(b))]
    for (_, row), c in zip(b.iterrows(), cs):
        ax.plot([0, row.median_critical_rain_mm_day], [row.median_critical_ru] * 2, color=c, lw=1, ls=(0, (3, 2)))
        ax.plot([row.median_critical_rain_mm_day], [row.median_critical_ru], "o", color=c, ms=4.5, mec="white", mew=.6, zorder=4, label=f"critical rᵤ, kₕ {row.kh:g} → {row.median_critical_rain_mm_day:.0f} mm/day")
    ax.set(xlabel="Rainfall (mm/day)", ylabel="Pore-pressure ratio rᵤ", title="(c) Rainfall at which kₕ becomes critical", xlim=(0, 340), ylim=(0, .62)); ax.legend(loc="upper left", fontsize=6.3)
    save("Fig05_yield_coefficient_and_thresholds")

@fig("Fig06")
def _():
    p = PAL["rel"]; t = pd.read_csv(I_ + "I6_reliability_interaction_surface.csv"); ru, kh = sorted(t.ru.unique()), sorted(t.kh.unique())
    P = lambda c: t.pivot(index="ru", columns="kh", values=c).reindex(index=ru, columns=kh).values; ext = (kh[0] - .0125, kh[-1] + .0125, ru[0] - .025, ru[-1] + .025)
    f, axs = plt.subplots(1, 2, figsize=(10.6, 4.1)); pf = np.clip(P("Pf") * 100, 1e-3, 100)
    im = axs[0].imshow(pf, cmap=seq("#DCE8D9", p["sage"], "#3E5A6E", p["midnight"]), norm=LogNorm(1e-3, 100), aspect="auto", origin="lower", extent=ext)
    cs = axs[0].contour(kh, ru, pf, levels=[1, 10, 50], colors=["white"], linewidths=.9); axs[0].clabel(cs, fmt=lambda v: f"Pf {v:g}%", fontsize=6.8)
    axs[0].grid(False); axs[0].set(xlabel="Seismic coefficient kₕ", ylabel="Pore-pressure ratio rᵤ", title="(a) Probability of failure, reference slope"); cb = plt.colorbar(im, ax=axs[0], pad=.02); cb.set_label("Pf (%)"); cb.outline.set_visible(False)
    rat = np.where((P("Pf") < 1e-4) | (P("Pf_additive_expectation") < 1e-4), np.nan, P("Pf_ratio_to_additive"))
    im2 = axs[1].imshow(np.log10(np.clip(rat, .1, 1000)), cmap=LSC.from_list("d", [(0, p["sage"]), (.5, "#F4F4F2"), (.75, "#5D6B93"), (1, p["midnight"])]), norm=TwoSlopeNorm(0, -1, 3), aspect="auto", origin="lower", extent=ext)
    axs[1].grid(False); axs[1].set(xlabel="Seismic coefficient kₕ", title="(b) Combined Pf ÷ additive expectation")
    cb2 = plt.colorbar(im2, ax=axs[1], pad=.02, ticks=[-1, 0, 1, 2, 3]); cb2.ax.set_yticklabels(["0.1×", "1×", "10×", "100×", "1000×"]); cb2.outline.set_visible(False)
    lab(axs[1], .02, .97, "blank: Pf or its additive expectation < 0.01 %", transform=axs[1].transAxes, va="top", fontsize=6.8)
    save("Fig06_reliability_surface")

@fig("Fig07")
def _():
    p = PAL["vuln"]; t = pd.read_csv(I_ + "I3b_vulnerability_by_geometry_and_strength.csv"); m = pd.read_csv(I_ + "I3_interaction_moderators.csv")
    bt, nt = list(dict.fromkeys(t.beta_tertile)), list(dict.fromkeys(t.cohesion_number_tertile)); f, axs = plt.subplots(1, 2, figsize=(10.4, 3.9))
    M = t.pivot(index="cohesion_number_tertile", columns="beta_tertile", values="compound_only_failure_pct").reindex(index=nt, columns=bt).values
    heat(axs[0], M, ["low c/(γH)", "mid c/(γH)", "high c/(γH)"], ["gentle β", "medium β", "steep β"], seq("#F2DADC", p["rose"], p["plum"], "#3E1B3A"), vmin=0, vmax=max(5, np.nanmax(M)), fmt="{:.0f}%")
    axs[0].set(title="(a) Slopes failing only under combined loading")
    v = m.spearman_with_relative_combined_drop.values; y = np.arange(len(m)); ax = axs[1]
    ax.barh(y, v, color=[p["moss"] if x > 0 else p["plum"] for x in v], height=.6); ax.axvline(0, color=AXC, lw=.8)
    ax.set_yticks(y, m.moderator.str.replace("beta", "β").str.replace("phi", "φ").str.replace("gamma", "γ")); ax.invert_yaxis(); ax.grid(axis="y", visible=False)
    for i, x in enumerate(v): lab(ax, x + (.02 if x >= 0 else -.02), i, f"{x:+.2f}", va="center", ha="left" if x >= 0 else "right")
    ax.legend(handles=[Patch(color=p["moss"], label="larger loss when higher"), Patch(color=p["plum"], label="larger loss when lower")], loc="lower right", fontsize=7)
    ax.set(xlabel="Spearman ρ with relative FoS loss (rᵤ 0.3 + kₕ 0.15)", title="(b) What makes a slope lose more", xlim=(-1, 1)); save("Fig07_vulnerability")

@fig("Fig08")
def _():
    p = PAL["sens"]; t = pd.read_csv(I_ + "I5_sensitivity_change_under_combined_loading_Bishop.csv"); v = pd.read_csv(I_ + "I5b_monotonicity_by_loading_regime.csv"); g6 = pd.read_csv(F_ + "F6_final_model_monotonicity_by_regime.csv")
    conds = list(dict.fromkeys(t.condition)); cc = ["#C9CED3", p["steel"], p["forest"], "#173A22"]; vars_ = ["c", "phi", "beta"]; vl = {"c": "Cohesion c", "phi": "Friction angle φ", "beta": "Slope angle β"}
    f, axs = plt.subplots(1, 2, figsize=(10.8, 3.9)); x = np.arange(3); w = .2
    for i, (cn, c) in enumerate(zip(conds, cc)):
        axs[0].bar(x + (i - 1.5) * w, t[t.condition == cn].set_index("variable").reindex(vars_).median_log_sensitivity.abs().values, w, color=c, label=cn.replace("r_u", "rᵤ").replace("kh", "kₕ"))
    axs[0].set_xticks(x, [vl[k] for k in vars_]); axs[0].grid(axis="x", visible=False); axs[0].legend(fontsize=7, loc="upper left")
    axs[0].set(ylabel="|∂ ln FoS / ∂x|, Bishop (median)", title="(a) Property effects change under combined loading")
    vv = v.groupby(["regime", "model"]).violation_pct.mean().unstack(); gg = g6.groupby(["regime", "model"]).violation_pct_abs_1e3.mean().unstack()
    regs = ["low-hazard", "rainfall", "seismic", "compound"]
    sty = [("Data-only framework", vv["Proposed framework"], p["steel"], "o", "-"), ("Final model (monotone + envelope)", gg["final blend v2 + envelope (kh, r_u)"], p["forest"], "D", "-")]
    for nm, s_, c, mk, ls in sty: axs[1].plot(range(4), s_.reindex(regs).values, ls, marker=mk, color=c, ms=5, label=nm)
    axs[1].set_xticks(range(4), regs); axs[1].set(ylabel="Monotonicity violations (% of slopes)", title="(b) Physical consistency per loading regime"); axs[1].legend(fontsize=7)
    save("Fig08_property_sensitivity_and_monotonicity")

@fig("Fig09")
def _():
    p = PAL["inter"]; h = pd.read_csv(I_ + "I4_Friedman_H_interaction_strength_logFoS.csv"); s = pd.read_csv(I_ + "I4b_SHAP_interaction_values_LightGBM.csv"); d = pd.read_csv(RV_ + "R6b_PDP_curves.csv")
    XN = {"FS_infinite": "FS∞", "StabilityNumber_N": "stability no. N", "FrictionRatio": "friction ratio"}
    nice = lambda q: " × ".join(XN.get(x.strip(), S.VAR_LABEL.get(x.strip(), x.strip())).replace("Seismic coefficient kₕ", "kₕ").replace("Pore-pressure ratio rᵤ", "rᵤ") for x in q.split(" x "))
    f, axs = plt.subplots(2, 2, figsize=(11.2, 7.6)); ax = axs[0, 0]; pairs = list(dict.fromkeys(h.pair)); y = np.arange(len(pairs)); hg = .26
    sty = {"Proposed framework": (p["indigo"], None, "data-only framework"), "Mechanics-anchored hybrid": (p["jade"], None, "mechanics-anchored hybrid"), "Bishop (MVB surrogate)": ("white", "////", "Bishop (reference)")}
    for i, (m, (c, hatch, nm)) in enumerate(sty.items()):
        ax.barh(y + (i - 1) * hg, h[h.model == m].set_index("pair").reindex(pairs).H2.values * 100, hg, color=c, hatch=hatch, edgecolor=p["terra"] if hatch else c, lw=.8 if hatch else 0, label=nm)
    ax.set_yticks(y, [nice(q) for q in pairs]); ax.invert_yaxis(); ax.grid(axis="y", visible=False); ax.legend(loc="lower right", fontsize=7)
    ax.set(xlabel="Friedman H² on log FoS (%)", title="(a) Interaction strength of each pair")
    ax = axs[0, 1]; top = s.head(10).iloc[::-1]; col = [p["terra"] if "SeismicCoefficient" in q else (p["jade"] if any(k in q for k in ("Rain", "Pore", "Ground", "Weather")) else p["indigo"]) for q in top.pair]
    ax.barh(np.arange(10), top.mean_abs_SHAP_interaction, color=col, height=.62); ax.set_yticks(np.arange(10), [nice(q) for q in top.pair]); ax.grid(axis="y", visible=False)
    ax.legend(handles=[Patch(color=p["terra"], label="involves kₕ"), Patch(color=p["jade"], label="hydrology pair"), Patch(color=p["indigo"], label="geometry / strength")], loc="lower right", fontsize=7)
    ax.set(xlabel="mean |SHAP interaction| (FoS)", title="(b) Ten strongest SHAP interactions")
    st2 = {"Proposed framework": (p["indigo"], "-", "o", "data-only framework"), "Mechanics-anchored hybrid": (p["jade"], "-", "D", "mechanics-anchored hybrid"), "Bishop (MVB surrogate)": (p["terra"], "--", "o", "Bishop (reference)")}
    for ax, var, ttl in ((axs[1, 0], "SeismicCoefficient", "(c) Partial dependence on kₕ"), (axs[1, 1], "PorePressureRatio", "(d) Partial dependence on rᵤ")):
        for m, (c, ls, mk, nm) in st2.items():
            e = d[(d.variable == var) & (d.model == m)]; ax.fill_between(e.x, e.q10, e.q90, color=c, alpha=.10, lw=0); ax.plot(e.x, e.PDP_norm, ls, marker=mk, color=c, ms=3.5, mfc="white" if "Bishop" in m else c, label=nm)
        ax.axhline(1, color=AXC, lw=.8); ax.set(xlabel="Seismic coefficient kₕ" if var.startswith("S") else "Pore-pressure ratio rᵤ", ylabel="FoS / FoS(x = 0)", title=ttl, ylim=(.45, 1.03))
    axs[1, 0].legend(fontsize=7, loc="lower left"); save("Fig09_interaction_strength_and_partial_dependence")

@fig("Fig10")
def _():
    p = PAL["mech"]; a = pd.read_csv(M_ + "M4_mechanics_consistency_audit.csv"); f7 = pd.read_csv(F_ + "F7_final_model_v2_mechanics_audit.csv").set_index("variable")
    var = ["c", "phi", "beta", "H", "gamma", "ru", "kh"]; vl = {"c": "Cohesion c", "phi": "Friction angle φ", "beta": "Slope angle β", "H": "Height H", "gamma": "Unit weight γ", "ru": "Pore pressure rᵤ", "kh": "Seismic kₕ"}
    fw = a[a.model == "Final framework"].set_index("variable").ratio_of_medians; mv = a[a.model.str.startswith("MVB")].set_index("variable").ratio_of_medians; fin = f7.ratio_to_Bishop
    f, axs = plt.subplots(1, 2, figsize=(11.2, 4.4), gridspec_kw=dict(width_ratios=[1.15, 1])); ax = axs[0]; y = np.arange(7)[::-1]
    ax.axvspan(.8, 1.25, color="#F1ECDA", zorder=0); ax.axvline(1, color=p["graphite"], ls=(0, (4, 3)), lw=1)
    for i, k in zip(y, var): ax.plot([min(fw[k], fin[k]), max(fw[k], fin[k])], [i, i], color=AXC, lw=1.2, zorder=1)
    ax.scatter(fw[var].abs(), y, s=46, color=p["graphite"], zorder=3, label="data-only framework")
    ax.scatter(mv[var].abs(), y, s=46, facecolor="white", edgecolor=p["cobalt"], lw=1.4, zorder=3, label="Bishop surrogate (MVB)")
    ax.scatter(fin[var].abs(), y, s=58, color=p["gold"], edgecolor=p["graphite"], lw=.6, zorder=4, label="final model")
    ax.set_xscale("log"); ax.set_xticks([.1, .2, .5, 1, 2], ["0.1", "0.2", "0.5", "1", "2"]); ax.set_xlim(.08, 2.2); ax.set_yticks(y, [vl[k] for k in var]); ax.grid(axis="y", visible=False)
    lab(ax, 1.03, 6.55, "Bishop = 1", fontsize=7); ax.set(xlabel="Sensitivity relative to Bishop (log scale)", title="(a) Mechanics-consistency audit", ylim=(-.7, 7)); ax.legend(loc="upper center", bbox_to_anchor=(.5, -.16), ncol=3, fontsize=7)
    # (b) Pareto front of the final model's blend family (test), weight selected on validation
    src = open(os.path.join(HERE, "msh_unified.py")).read(); g = {"__file__": os.path.join(HERE, "msh_unified.py"), "__name__": "unified_lite"}; exec(src.split("# ===================================================================== 4. real case histories")[0], g)
    y_ = g["sva"].FoS.values; yt = y_[g["s_te"]]; BR = joblib.load(WK + "finalblend/branches.joblib"); A2 = joblib.load(WK + "finalblend/anch_v2.joblib")
    SF = joblib.load(WK + "mech/m4_sens_Finalframework.joblib"); SD = joblib.load(WK + "finalblend/sens_d2.joblib"); B = joblib.load(WK + "mech/m4_sens_BishopPSLEM.joblib")
    W2 = float(pd.read_csv(F_ + "F5_final_model_v1_vs_v2_test.csv").w.iloc[1]); ws = np.round(np.linspace(0, 1, 41), 3); r2, rk = [], []
    for w in ws:
        pt = np.clip(np.exp(w * np.log(BR["test"][0]) + (1 - w) * np.log(A2["test"])), .25, 5); r2.append(1 - np.sum((yt - pt) ** 2) / np.sum((yt - yt.mean()) ** 2))
        sk = w * SF["kh"] + (1 - w) * SD["kh"]; ok = np.isfinite(sk) & np.isfinite(B["kh"]); rk.append(np.median(sk[ok]) / np.median(B["kh"][ok]))
    ax = axs[1]; ax.plot(rk, r2, "-o", color=p["graphite"], ms=3, label="blend weight w from 0 to 1"); ax.axhline(.93, color=p["cobalt"], ls=(0, (4, 3)), lw=1)
    lab(ax, .02, .932, "R² = 0.93 benchmark", transform=ax.get_yaxis_transform(), va="bottom", color=p["cobalt"]); j = int(np.argmin(np.abs(ws - W2)))
    ax.scatter([rk[j]], [r2[j]], s=120, color=p["gold"], edgecolor=p["graphite"], lw=1, zorder=5, label=f"selected on validation (w = {W2:g})")
    for k in (0, 10, 20, 30, 40): lab(ax, rk[k] - .015, r2[k] - .003, f"w = {ws[k]:.2f}", ha="right", va="top", fontsize=6.8)
    ax.set(xlabel="Seismic sensitivity relative to Bishop", ylabel="R² on test slopes", title="(b) Accuracy vs mechanics consistency", xlim=(0, 1.08)); ax.legend(loc="lower left", fontsize=7)
    save("Fig10_mechanics_consistency_and_pareto")

@fig("Fig11")
def _():
    p = PAL["comp"]; t = pd.read_csv(R + "MASTER_FINAL_leakage_free_comparison.csv", index_col=0); r10 = pd.read_csv(RV_ + "R10_sota_tabular_baselines.csv")
    drop = ["LSTM", "GRU", "LSTM-GRU-DNN", "M3 CNN-Transformer-LSTM-MHA", "M4 CNN-LSTM-SE-Attention", "N1 PLE-ResNet-Attention", "DNN-embedding-XGBoost", "Hybrid Stacked (ML+DL)", "M5 DNN-XGBoost/LightGBM Stacking"]
    t = t[~t.index.isin(drop)][["RMSE", "RMSE_CI_low", "RMSE_CI_high"]]
    for _, r in r10.iterrows(): t.loc["[sota] " + r.model] = [r.test_RMSE, np.nan, np.nan]
    t = t.sort_values("RMSE").iloc[::-1]
    def short(i):
        if i.startswith("FINAL FRAMEWORK +"): return "Framework + monotone envelope"
        if i.startswith("FINAL FRAMEWORK"): return "Proposed framework (data branch)"
        return i.replace("[literature] ", "").replace("[sota] ", "").replace(" (20k train subset)", "").replace("Gated Mixture of Deep & Boosted Experts", "Gated Mixture of Experts")[:40]
    col = [p["amber"] if i.startswith("FINAL") else (p["teal"] if i.startswith(("[literature]", "[sota]")) else p["slate"]) for i in t.index]
    f = plt.figure(figsize=(12, 5.6)); gs = f.add_gridspec(2, 2, width_ratios=[1.25, 1]); ax = f.add_subplot(gs[:, 0]); y = np.arange(len(t))
    ax.barh(y, t.RMSE, color=col, height=.66); lo, hi = (t.RMSE - t.RMSE_CI_low).fillna(0).clip(lower=0), (t.RMSE_CI_high - t.RMSE).fillna(0).clip(lower=0)
    ax.errorbar(t.RMSE, y, xerr=[lo, hi], fmt="none", ecolor=INK2, lw=.7, capsize=1.5)
    for i, v in enumerate(t.RMSE): lab(ax, v + hi.iloc[i] + .0004, i, f"{v:.4f}", va="center", fontsize=6.8)
    ax.set_yticks(y, [short(i) for i in t.index], fontsize=7.3); ax.grid(axis="y", visible=False); ax.set_xlim(0, t.RMSE.max() * 1.42)
    ax.legend(handles=[Patch(color=p["amber"], label="proposed (data branch)"), Patch(color=p["slate"], label="expert models"), Patch(color=p["teal"], label="literature / state-of-the-art baselines")], loc="upper right", fontsize=7)
    ax.set(xlabel="Test RMSE of FoS, 18,000 slopes (95 % CI)", title="(a) Model comparison (main-text tiers)")
    a = pd.read_csv(R + "framework_results/T3_best_per_k_validation.csv"); b = pd.read_csv(R + "realworld_combinations/T8_accuracy_by_k_LightGBM_layer.csv")
    ax = f.add_subplot(gs[0, 1]); ax.plot(a.k, a.average, "-o", color=p["slate"], ms=3.5, label="best simple average"); ax.plot(a.k, a.stacking, "-s", color=p["amber"], ms=3.5, label="best stacking")
    ax.set(ylabel="Validation RMSE", title="(b) Progressive search, 120,000 slopes"); ax.legend(fontsize=7); ax.set_xticks(range(3, 21, 2))
    ax = f.add_subplot(gs[1, 1]); ax.fill_between(b.k, b.worst_acc * 100, b.best_acc * 100, color=p["teal"], alpha=.18, lw=0, label="range over combinations")
    ax.plot(b.k, b.median_acc * 100, "-o", color=p["teal"], ms=3.5, label="median combination")
    ax.set(xlabel="Number of experts combined (k)", ylabel="Real-slope accuracy (%)", title="(c) Progressive search, 363 real slopes", ylim=(75, 96)); ax.legend(fontsize=7, loc="lower left"); ax.set_xticks(range(3, 21, 2))
    save("Fig11_model_comparison_and_progressive_search")

@fig("Fig12")
def _():
    p = PAL["cov"]; t = pd.read_csv(P_ + "P3_final_model_mondrian_conformal.csv"); f5 = pd.read_csv(F_ + "F5_final_model_v1_vs_v2_test.csv").iloc[1]
    f, axs = plt.subplots(1, 2, figsize=(10.6, 4.1), gridspec_kw=dict(width_ratios=[1.3, 1])); ax = axs[0]; u = t[t.level == "90%"]; y = np.arange(len(u))
    ax.hlines(y, np.minimum(u.coverage_global, u.coverage_mondrian) * 100, np.maximum(u.coverage_global, u.coverage_mondrian) * 100, color=AXC, lw=1.2)
    ax.scatter(u.coverage_global * 100, y, s=42, color=p["sage"], zorder=3, label="one global interval"); ax.scatter(u.coverage_mondrian * 100, y, s=50, color=p["cobalt"], zorder=4, label="interval per regime / family")
    ax.axvline(90, color=p["copper"], ls=(0, (4, 3)), lw=1); lab(ax, 90.15, -.75, "nominal 90 %", color=p["copper"])
    ax.set_yticks(y, u.group); ax.set_ylim(len(u) - .5, -1.1); ax.grid(axis="y", visible=False); ax.set_xlim(82, 95); ax.legend(loc="upper center", bbox_to_anchor=(.5, -.15), ncol=2, fontsize=7)
    ax.set(xlabel="Coverage on test slopes (%)", title="(a) Final-model interval coverage")
    ax = axs[1]; x = np.arange(2); conf = [f5.confident_pct_90, f5.confident_pct_95]; acc = [f5.confident_accuracy_90, f5.confident_accuracy_95]
    ax.bar(x, conf, .55, color=p["cobalt"], label="confident class verdict"); ax.bar(x, [100 - c for c in conf], .55, bottom=conf, color="#E4E9DF", label="interval spans a class boundary")
    for i in x: lab(ax, i, conf[i] / 2, f"{conf[i]:.1f} %\n{acc[i]*100:.1f} % correct", ha="center", va="center", color="white", fontsize=7.4)
    ax.set_xticks(x, ["90 % interval", "95 % interval"]); ax.grid(axis="x", visible=False); ax.set(ylim=(0, 100), ylabel="Share of test slopes (%)", title="(b) Confident verdicts")
    ax.legend(loc="upper center", bbox_to_anchor=(.5, -.12), fontsize=7); save("Fig12_conformal_coverage")

@fig("Fig13")
def _():
    p = PAL["cal"]; r = pd.read_csv(P_ + "P2b_reliability_after_recalibration.csv"); s = pd.read_csv(P_ + "P2_realworld_recalibration.csv", header=[0, 1], index_col=0)
    f, axs = plt.subplots(1, 2, figsize=(10.2, 4.1), gridspec_kw=dict(width_ratios=[1.2, 1])); ax = axs[0]; ax.plot([0, 1], [0, 1], ls=(0, (4, 3)), color=INK2, lw=.9)
    for m, c, mk in (("uncalibrated", p["olive"], "o"), ("Platt (grouped CV)", p["blue"], "s")):
        e = r[r.method == m]; ax.plot(e.mean_predicted, e.observed, "-", marker=mk, color=c, ms=4.5, label=m)
    ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="Predicted P(failure)", ylabel="Observed failure rate", title="(a) Reliability diagram, 363 real slopes"); ax.legend(loc="upper left", fontsize=7)
    ax = axs[1]; ms = ["uncalibrated", "isotonic (grouped CV)", "Platt (grouped CV)"]; x = np.arange(3); e = [s.loc[m, ("ECE", "mean")] for m in ms]; sd = [s.loc[m, ("ECE", "std")] for m in ms]
    ax.bar(x, e, .55, yerr=sd, color=[p["olive"], p["terra"], p["blue"]], ecolor=INK2, capsize=2)
    for i, m in enumerate(ms): lab(ax, i, e[i] + sd[i] + .003, f"ECE {e[i]:.3f}\nBrier {s.loc[m, ('Brier', 'mean')]:.3f}", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(x, ["none", "isotonic", "Platt"]); ax.grid(axis="x", visible=False); ax.set(ylabel="Expected calibration error", title="(b) Recalibration inside grouped CV", ylim=(0, .12))
    save("Fig13_realworld_calibration")

@fig("Fig14")
def _():
    p = PAL["rem"]; t = pd.read_csv(RV_ + "R7_counterfactual_remediation.csv"); v = pd.read_csv(RV_ + "R7b_remediation_verified_with_Bishop.csv", index_col=0).iloc[:, 0]
    f, axs = plt.subplots(1, 2, figsize=(10.6, 3.9), sharey=True)
    for ax, tg in zip(axs, (1.3, 1.5)):
        e = t[(t.target_FoS == tg) & (t.kh_band != "all")]; x = np.arange(len(e)); w = .26
        for dx, c_, c, nm in ((-w, "pct_fixable_by_drainage_alone", p["emerald"], "drainage alone"), (0, "pct_fixable_by_regrading_alone", p["slate"], "regrading alone"), (w, "pct_needing_both_or_structural", p["sand"], "both or structural")):
            ax.bar(x + dx, e[c_], w, color=c, label=nm)
            for i, val in enumerate(e[c_]): lab(ax, i + dx, val + 1, f"{val:.0f}", ha="center", fontsize=6.8)
        ax.set_xticks(x, e.kh_band.str.replace("kh", "kₕ")); ax.grid(axis="x", visible=False); ax.set(title=f"({'a' if tg == 1.3 else 'b'}) Target FoS {tg}", ylim=(0, 100))
    axs[0].set_ylabel("Slopes below target (%)"); axs[0].legend(loc="upper right", fontsize=7)
    lab(axs[1], .98, .97, f"designs checked with direct Bishop:\nmedian FoS {v.median_Bishop_FoS_at_design:.2f}, {v.pct_Bishop_ge_1_25:.0f} % ≥ 1.25", transform=axs[1].transAxes, ha="right", va="top", color=INK)
    save("Fig14_counterfactual_remediation")

json.dump(dict(figures=done, failed=failed, palettes=PAL), open(OUT + "figure_list.json", "w"), indent=1); print("done", len(done), "failed", failed)
