"""M4 mechanics-consistency audit (reviewer R2): do the models' SENSITIVITIES match slope mechanics?
For 300 Kaggle test slopes, central-difference log-sensitivities d ln(FoS)/dx for x in {c, phi, beta, H, gamma, r_u, kh} are
computed with (i) pseudo-static Bishop LEM, (ii) the final framework, (iii) the framework + monotone envelope, and (iv) the
MVB-trained physics-guided surrogate. Log-sensitivities are scale-free, so the Kaggle FoS offset (about 0.59 x Bishop) cancels.
Run after msh_monotone.py and msh_mechanics.py."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_monotone as MO
import msh_mechanics as ME
FW, U = MO.FW, MO.FW.U
from scipy.stats import spearmanr
OUT = ME.OUT; T0 = time.time()
def say(*a): print(f"[MA {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
S = U.TS["A"].sample(300, random_state=11).reset_index(drop=True)
MAP = {"c": "Cohesion_kPa", "phi": "FrictionAngle_deg", "beta": "SlopeAngle_deg", "H": "SlopeHeight_m", "gamma": "UnitWeight_kN_m3", "ru": "PorePressureRatio", "kh": "SeismicCoefficient"}
STEP = {"c": 3., "phi": 1.5, "beta": 2., "H": 2., "gamma": .5, "ru": .03, "kh": .02}
LOK = {k: U.LO_[v] for k, v in MAP.items()}; HIK = {k: U.HI_[v] for k, v in MAP.items()}
def shifted(k, sgn):
    D = S.copy(); D[MAP[k]] = np.clip(D[MAP[k]] + sgn * STEP[k], LOK[k], HIK[k]); return FW.recompute(D)
def mech(D): return np.c_[D.SlopeHeight_m, D.SlopeAngle_deg, D.Cohesion_kPa, D.FrictionAngle_deg, D.UnitWeight_kN_m3, D.PorePressureRatio, D.SeismicCoefficient]
def mvb(D): return ME.pred(ME.BEST, ME.feats(pd.DataFrame(mech(D), columns=ME.COLS)))
MODELS = {"Bishop-PS LEM": lambda D, tag: ME.bishop_many(mech(D), "m4_" + tag), "Final framework": lambda D, tag: MO.fw(D),
          "Final framework + monotone envelope": lambda D, tag: MO.envelope(D), "MVB best surrogate (MLP)": lambda D, tag: mvb(D)}
SENS = {}
for mn, f in MODELS.items():
    f_ = f"{ME.CK}m4_sens_{''.join(ch for ch in mn if ch.isalnum())}.joblib"
    if os.path.exists(f_): SENS[mn] = joblib.load(f_); continue
    out = {}
    for k in MAP:
        Dp, Dm = shifted(k, 1), shifted(k, -1); dx = Dp[MAP[k]].values - Dm[MAP[k]].values
        fp, fm = np.clip(f(Dp, k + "p"), .05, 50), np.clip(f(Dm, k + "m"), .05, 50)
        out[k] = np.where(dx > 0, (np.log(fp) - np.log(fm)) / np.where(dx > 0, dx, 1), np.nan)
    SENS[mn] = out; joblib.dump(out, f_); say("sensitivities done:", mn)
EXPECT = {"c": 1, "phi": 1, "beta": -1, "H": -1, "gamma": -1, "ru": -1, "kh": -1}
rows = []
for mn in MODELS:
    if mn == "Bishop-PS LEM": continue
    for k in MAP:
        b, m = SENS["Bishop-PS LEM"][k], SENS[mn][k]; ok = np.isfinite(b) & np.isfinite(m)
        rows.append(dict(model=mn, variable=k, sign_agreement_with_Bishop_pct=np.mean(np.sign(b[ok]) == np.sign(m[ok])) * 100,
                         spearman_with_Bishop=spearmanr(b[ok], m[ok])[0], median_sensitivity_model=np.median(m[ok]), median_sensitivity_Bishop=np.median(b[ok]),
                         ratio_of_medians=np.median(m[ok]) / np.median(b[ok]) if abs(np.median(b[ok])) > 1e-9 else np.nan))
A = pd.DataFrame(rows); A.round(4).to_csv(OUT + "M4_mechanics_consistency_audit.csv", index=False)
say("\n" + A.pivot(index="variable", columns="model", values="spearman_with_Bishop").round(3).to_string())
say("\n" + A.pivot(index="variable", columns="model", values="ratio_of_medians").round(3).to_string()); say("DONE")
