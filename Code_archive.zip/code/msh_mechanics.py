"""
Mechanics extension (reviewer comments R1-R5). All Bishop work is cached in chunks, so the script resumes after interruption.
 M1  verification of the pseudo-static Bishop solver against independent Morgenstern-Price solutions (kv = 0)
 M2  Mechanics-Verified Benchmark (MVB): Latin-hypercube slopes, continuous (no scenario gaps), FoS from Bishop-PS
 M3  surrogates on MVB: XGBoost, LightGBM, MLP, physics-guided monotone LightGBM, physics-residual XGBoost (learns
     log(FoS / analytical pseudo-static infinite-slope FS)) + physics-consistency of each
 M5  surrogate-accelerated reliability: Monte Carlo P_f and beta under static / rainfall (r_u) / seismic / compound loading,
     direct Bishop MC vs surrogate MC, with speed-up
 M6  rainfall (r_u) x seismic interaction from mechanics on the gap-free benchmark, and its reproduction by the surrogate
 M7  real case histories: Bishop and the MVB surrogate zero-shot, and as features in grouped CV
"""
import os, sys, time, json, warnings
import numpy as np, pandas as pd, joblib
from joblib import Parallel, delayed
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from bishop_ps import bishop_ps
import lightgbm as lgb, xgboost as xgb
from scipy.stats import norm, qmc, spearmanr
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, StratifiedGroupKFold
from sklearn.metrics import r2_score, mean_squared_error, accuracy_score, roc_auc_score, f1_score
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/mechanics_results/"; os.makedirs(OUT + "figures", exist_ok=True)
CK = os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work") + "/mech/"; os.makedirs(CK, exist_ok=True)
RS = 42; T0 = time.time(); NJ = max(1, (os.cpu_count() or 2))
def say(*a): print(f"[ME {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    say("computing", name); r = fn(); joblib.dump(r, f); return r
def bishop_many(P, tag, chunk=500):
    """P: array (n, 7) of [H, beta, c, phi, gamma, ru, kh]; chunk-cached parallel Bishop evaluation."""
    out = []
    for k in range(0, len(P), chunk):
        f = CK + f"{tag}_{k}.npy"
        if os.path.exists(f): out.append(np.load(f)); continue
        r = np.array(Parallel(n_jobs=NJ)(delayed(bishop_ps)(*row) for row in P[k:k + chunk])); np.save(f, r); out.append(r)
        say(f"  {tag}: {min(k + chunk, len(P))}/{len(P)}")
    return np.concatenate(out) if out else np.array([])
def cls(f): return np.where(f < 1, 0, np.where(f < 1.3, 1, 2))
COLS = ["H", "beta", "c", "phi", "gamma", "ru", "kh"]

# ---------------------------------------------------------------- M1 verification against Morgenstern-Price
say("M1 verification vs Morgenstern-Price")
mp = pd.read_csv(ROOT + "/real_validation_data/4_pseudostatic_morgenstern_price_19128.csv")
mv = mp[(mp.kvr == 0) & (mp.fmp > 0)].sample(2000, random_state=RS).reset_index(drop=True)
Pm = np.c_[np.full(len(mv), 10.), mv["Slope Angle"], mv.CbygammaH * 20 * 10, mv.phi, np.full(len(mv), 20.), np.zeros(len(mv)), mv.kh]
fb = bishop_many(Pm, "m1")
e = fb / mv.fmp.values; okm = mv.fmp.values >= .3          # ratio metrics only where FoS is not near zero
V = dict(n=len(mv), pearson_r=float(np.corrcoef(fb, mv.fmp)[0, 1]), R2_vs_MP=float(r2_score(mv.fmp, fb)), median_ratio_Bishop_over_MP=float(np.median(e)),
         MAPE_pct_FoS_ge_0_3=float(np.mean(np.abs(e[okm] - 1)) * 100), within_5pct=float(np.mean(np.abs(e[okm] - 1) < .05) * 100), within_10pct=float(np.mean(np.abs(e[okm] - 1) < .10) * 100), n_ratio_metrics=int(okm.sum()), RMSE_FoS=float(mean_squared_error(mv.fmp, fb) ** .5),
         class_agreement_FoS_lt_1=float(np.mean((fb < 1) == (mv.fmp.values < 1)) * 100))
vk = pd.DataFrame(dict(kh=mv.kh.round(2), r=e))[okm].groupby("kh").r.agg(["median", lambda s: np.mean(np.abs(s - 1)) * 100]).rename(columns={"<lambda_0>": "MAPE_pct_FoS_ge_0_3"})
pd.DataFrame(dict(slope_angle=mv["Slope Angle"], c_over_gammaH=mv.CbygammaH, phi=mv.phi, kh=mv.kh, FoS_MorgensternPrice=mv.fmp, FoS_Bishop_PS=fb)).round(5).to_csv(OUT + "M1c_verification_points.csv", index=False)
pd.Series(V).round(4).to_csv(OUT + "M1_solver_verification_vs_MP.csv"); vk.round(4).to_csv(OUT + "M1b_verification_by_kh.csv"); say(V)
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
C1, C2, C3, INK2, GRID = "#2a78d6", "#eb6834", "#1baf7a", "#52514e", "#e1e0d9"
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "font.size": 9})
fig, ax = plt.subplots(figsize=(4.6, 4.4)); ax.scatter(mv.fmp, fb, s=6, alpha=.5, color=C1, edgecolor="none"); m_ = max(mv.fmp.max(), fb.max())
ax.plot([0, m_], [0, m_], "--", color=INK2, lw=1); ax.set(xlabel="Morgenstern-Price FoS (Waris et al. 2024)", ylabel="Pseudo-static Bishop FoS (this study)",
                                                       title=f"Solver verification, n={len(mv)}: r={V['pearson_r']:.3f}")
plt.tight_layout(); plt.savefig(OUT + "figures/M1_verification.png", dpi=300); plt.close()

# ---------------------------------------------------------------- M2 mechanics-verified benchmark
say("M2 mechanics-verified benchmark")
N = int(os.environ.get("MVB_N", 20000))
LO = np.array([5, 15, 5, 15, 16, 0, 0]); HI = np.array([50, 65, 120, 45, 24, .6, .3])
S = qmc.LatinHypercube(d=7, seed=RS).random(N); P = LO + S * (HI - LO)
F = bishop_many(P, "mvb")
D = pd.DataFrame(P, columns=COLS); D["FoS_raw"] = F; D["FoS"] = np.clip(F, .25, 5)
def feats(d):
    b, p = np.radians(d.beta), np.radians(d.phi); N_ = d.c / (d.gamma * d.H)
    num = N_ / (np.cos(b) ** 2) + (1 - d.ru / np.cos(b) ** 2 - d.kh * np.tan(b)) * np.tan(p); den = np.tan(b) + d.kh
    FSi = np.clip(num / den, .02, 50)                                            # analytical pseudo-static infinite-slope prior (z = H)
    return pd.DataFrame(dict(H=d.H, beta=d.beta, c=d.c, phi=d.phi, gamma=d.gamma, ru=d.ru, kh=d.kh, N=N_, Fr=np.tan(p) / np.tan(b), FSinf_ps=FSi))
X = feats(D); y = D.FoS.values
i_tr, i_te = train_test_split(np.arange(N), test_size=.15, random_state=RS); i_tr, i_va = train_test_split(i_tr, test_size=.15 / .85, random_state=RS)
D["split"] = "train"; D.loc[i_va, "split"] = "val"; D.loc[i_te, "split"] = "test"; D.round(5).to_csv(OUT + "M2_mechanics_verified_benchmark.csv", index=False)
say(f"MVB: {N} slopes; FoS<1 {np.mean(F<1)*100:.1f}%, 1-1.3 {np.mean((F>=1)&(F<1.3))*100:.1f}%, >=1.3 {np.mean(F>=1.3)*100:.1f}%")

# ---------------------------------------------------------------- M3 surrogates
say("M3 surrogates on MVB")
Xtr, Xva, Xte, ytr, yva, yte = X.iloc[i_tr], X.iloc[i_va], X.iloc[i_te], y[i_tr], y[i_va], y[i_te]
MONO = [-1, -1, 1, 1, 0, -1, -1, 1, 1, 1]
def fit_all():
    M = {}
    M["XGBoost"] = xgb.XGBRegressor(n_estimators=4000, learning_rate=.04, max_depth=7, subsample=.8, colsample_bytree=.8, early_stopping_rounds=150,
                                    tree_method="hist", random_state=RS).fit(Xtr, ytr, eval_set=[(Xva, yva)], verbose=False)
    M["LightGBM"] = lgb.LGBMRegressor(n_estimators=5000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1,
                                      random_state=RS).fit(Xtr, ytr, eval_set=[(Xva, yva)], callbacks=[lgb.early_stopping(150, verbose=False)])
    M["Physics-guided monotone LightGBM"] = lgb.LGBMRegressor(n_estimators=5000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8,
                                      monotone_constraints=MONO, verbose=-1, random_state=RS).fit(Xtr, ytr, eval_set=[(Xva, yva)], callbacks=[lgb.early_stopping(150, verbose=False)])
    lr = lambda d, f: np.log(np.clip(f, .25, 5)) - np.log(d.FSinf_ps.values)
    M["Physics-residual XGBoost (learns FoS / FS_inf,ps)"] = xgb.XGBRegressor(n_estimators=4000, learning_rate=.04, max_depth=7, subsample=.8, colsample_bytree=.8,
                                    early_stopping_rounds=150, tree_method="hist", random_state=RS).fit(Xtr, lr(Xtr, ytr), eval_set=[(Xva, lr(Xva, yva))], verbose=False)
    sc = StandardScaler().fit(Xtr); M["MLP"] = (sc, MLPRegressor(hidden_layer_sizes=(256, 128, 64), early_stopping=True, max_iter=300, random_state=RS).fit(sc.transform(Xtr), ytr))
    return M
MOD = cached("m3_models", fit_all)
def pred(n, Xd):
    m = MOD[n]
    if n == "MLP": return m[1].predict(m[0].transform(Xd))
    if n.startswith("Physics-residual"): return np.exp(m.predict(Xd) + np.log(Xd.FSinf_ps.values))
    return m.predict(Xd)
def physics_viol(n, base):
    out = {}
    for c_, st, sgn in (("ru", .05, -1), ("kh", .03, -1), ("beta", 3, -1), ("H", 3, -1), ("c", 5, 1), ("phi", 2, 1)):
        Dp = base.copy(); Dp[c_] = Dp[c_] + st; d = pred(n, feats(Dp)) - pred(n, feats(base)); out[f"viol_{c_}"] = float(np.mean(sgn * d < -1e-3) * 100)
    out["mean_violation_pct"] = float(np.mean(list(out.values()))); return out
rows = {}; Bte = D.iloc[i_te][COLS].sample(2000, random_state=1)
for n in MOD:
    t = time.time(); p = np.clip(pred(n, Xte), .25, 5); ms = (time.time() - t) / len(Xte) * 1000
    rows[n] = dict(R2=r2_score(yte, p), RMSE=mean_squared_error(yte, p) ** .5, MAPE_pct=np.mean(np.abs(p / yte - 1)) * 100, Accuracy_3class=accuracy_score(cls(yte), cls(p)),
                   F1_Marginal=f1_score(cls(yte) == 1, cls(p) == 1), ms_per_slope=ms, **physics_viol(n, Bte))
ps = np.clip(Xte.FSinf_ps.values, .25, 5); rows["Analytical pseudo-static infinite slope (no learning)"] = dict(R2=r2_score(yte, ps), RMSE=mean_squared_error(yte, ps) ** .5,
     MAPE_pct=np.mean(np.abs(ps / yte - 1)) * 100, Accuracy_3class=accuracy_score(cls(yte), cls(ps)), F1_Marginal=f1_score(cls(yte) == 1, cls(ps) == 1))
lem_ms = float(np.mean([(lambda t0: (bishop_ps(*Bte.iloc[i].values), time.time() - t0)[1])(time.time()) for i in range(30)]) * 1000)
rows["Bishop-PS LEM (reference)"] = dict(ms_per_slope=lem_ms)
R3 = pd.DataFrame(rows).T; R3.round(5).to_csv(OUT + "M3_surrogates_on_MVB.csv"); say("\n" + R3.round(4).to_string())
BEST = R3.drop(index=["Analytical pseudo-static infinite slope (no learning)", "Bishop-PS LEM (reference)"]).RMSE.idxmin(); say("best surrogate:", BEST)
PG = "Physics-guided monotone LightGBM"

# ---------------------------------------------------------------- M5 reliability
say("M5 reliability analysis")
REF = dict(H=12., beta=35., c=18., phi=26., gamma=19.)
CASES = {"static": (0., 0.), "rainfall (r_u = 0.3)": (.3, 0.), "seismic (kh = 0.15)": (0., .15), "compound (r_u = 0.3, kh = 0.15)": (.3, .15)}
def samples(n, seed):
    r = np.random.default_rng(seed); z = r.multivariate_normal([0, 0], [[1, -.5], [-.5, 1]], n)
    cv_c, cv_p = .3, .1; s_ln = np.sqrt(np.log(1 + cv_c ** 2)); mu_ln = np.log(REF["c"]) - s_ln ** 2 / 2
    c_ = np.exp(mu_ln + s_ln * z[:, 0]); p_ = np.clip(REF["phi"] * (1 + cv_p * z[:, 1]), 5, 50); return c_, p_
NMC = int(os.environ.get("MC_N", 2000))
rel = {}
for k, (ru, kh) in CASES.items():
    c_, p_ = samples(NMC, 7); Pc = np.c_[np.full(NMC, REF["H"]), np.full(NMC, REF["beta"]), c_, p_, np.full(NMC, REF["gamma"]), np.full(NMC, ru), np.full(NMC, kh)]
    t = time.time(); fb_ = bishop_many(Pc, "m5_" + k.split()[0]); tb = time.time() - t
    Dc = pd.DataFrame(Pc, columns=COLS); out = dict(mean_FoS_deterministic=bishop_ps(REF["H"], REF["beta"], REF["c"], REF["phi"], REF["gamma"], ru, kh))
    pf = np.mean(fb_ < 1); se = np.sqrt(max(pf * (1 - pf), 1 / NMC) / NMC)
    out.update(Pf_Bishop_MC=pf, Pf_Bishop_CI95=f"[{max(pf-1.96*se,0):.4f}, {pf+1.96*se:.4f}]", beta_Bishop=-norm.ppf(pf) if 0 < pf < 1 else np.nan)
    for n in (BEST, PG):
        ps_ = pred(n, feats(Dc)); out[f"Pf_{n}_same_samples"] = float(np.mean(ps_ < 1)); out[f"agreement_{n}"] = float(np.mean((ps_ < 1) == (fb_ < 1)) * 100)
    cb, pb = samples(1_000_000, 11); Db = pd.DataFrame(dict(H=REF["H"], beta=REF["beta"], c=cb, phi=pb, gamma=REF["gamma"], ru=ru, kh=kh))
    for n in (BEST, PG):
        t = time.time(); pbig = pred(n, feats(Db)); ts = time.time() - t; pf2 = float(np.mean(pbig < 1))
        out.update({f"Pf_{n}_1e6": pf2, f"beta_{n}_1e6": -norm.ppf(pf2) if 0 < pf2 < 1 else np.nan, f"speedup_{n}": (lem_ms / 1000) / (ts / 1e6)})
    rel[k] = out; say(k, {a: (round(b, 4) if isinstance(b, float) else b) for a, b in out.items()})
R5 = pd.DataFrame(rel).T; R5.to_csv(OUT + "M5_reliability_compound_hazard.csv")

# ---------------------------------------------------------------- M6 interaction from mechanics
say("M6 r_u x kh interaction from mechanics")
RU, KH = np.round(np.arange(0, .61, .1), 2), np.round(np.arange(0, .31, .05), 2)
REFS = {"gentle 25 deg, strong soil": dict(H=12, beta=25, c=30, phi=32, gamma=19), "typical 35 deg": dict(H=12, beta=35, c=18, phi=26, gamma=19),
        "steep 50 deg, weak soil": dict(H=12, beta=50, c=25, phi=22, gamma=19)}
grid_rows = []
for nm, r_ in REFS.items():
    Pg = np.array([[r_["H"], r_["beta"], r_["c"], r_["phi"], r_["gamma"], a, b] for a in RU for b in KH]); fg = bishop_many(Pg, "m6_" + nm.split()[0])
    sg = pred(BEST, feats(pd.DataFrame(Pg, columns=COLS)))
    for (a, b), f_, s_ in zip(Pg[:, 5:7], fg, sg): grid_rows.append(dict(slope=nm, ru=a, kh=b, FoS_Bishop=f_, FoS_surrogate=s_))
G6 = pd.DataFrame(grid_rows)
def inter(g, col):
    f = g.set_index(["ru", "kh"])[col]; f00 = f.loc[(0., 0.)]
    return g.apply(lambda r: f.loc[(r.ru, r.kh)] * f00 / (f.loc[(r.ru, 0.)] * f.loc[(0., r.kh)]), axis=1)
G6["I_Bishop"] = G6.groupby("slope", group_keys=False).apply(lambda g: inter(g, "FoS_Bishop")); G6["I_surrogate"] = G6.groupby("slope", group_keys=False).apply(lambda g: inter(g, "FoS_surrogate"))
G6.round(4).to_csv(OUT + "M6_ru_kh_interaction_grid.csv", index=False)
def pop():
    B = D.iloc[i_te][COLS].sample(400, random_state=3).reset_index(drop=True); B["ru"] = np.minimum(B.ru, .35); B["kh"] = np.minimum(B.kh, .15)
    sets = {"base": B, "R": B.assign(ru=B.ru + .2), "E": B.assign(kh=B.kh + .1), "RE": B.assign(ru=B.ru + .2, kh=B.kh + .1)}
    Fb = {k: bishop_many(v[COLS].values, "m6pop_" + k) for k, v in sets.items()}; Fs = {k: pred(BEST, feats(v)) for k, v in sets.items()}
    return Fb, Fs
Fb, Fs = cached("m6_pop", pop)
Ib = Fb["RE"] * Fb["base"] / (Fb["R"] * Fb["E"]); Is = Fs["RE"] * Fs["base"] / (Fs["R"] * Fs["E"])
M6s = dict(median_I_Bishop=float(np.median(Ib)), pct_synergistic_Bishop=float(np.mean(Ib < 1 - 1e-3) * 100), pct_antagonistic_Bishop=float(np.mean(Ib > 1 + 1e-3) * 100),
           median_I_surrogate=float(np.median(Is)), pct_synergistic_surrogate=float(np.mean(Is < 1 - 1e-3) * 100), spearman_I=float(spearmanr(Ib, Is)[0]),
           median_drop_rain_pct=float(np.median(1 - Fb["R"] / Fb["base"]) * 100), median_drop_eq_pct=float(np.median(1 - Fb["E"] / Fb["base"]) * 100),
           median_drop_both_pct=float(np.median(1 - Fb["RE"] / Fb["base"]) * 100))
pd.Series(M6s).round(4).to_csv(OUT + "M6b_population_interaction.csv"); say(M6s)
fig, axs = plt.subplots(1, 3, figsize=(12, 3.6), sharey=True)
for ax, (nm, g) in zip(axs, G6.groupby("slope", sort=False)):
    for j, (kh, gg) in enumerate(g.groupby("kh")):
        if kh in (0, .1, .2, .3):
            col = {0: C1, .1: C2, .2: C3, .3: "#4a3aa7"}[kh]; ax.plot(gg.ru, gg.FoS_Bishop, "-o", color=col, ms=3, lw=1.8, label=f"kh={kh:g} (Bishop)")
            ax.plot(gg.ru, gg.FoS_surrogate, "--", color=col, lw=1)
    ax.axhline(1, color=INK2, lw=.8); ax.set(xlabel="pore-pressure ratio r_u (rainfall)", title=nm)
axs[0].set_ylabel("FoS (solid: Bishop-PS; dashed: surrogate)"); axs[-1].legend(fontsize=7); plt.tight_layout(); plt.savefig(OUT + "figures/M6_ru_kh_interaction.png", dpi=300); plt.close()

# ---------------------------------------------------------------- M7 real case histories
say("M7 real case histories")
R = ROOT + "/real_validation_data/"; c1 = pd.read_csv(R + "1_circular_case_histories_184.csv"); c2 = pd.read_csv(R + "2_compiled_case_histories_361.csv")
F6 = ["H", "beta", "gamma", "c", "phi", "ru"]
real = pd.concat([pd.DataFrame(dict(zip(F6, [c1.H_m, c1.beta_deg, c1.gamma_kN_m3, c1.c_kPa, c1.phi_deg, c1.r_u]), fail=(c1.stability == "Failure").astype(int))),
                  pd.DataFrame(dict(zip(F6, [c2["slope height (m)"], c2["Slope angle"], c2["unit weight(kN/m3)"], c2["Cohesion(kPa)"], c2["internal friction angle"],
                                             c2["pore pressure ratio"]]), fail=(c2.Status == "Failure").astype(int)))], ignore_index=True)
real[F6] = real[F6].round(2); real = real.drop_duplicates(subset=F6).query("H > 0 and gamma > 0").reset_index(drop=True); real["kh"] = 0.
kq = pd.DataFrame(dict(a=real.H.round(0), b=real.beta.round(0), c=(real.gamma * 2).round(), d=real.c.round(0), e=real.phi.round(0), f=(real.ru * 20).round()))
G = pd.factorize(kq.astype(str).agg("|".join, axis=1))[0]; yR = real.fail.values
fbR = bishop_many(real[COLS].values, "m7"); Xr = feats(real.assign(**{k: real[k].clip(LO[i], HI[i]) for i, k in enumerate(COLS)})); fsR = pred(BEST, Xr)
res7 = {"Bishop-PS LEM (no learning)": dict(AUROC=roc_auc_score(yR, -fbR), Accuracy=accuracy_score(yR, fbR < 1)),
        "MVB surrogate zero-shot (inputs clipped to MVB range)": dict(AUROC=roc_auc_score(yR, -fsR), Accuracy=accuracy_score(yR, fsR < 1))}
Xb = np.c_[real[F6].values, np.log(np.clip(fbR, .05, 50))]; X0 = real[F6].values
for nm, XX in (("Real data only (LightGBM, 6 properties)", X0), ("Real data + Bishop-PS FoS feature (LightGBM)", Xb)):
    acc, auc = [], []
    for r in range(5):
        pp = np.zeros(len(yR))
        for a, b in StratifiedGroupKFold(5, shuffle=True, random_state=r).split(XX, yR, G):
            pp[b] = lgb.LGBMClassifier(n_estimators=300, num_leaves=15, learning_rate=.05, subsample=.8, subsample_freq=1, colsample_bytree=.8, min_child_samples=10,
                                       verbose=-1, random_state=RS).fit(XX[a], yR[a]).predict_proba(XX[b])[:, 1]
        acc.append(accuracy_score(yR, pp > .5)); auc.append(roc_auc_score(yR, pp))
    res7[nm] = dict(AUROC=np.mean(auc), Accuracy=np.mean(acc), Accuracy_sd=np.std(acc))
R7 = pd.DataFrame(res7).T; R7.round(4).to_csv(OUT + "M7_real_case_histories_mechanics.csv"); say("\n" + R7.round(3).to_string())
json.dump(dict(verification=V, best_surrogate=BEST, interaction=M6s, minutes=round((time.time() - T0) / 60, 1)), open(OUT + "run_log.json", "w"), indent=2, default=str)
say("DONE")
