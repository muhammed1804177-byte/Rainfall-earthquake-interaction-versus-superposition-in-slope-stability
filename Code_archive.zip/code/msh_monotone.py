"""
Guaranteed physical monotonicity: FoS_mono(x) = min over (kh' <= kh, ru' <= ru) of FoS(x | kh', ru').
=> predicted FoS can never increase when seismic load or pore pressure increases. Final framework (5 seeds) is rebuilt
exactly as selected in msh_finalize.py and evaluated before/after the envelope. Test touched once; conformal re-calibrated.
"""
import os, json, time, warnings
import numpy as np, pandas as pd, joblib, torch
warnings.filterwarnings("ignore")
import msh_framework as FW
from sklearn.metrics import r2_score, accuracy_score, f1_score
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/final_results/"); CK = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptFinal/"); T0 = time.time()
__import__("os").makedirs(CK, exist_ok=True); __import__("os").makedirs(OUT + "figures", exist_ok=True)
def say(*a): print(f"[MON {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
U = FW.U; TS, CA = FW.TS, FW.CA; y_te = FW.y_te
sel = json.load(open(OUT + "run_log.json"))["selected"]; COLS = sel["members"]
KW = dict(mode="attention", residual=True) if "FULL" in sel["config"] else dict(mode="gate", residual=True)
MODELS = [FW.train_fusion(COLS, seed=s, EV=FW.EVcache(COLS), **KW) for s in range(5)]
def fw(A):
    LP = np.log(np.clip(np.column_stack([FW.FN[c](A) for c in COLS]), .2, 6)); H = FW.hstate(A)
    with torch.no_grad(): return np.mean([FW.fpred(m, H, LP)[0].numpy() for m in MODELS], 0)
KG, RG = np.round(np.arange(0, .301, .01), 3), np.round(np.arange(0, .61, .1), 3)
def envelope(A, f=fw, bs=3000):
    """min over fixed grid points (each clipped to the slope's own value) -> monotone non-increasing in kh and r_u."""
    out = []
    for k in range(0, len(A), bs):
        B = A.iloc[k:k + bs].reset_index(drop=True); n = len(B); reps = []
        kh, ru = B.SeismicCoefficient.values, B.PorePressureRatio.values
        for kg in KG:
            for rg in RG:
                C = B.copy(); C["SeismicCoefficient"] = np.minimum(kg, kh); C["PorePressureRatio"] = np.minimum(rg, ru); reps.append(FW.recompute(C))
        reps.append(B)
        P = f(pd.concat(reps, ignore_index=True)).reshape(-1, n); out.append(P.min(0))
    return np.concatenate(out)
def metrics(p):
    p = np.clip(p, .25, 5); a, b = U.to_class(y_te), U.to_class(p)
    return dict(R2=r2_score(y_te, p), RMSE=FW.rmse(y_te, p), Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1),
                RMSE_compound=FW.rmse(y_te[FW.REG_T == "compound"], p[FW.REG_T == "compound"]))
def physics(f):
    X = TS["A"].sample(1500, random_state=7).reset_index(drop=True); S = FW.perturbed_sets(X); P = {k: f(A) for k, A in S.items()}
    r = {f"viol_{c}": float(np.mean(sgn * (P[k] - P["base"]) < -1e-3) * 100) for k, (c, _, sgn) in FW.PERT.items()}
    I = P["RE"] * P["base"] / (P["R"] * P["E"]); r.update(antagonistic_pct=float(np.mean(I > 1 + 1e-3) * 100), interaction_median=float(np.median(I)))
    r["mean_violation_pct"] = float(np.mean([v for k, v in r.items() if k.startswith("viol_")])); return r
def conformal(pt, pc):
    e = np.abs(CA["lo"] - np.clip(pc, .25, 5)); rows = []
    for al in (.1, .05):
        q = np.quantile(e, min(1, np.ceil((len(e) + 1) * (1 - al)) / len(e))); lo, hi = pt - q, pt + q
        dec = np.where(hi < 1, 0, np.where(lo >= 1.3, 2, -1)); m = dec >= 0
        rows.append(dict(alpha=al, coverage=np.mean((y_te >= lo) & (y_te <= hi)), half_width=q, confident_pct=m.mean() * 100,
                         confident_accuracy=accuracy_score(U.to_class(y_te)[m], dec[m])))
    return rows
def piece(name, fn):
    f = CK + "mono_" + name + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    say("computing", name); r = fn(); joblib.dump(r, f); return r
pt0, pc0 = piece("pt0", lambda: fw(TS["A"])), piece("pc0", lambda: fw(CA["A"]))
t0 = time.time(); pt1 = piece("pt1", lambda: envelope(TS["A"])); tinf = piece("tinf", lambda: (time.time() - t0) / len(pt1) * 1000)
pc1 = piece("pc1", lambda: envelope(CA["A"]))
ph0 = piece("ph0", lambda: physics(fw)); ph1 = piece("ph1", lambda: physics(envelope))
R = dict(before=dict(**metrics(pt0), **ph0), after=dict(**metrics(pt1), **ph1), conf_before=conformal(pt0, pc0), conf_after=conformal(pt1, pc1), ms_per_slope=tinf)
T = pd.DataFrame({"Final framework": R["before"], "Final framework + monotone envelope (kh, r_u)": R["after"]}).T
T.round(5).to_csv(OUT + "T6_monotone_envelope.csv"); say("\n" + T.round(4).T.to_string())
C = pd.concat([pd.DataFrame(R["conf_before"]).assign(model="before"), pd.DataFrame(R["conf_after"]).assign(model="with envelope")])
C.round(4).to_csv(OUT + "T7_uncertainty_with_envelope.csv", index=False); say("\n" + C.round(4).to_string()); say("inference ms/slope:", round(R["ms_per_slope"], 3))
say("DONE")
