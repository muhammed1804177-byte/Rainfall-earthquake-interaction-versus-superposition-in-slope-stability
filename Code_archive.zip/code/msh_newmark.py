"""I7 Newmark-type permanent displacement under combined loading (reviewer item: pseudo-static FoS gives no displacement).
Yield coefficient k_y(r_u) of 3,000 held-out MVB slopes (verified Bishop surrogate, bisection on kh), then the empirical
Jibson (2007) sliding-block relation  log10 D[cm] = 0.215 + log10[(1 - k_y/a_max)^2.341 (k_y/a_max)^-1.438]  (sigma 0.51),
valid for 0 < k_y/a_max < 1. Hazard classes after Jibson & Michael (2009): <1 cm low, 1-5 moderate, 5-15 high, >15 very high.
Slopes failing statically (FoS < 1 at kh = 0) are counted separately."""
import os, sys
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_mechanics as ME
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/interaction_results/"
POP = ME.D.iloc[ME.i_te][ME.COLS].reset_index(drop=True)
f = lambda d: ME.pred(ME.BEST, ME.feats(d))
rows = []
for ru in (0., .1, .2, .3, .4):
    D0 = POP.assign(ru=ru); F0 = f(D0.assign(kh=0.)); lo, hi = np.zeros(len(D0)), np.full(len(D0), .3)
    for _ in range(22):
        mid = (lo + hi) / 2; ok = f(D0.assign(kh=mid)) >= 1; lo = np.where(ok, mid, lo); hi = np.where(ok, hi, mid)
    ky = np.where(F0 < 1, np.nan, lo); ky = np.where(f(D0.assign(kh=.3)) >= 1, .3, ky)   # >= 0.3 treated as 0.3 (conservative)
    for amax in (.2, .3, .4):
        r = ky / amax; D = np.where(np.isnan(ky), np.nan, np.where(r >= 1, 0., 10 ** (0.215 + np.log10(np.clip(1 - r, 1e-9, None) ** 2.341 * np.clip(r, 1e-6, None) ** -1.438))))
        st = ~np.isnan(ky)
        rows.append(dict(ru=ru, a_max_g=amax, pct_failing_static=np.mean(~st) * 100, median_D_cm_stable=np.nanmedian(D), pct_D_gt_5cm=np.mean(D[st] > 5) * 100, pct_D_gt_15cm=np.mean(D[st] > 15) * 100,
                         pct_high_or_failed=(np.mean(~st) + np.mean(np.where(st, D, 0) > 5)) * 100))
T = pd.DataFrame(rows); T.round(3).to_csv(OUT + "I7_Newmark_displacement_vs_ru.csv", index=False); print(T.round(2).to_string()); print("NM DONE")
