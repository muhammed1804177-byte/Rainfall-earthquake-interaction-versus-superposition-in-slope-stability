"""Deployable predictor of the final model (one call per table of slopes).
Returns for each slope:
  FoS_dataset      final model (framework x monotone mechanics-anchored branch, w chosen on validation), dataset FoS scale
  FoS_lo / FoS_hi  regime-conditional split-conformal interval (90 % by default), from the untouched calibration split
  FoS_mechanics    verified pseudo-static Bishop surrogate on the 7 mechanics inputs (use this scale for engineering statements)
  stability_class  0: FoS < 1, 1: 1-1.3, 2: >= 1.3 (dataset scale)
  verdict          'confident <class>' when the interval lies in one class, else 'investigate'
  in_domain        applicability-domain gate (family envelope + Mahalanobis 99 %); out-of-domain slopes are always 'investigate'
Usage:  import msh_predict as P;  out = P.predict(df)   # df with the Kaggle feature columns (see U.FEATS)"""
import os, sys
import numpy as np, pandas as pd, joblib
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_review as RV
U, MO, FW = RV.U, RV.MO, RV.FW
ROOT, WK = RV.ROOT, RV.WK
DM = joblib.load(WK + "/finalblend/d_mono.joblib")
W = float(pd.read_csv(ROOT + "/final_model_results/F5_final_model_v1_vs_v2_test.csv").w.iloc[1])
from msh_gate import Gate
GATE = Gate(U.A_sva.iloc[U.s_tr].reset_index(drop=True), ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "WeatheringIndex", "Rainfall_mm_day",
                                                         "GroundwaterRiseRate_m_day", "GroundwaterDepth_m", "PorePressureRatio", "SeismicCoefficient"])
_BR, _A2 = joblib.load(WK + "/finalblend/branches.joblib"), joblib.load(WK + "/finalblend/anch_v2.joblib")
_Aca = U.A_sva.iloc[U.s_ca].reset_index(drop=True); _yc = U.sva.FoS.values[U.s_ca]
_pc = np.clip(np.exp(W * np.log(_BR["calib"][0]) + (1 - W) * np.log(_A2["calib"])), .25, 5)
_rc, _Rc = np.abs(np.log(_yc) - np.log(_pc)), FW.regime(_Aca)
def _q(r, a): return np.quantile(r, min(1, np.ceil((len(r) + 1) * (1 - a)) / len(r)))
def predict(df, alpha=.10, envelope=False):
    X = U.recompute(df[U.FEATS].reset_index(drop=True))
    fa = np.clip(MO.fw(X), .05, 20); fd = np.clip(np.exp(RV.prior(X) + DM.predict(X[RV.ENV])), .05, 20)
    f = lambda Z: np.clip(np.exp(W * np.log(np.clip(MO.fw(Z), .05, 20)) + (1 - W) * (RV.prior(Z) + DM.predict(Z[RV.ENV]))), .25, 5)
    p = MO.envelope(X, f=f) if envelope else np.clip(np.exp(W * np.log(fa) + (1 - W) * np.log(fd)), .25, 5)
    reg = FW.regime(X); q = np.array([_q(_rc[_Rc == r], alpha) if (_Rc == r).sum() > 50 else _q(_rc, alpha) for r in reg])
    lo, hi = p * np.exp(-q), p * np.exp(q); ok = GATE.ok(X); c = U.to_class(p)
    names = np.array(["unstable (FoS < 1)", "marginal (1-1.3)", "stable (>= 1.3)"])
    verdict = np.where(ok & (U.to_class(lo) == U.to_class(hi)), np.char.add("confident ", names[c]), "investigate")
    return pd.DataFrame(dict(FoS_dataset=p, FoS_lo=lo, FoS_hi=hi, FoS_mechanics=RV.mech(X), stability_class=c, verdict=verdict, in_domain=ok, regime=reg))
if __name__ == "__main__":
    S = U.A_sva.iloc[U.s_te[:8]]; print(predict(S).round(3).to_string())
