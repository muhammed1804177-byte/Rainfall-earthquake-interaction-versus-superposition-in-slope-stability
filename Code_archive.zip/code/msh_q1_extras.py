"""
Reviewer-driven analyses on the FINAL framework (run after msh_monotone.py; all on available data, test touched once).
 Q1  dataset characterisation (synthetic-data indicators) for the methods section
 Q2  label-correction sensitivity: original vs physics-corrected FoS labels (SVA test, seismic response, real-world zero-shot)
 Q3  cluster-holdout split ("related observations" robustness) vs random split
 Q4  literature-style baselines on the same split (linear, kNN, SVR, MLP, Bishop-calibrated physics)
 Q5  SHAP + permutation importance of the final framework, incl. rainfall x seismic SHAP dependence
 Q6  computational cost (training and inference) of every expert and of the final framework
"""
import os, sys, json, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_monotone as MO
FW = MO.FW; U = FW.U
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import lightgbm as lgb, xgboost as xgb, shap
from sklearn.cluster import MiniBatchKMeans
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score, mean_squared_error, accuracy_score, roc_auc_score, f1_score
from bishop import bishop_fos
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/q1_results/"; os.makedirs(OUT + "figures", exist_ok=True)
CK = os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work") + "/q1/"; os.makedirs(CK, exist_ok=True)
T0 = time.time(); RS = 42
def say(*a): print(f"[Q1 {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    say("computing", name); r = fn(); joblib.dump(r, f); return r
def savefig(n): plt.tight_layout(); plt.savefig(OUT + "figures/" + n, dpi=200, bbox_inches="tight"); plt.close()
def M(y, p):
    p = np.clip(p, .25, 5); a, b = U.to_class(y), U.to_class(p)
    return dict(R2=r2_score(y, p), RMSE=mean_squared_error(y, p) ** .5, Accuracy=accuracy_score(a, b), F1_Marginal=f1_score(a == 1, b == 1))
sva, A_sva, FEATS, NUM = U.sva, U.A_sva, U.FEATS, U.NUM
s_tr, s_va, s_te = U.s_tr, U.s_va, U.s_te
yP = sva.FoS.values; yO = np.clip(sva.FactorOfSafety.values, .25, 5)

# ------------------------------------------------------------ Q1 dataset characterisation
say("Q1 dataset characterisation")
d = pd.read_csv(U.CFG["SVA"])
num = d.select_dtypes("number").drop(columns=["SlopeID"])
ch = pd.DataFrame({"min": num.min(), "max": num.max(), "mean": num.mean(), "sd": num.std(),
                   "uniformity_KS_stat": [float(np.max(np.abs(np.sort((v - v.min()) / (v.max() - v.min())) - np.linspace(0, 1, len(v))))) for v in (num[c].values for c in num)]})
ch.round(4).to_csv(OUT + "Q1a_variable_ranges_and_uniformity.csv")
corr = num.drop(columns="FactorOfSafety").corr().round(3); corr.to_csv(OUT + "Q1b_input_correlations.csv")
facts = dict(rows=len(d), duplicates=int(d.drop(columns="SlopeID").duplicated().sum()), soil_type_counts=d.SoilType.value_counts().to_dict(),
             vegetation_missing_pct=float(d.VegetationCover.isna().mean() * 100), FoS_at_floor_0_25=int((d.FactorOfSafety <= .2500001).sum()),
             FoS_at_cap_5=int((d.FactorOfSafety >= 4.99999).sum()), class_counts=d.StabilityStatus.value_counts().to_dict(),
             strongly_correlated_input_pairs=[(a, b, float(corr.loc[a, b])) for a in corr for b in corr if a < b and abs(corr.loc[a, b]) > .5])
json.dump(facts, open(OUT + "Q1c_dataset_facts.json", "w"), indent=2, default=str)

# ------------------------------------------------------------ Q2 label-correction sensitivity
say("Q2 label-correction sensitivity")
def q2():
    rows = {}
    Atr, Ava, Ate = A_sva.iloc[s_tr], A_sva.iloc[s_va], A_sva.iloc[s_te]
    Ar = U.real_matrix(U.real); yr = U.real.fail.values
    for lab, y in (("original labels", yO), ("physics-corrected labels (used)", yP)):
        m = lgb.LGBMRegressor(n_estimators=4000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS)
        m.fit(Atr, y[s_tr], eval_set=[(Ava, y[s_va])], callbacks=[lgb.early_stopping(150, verbose=False)])
        p = m.predict(Ate); Xq = Ate.sample(1500, random_state=1)
        v = np.array([m.predict(Xq.assign(SeismicCoefficient=k)).mean() for k in (0., .1, .2, .3)]); pr = m.predict(Ar)
        rows[lab] = dict(**{f"{k}_vs_own_labels": v_ for k, v_ in M(y[s_te], p).items()},
                         FoS_ratio_kh_0_1=v[1] / v[0], FoS_ratio_kh_0_2=v[2] / v[0], FoS_ratio_kh_0_3=v[3] / v[0],
                         real_zero_shot_AUROC=roc_auc_score(yr, -pr), real_zero_shot_accuracy=accuracy_score(yr, pr < 1))
    mpo = U.mp.iloc[U.g_ho]; mpc = mpo.groupby(mpo.kh.round(2)).ratio.median()
    rows["Morgenstern-Price (held-out geometries)"] = dict(FoS_ratio_kh_0_1=mpc.get(.1), FoS_ratio_kh_0_2=mpc.get(.2), FoS_ratio_kh_0_3=mpc.get(.3))
    rows["Real rock slopes (reported, kh=0.15)"] = dict(FoS_ratio_kh_0_1=np.nan)
    return pd.DataFrame(rows).T
Q2 = cached("q2", q2); Q2.round(4).to_csv(OUT + "Q2_label_correction_sensitivity.csv"); say("\n" + Q2.round(3).to_string())

# ------------------------------------------------------------ Q3 cluster-holdout
say("Q3 cluster-holdout split")
def q3():
    Z = StandardScaler().fit_transform(A_sva[NUM[:11]]); km = MiniBatchKMeans(25, random_state=RS, n_init=5).fit(Z); cl = km.labels_
    rng = np.random.default_rng(RS); test_cl = rng.choice(25, 5, replace=False); te = np.isin(cl, test_cl); tr = ~te
    idx_tr = np.where(tr)[0]; rng.shuffle(idx_tr); n_v = int(.1 * len(idx_tr)); iv, it = idx_tr[:n_v], idx_tr[n_v:]
    rows = {}
    for name, mk in (("LightGBM", lambda: lgb.LGBMRegressor(n_estimators=4000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS)),
                     ("XGBoost", lambda: xgb.XGBRegressor(n_estimators=4000, early_stopping_rounds=150, tree_method="hist", random_state=RS, **{k: v for k, v in U.CFG["XGB"].items()})),
                     ("MLP (DL baseline)", None)):
        for split, (a, v, t) in (("random split (used)", (s_tr, s_va, s_te)), ("cluster-holdout (5 of 25 input clusters unseen)", (it, iv, np.where(te)[0]))):
            X, y = A_sva, yP
            if name == "MLP (DL baseline)":
                sc = StandardScaler().fit(X.iloc[a]); m = MLPRegressor(hidden_layer_sizes=(256, 128, 64), early_stopping=True, max_iter=60, random_state=RS).fit(sc.transform(X.iloc[a]), y[a]); p = m.predict(sc.transform(X.iloc[t]))
            elif name == "XGBoost":
                m = mk().fit(X.iloc[a], y[a], eval_set=[(X.iloc[v], y[v])], verbose=False); p = m.predict(X.iloc[t])
            else:
                m = mk().fit(X.iloc[a], y[a], eval_set=[(X.iloc[v], y[v])], callbacks=[lgb.early_stopping(150, verbose=False)]); p = m.predict(X.iloc[t])
            rows[(name, split)] = dict(n_test=len(t), **M(y[t], p))
    return pd.DataFrame(rows).T
Q3 = cached("q3", q3); Q3.round(4).to_csv(OUT + "Q3_cluster_holdout_vs_random.csv"); say("\n" + Q3.round(4).to_string())

# ------------------------------------------------------------ Q4 literature-style baselines (same split, same test)
say("Q4 literature baselines")
def q4():
    Atr, Ate = A_sva.iloc[s_tr], A_sva.iloc[s_te]; ytr, yte = yP[s_tr], yP[s_te]; sc = StandardScaler().fit(Atr); Ztr, Zte = sc.transform(Atr), sc.transform(Ate)
    rng = np.random.default_rng(RS); sub = rng.choice(len(Ztr), 20000, replace=False); rows = {}
    def add(n, p, note=""): rows[n] = dict(**M(yte, p), note=note)
    add("Ridge regression (linear)", Ridge(1.).fit(Ztr, ytr).predict(Zte))
    add("kNN regression (k=15)", KNeighborsRegressor(15, weights="distance").fit(Ztr[sub], ytr[sub]).predict(Zte), "20,000-row training subsample (kNN memory)")
    # SVR (GWO-tuned) and ANN (PSO-tuned) baselines are in msh_lit_baselines.py -> final_results/T11
    # physics: Bishop simplified FoS (static) linearly calibrated on training slopes, with pseudo-static kh term
    rs = np.random.default_rng(3); ib = rs.choice(len(Atr), 3000, replace=False); it_ = rs.choice(len(Ate), 3000, replace=False)
    bf = lambda D: np.array([bishop_fos(r.SlopeHeight_m, r.SlopeAngle_deg, r.Cohesion_kPa, r.FrictionAngle_deg, r.UnitWeight_kN_m3, r.PorePressureRatio) for r in D.itertuples()])
    btr, bte = bf(Atr.iloc[ib]), bf(Ate.iloc[it_])
    Xb = lambda D, b: np.c_[np.log(np.clip(b, .05, 50)), D.SeismicCoefficient.values, np.log(np.clip(b, .05, 50)) * D.SeismicCoefficient.values]
    lr = Ridge(1e-3).fit(Xb(Atr.iloc[ib], btr), np.log(ytr[ib])); p = np.exp(lr.predict(Xb(Ate.iloc[it_], bte)))
    rows["Bishop simplified LEM, calibrated (physics baseline)"] = dict(**M(yte[it_], p), note="3,000 test slopes (LEM cost); log-linear calibration + kh term on 3,000 training slopes")
    return pd.DataFrame(rows).T
Q4 = cached("q4", q4)
fin = MO.piece("pt1", None); Q4.loc["PROPOSED FRAMEWORK (+ monotone envelope)"] = dict(**M(U.TS["lo"], fin), note="5 seeds, final model")
Q4.to_csv(OUT + "Q4_literature_baselines_same_split.csv"); say("\n" + Q4.drop(columns="note").astype(float).round(4).to_string())

# ------------------------------------------------------------ Q5 SHAP + permutation importance of the FINAL framework
say("Q5 SHAP on final framework")
BASE = NUM[:11]; CAT = [c for c in FEATS if c.startswith(("SoilType_", "VegetationCover_", "DrainageCondition_"))]
def framework_on(Xnum, template):
    D = template.copy(); D[BASE] = Xnum; return MO.fw(FW.recompute(D))
def q5():
    S = U.TS["A"].sample(200, random_state=RS).reset_index(drop=True); bg = U.TR["A"].iloc[:U.TR["nS"]].sample(50, random_state=RS)[BASE].values
    vals = np.zeros((len(S), len(BASE)))
    for i in range(len(S)):                                   # categorical context of each slope kept fixed (no invalid one-hot mixes)
        tmpl = pd.concat([S.iloc[[i]]] * 1, ignore_index=True)
        f = lambda X, t=tmpl: framework_on(X, pd.concat([t] * len(X), ignore_index=True))
        ex = shap.PermutationExplainer(f, bg); vals[i] = ex(S.iloc[[i]][BASE].values, max_evals=2 * len(BASE) + 1).values[0]
        if i % 25 == 0: say(f"  shap {i}/{len(S)}")
    base = U.TS["A"].sample(2000, random_state=7); yb = U.TS["lo"][U.TS["A"].index.get_indexer(base.index)] if False else None
    return dict(values=vals, data=S[BASE].values)
SH = cached("q5_shap", q5)
pd.DataFrame(SH["values"], columns=[f"shap_{c}" for c in BASE]).join(pd.DataFrame(SH["data"], columns=BASE)).round(5).to_csv(OUT + "Q5d_shap_values_200_test_slopes.csv", index=False)
imp = pd.Series(np.abs(SH["values"]).mean(0), index=BASE).sort_values(ascending=False); imp.round(5).to_csv(OUT + "Q5a_shap_importance_final_framework.csv")
shap.summary_plot(SH["values"], pd.DataFrame(SH["data"], columns=BASE), show=False); savefig("Q5_shap_summary_final_framework.png")
j_kh, j_r, j_ru = BASE.index("SeismicCoefficient"), BASE.index("Rainfall_mm_day"), BASE.index("PorePressureRatio")
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2))
sc = axs[0].scatter(SH["data"][:, j_kh], SH["values"][:, j_kh], c=SH["data"][:, j_r], cmap="viridis", s=14); plt.colorbar(sc, ax=axs[0], label="Rainfall (mm/day)")
axs[0].set(xlabel="Seismic coefficient kh", ylabel="SHAP value of kh (FoS units)", title="Seismic effect coloured by rainfall")
sc = axs[1].scatter(SH["data"][:, j_ru], SH["values"][:, j_ru], c=SH["data"][:, j_kh], cmap="magma", s=14); plt.colorbar(sc, ax=axs[1], label="kh")
axs[1].set(xlabel="Pore pressure ratio r_u", ylabel="SHAP value of r_u (FoS units)", title="Pore-pressure effect coloured by kh"); savefig("Q5b_shap_rainfall_seismic_dependence.png")
def q5b():
    S = U.TS["A"].sample(2000, random_state=7); y = U.TS["lo"][U.TS["A"].index.get_indexer(S.index)]; b0 = mean_squared_error(y, MO.fw(S)) ** .5; out = {}
    for c in BASE:
        D = S.copy(); D[c] = np.random.default_rng(RS).permutation(D[c].values); out[c] = mean_squared_error(y, MO.fw(FW.recompute(D))) ** .5 - b0
    return out
PI = pd.Series(cached("q5_perm", q5b)).sort_values(ascending=False); PI.round(5).to_csv(OUT + "Q5c_permutation_importance_final_framework.csv")
pd.DataFrame({"mean_abs_SHAP": imp, "permutation_RMSE_increase": PI}).round(5).to_csv(OUT + "Q5_importance_summary.csv")

# ------------------------------------------------------------ Q6 computational cost
say("Q6 computational cost")
def q6():
    import re
    log = open(os.path.join(os.path.dirname(HERE), ".work", "log_msh_unified.log")).read() if os.path.exists(os.path.join(os.path.dirname(HERE), ".work", "log_msh_unified.log")) else ""
    tr = {m.group(1): (int(m.group(2)), float(m.group(3))) for m in re.finditer(r"\]\s+(\S+): (\d+) ep, val iRMSE [\d.]+, (\d+)s", log)}
    A = U.TS["A"]; rows = {}
    for n in FW.EXPERTS:
        t = time.time(); FW.FN[n](A); dt = time.time() - t; key = "".join(ch for ch in n if ch.isalnum())[:30]
        ep, sec = tr.get(key, (np.nan, np.nan)); rows[n] = dict(train_epochs=ep, train_seconds=sec, inference_ms_per_1000_slopes=dt / len(A) * 1e6)
    t = time.time(); MO.fw(A); rows["FINAL framework (3 experts + attention fusion)"] = dict(inference_ms_per_1000_slopes=(time.time() - t) / len(A) * 1e6)
    rows["FINAL framework + monotone envelope"] = dict(inference_ms_per_1000_slopes=float(MO.piece("tinf", None)) * 1000)
    return pd.DataFrame(rows).T
Q6 = cached("q6", q6); Q6.round(3).to_csv(OUT + "Q6_computational_cost.csv"); say("\n" + Q6.round(2).to_string())

# ------------------------------------------------------------ Q7 extrapolation check of the rainfall x seismic scenario surface
say("Q7 scenario-surface support check")
from sklearn.neighbors import NearestNeighbors
def q7():
    cols = ["Rainfall_mm_day", "SeismicCoefficient", "SlopeAngle_deg", "PorePressureRatio", "Cohesion_kPa", "FrictionAngle_deg"]
    Atr = U.TR["A"].iloc[:U.TR["nS"]]; sc = StandardScaler().fit(Atr[cols]); nn = NearestNeighbors(n_neighbors=1).fit(sc.transform(Atr[cols]))
    ref = np.percentile(nn.kneighbors(sc.transform(U.TS["A"][cols]))[0][:, 0], 99)       # 99th pct test->train distance
    G = FW.G.copy(); ru = np.clip(U.ru_m.predict(G[U.HYD]), .02, .6); G["PorePressureRatio"] = ru
    dist = nn.kneighbors(sc.transform(G[cols]))[0][:, 0].reshape(FW.rr.shape)
    supported = dist <= ref
    rows = [dict(kh=round(float(k), 2), cells_supported_pct=float(supported[j].mean() * 100), max_rain_supported=float(FW.Rg[supported[j]].max()) if supported[j].any() else np.nan)
            for j, k in enumerate(FW.Kg)]
    return dict(table=pd.DataFrame(rows), dist=dist, ref=ref, supported=supported)
S7 = cached("q7", q7); S7["table"].round(3).to_csv(OUT + "Q7_scenario_surface_data_support.csv", index=False)
fig, ax = plt.subplots(figsize=(6.5, 4.6)); cs = ax.contourf(FW.rr, FW.kk, np.clip(FW.SURF, .5, 2), levels=np.linspace(.5, 2, 16), cmap="RdYlGn")
ax.contour(FW.rr, FW.kk, FW.SURF, levels=[1, 1.3], colors="k"); plt.colorbar(cs, label="FoS")
ax.contourf(FW.rr, FW.kk, (~S7["supported"]).astype(float), levels=[.5, 1.5], hatches=["///"], colors="none")
ax.set(xlabel="Rainfall (mm/day)", ylabel="kh", title="Rainfall-seismic surface; hatched = outside training-data support"); savefig("Q7_surface_with_support.png")
say("\n" + S7["table"].round(2).to_string())
say("DONE")
