"""Scenario-family analysis. The Kaggle dataset is a mixture of hazard scenario families with NON-overlapping parameter
ranges (no data for kh 0.12-0.15 or rainfall 140-180 mm/day). This script
 F1 identifies the families and their parameter envelopes,
 F2 reports the final framework's test performance per family (and without the all-failure extreme family),
 F3 leave-one-family-out test: train on the other families, test on the unseen family (the "simulation family" leakage
    check of the study protocol), for LightGBM, XGBoost and an MLP.
"""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_unified.py")).read()
exec(src.split("# ===================================================================== 6. tree models")[0])
import lightgbm as lgb2, xgboost as xgb2
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler as SS
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTQ = ROOT + "/q1_results/"; os.makedirs(OUTQ, exist_ok=True)
WK = os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work") + "/q1/"
fam = pd.cut(sva.SeismicCoefficient, [-.01, .03, .10, .12, .31], labels=["F1 low hazard (kh<0.03)", "F2 moderate (0.03<=kh<0.10)",
                                                                        "F3 elevated (0.10<=kh<0.12)", "F4 extreme compound (kh>=0.15)"]).astype(str).values
# ---- F1 envelopes
cols = ["SeismicCoefficient", "Rainfall_mm_day", "SlopeAngle_deg", "Cohesion_kPa", "FrictionAngle_deg", "PorePressureRatio", "GroundwaterDepth_m", "SlopeHeight_m"]
env = sva.groupby(fam)[cols].agg(["min", "max"]).round(2); env["n"] = pd.Series(fam).value_counts()
env["failure_pct_corrected_labels"] = pd.Series(sva.FoS.values < 1).groupby(fam).mean() * 100
env["failure_pct_original_labels"] = pd.Series(sva.FactorOfSafety.values < 1).groupby(fam).mean() * 100
env.to_csv(OUTQ + "QF1_scenario_family_envelopes.csv"); say("\n" + env.round(1).to_string())
# ---- F2 final framework per family (test set; predictions cached by msh_monotone.py)
def M(y, p):
    p = np.clip(p, .25, 5); a, b = to_class(y), to_class(p)
    return dict(n=len(y), R2=r2_score(y, p) if len(y) > 2 else np.nan, RMSE=mean_squared_error(y, p) ** .5, Accuracy=accuracy_score(a, b),
                F1_Marginal=f1_score(a == 1, b == 1) if (a == 1).any() else np.nan)
pt = joblib.load(os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work") + "/ckptFinal/mono_pt1.joblib"); yte = sva.FoS.values[s_te]; fte = fam[s_te]
rows = {f: M(yte[fte == f], pt[fte == f]) for f in sorted(set(fte))}
rows["ALL test slopes"] = M(yte, pt); m = fte != "F4 extreme compound (kh>=0.15)"; rows["ALL except extreme family"] = M(yte[m], pt[m])
pd.DataFrame(rows).T.round(4).to_csv(OUTQ + "QF2_final_framework_per_family.csv"); say("\n" + pd.DataFrame(rows).T.round(4).to_string())
# ---- F3 leave-one-family-out
def lofo():
    out = {}
    for f in sorted(set(fam)):
        tr = np.setdiff1d(s_tr, np.where(fam == f)[0]); va = np.setdiff1d(s_va, np.where(fam == f)[0]); te = np.intersect1d(s_te, np.where(fam == f)[0])
        intr = np.intersect1d(s_te, np.where(fam == f)[0])
        X, y = A_sva, sva.FoS.values
        for name in ("LightGBM", "XGBoost", "MLP"):
            if name == "LightGBM":
                mm = lgb2.LGBMRegressor(n_estimators=3000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS)
                mm.fit(X.iloc[tr], y[tr], eval_set=[(X.iloc[va], y[va])], callbacks=[lgb2.early_stopping(150, verbose=False)]); p = mm.predict(X.iloc[te])
                mi = lgb2.LGBMRegressor(n_estimators=3000, learning_rate=.04, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS)
                mi.fit(X.iloc[s_tr], y[s_tr], eval_set=[(X.iloc[s_va], y[s_va])], callbacks=[lgb2.early_stopping(150, verbose=False)]); pi = mi.predict(X.iloc[intr])
            elif name == "XGBoost":
                mm = xgb2.XGBRegressor(n_estimators=3000, early_stopping_rounds=150, tree_method="hist", random_state=RS, **CFG["XGB"]).fit(X.iloc[tr], y[tr], eval_set=[(X.iloc[va], y[va])], verbose=False)
                p = mm.predict(X.iloc[te]); mi = xgb2.XGBRegressor(n_estimators=3000, early_stopping_rounds=150, tree_method="hist", random_state=RS, **CFG["XGB"]).fit(X.iloc[s_tr], y[s_tr], eval_set=[(X.iloc[s_va], y[s_va])], verbose=False); pi = mi.predict(X.iloc[intr])
            else:
                sc = SS().fit(X.iloc[tr]); mm = MLPRegressor(hidden_layer_sizes=(256, 128, 64), early_stopping=True, max_iter=60, random_state=RS).fit(sc.transform(X.iloc[tr]), y[tr]); p = mm.predict(sc.transform(X.iloc[te]))
                sc2 = SS().fit(X.iloc[s_tr]); mi = MLPRegressor(hidden_layer_sizes=(256, 128, 64), early_stopping=True, max_iter=60, random_state=RS).fit(sc2.transform(X.iloc[s_tr]), y[s_tr]); pi = mi.predict(sc2.transform(X.iloc[intr]))
            a, b = M(y[te], p), M(y[intr], pi)
            out[(f, name)] = {"n_test": a["n"], "RMSE_family_seen": b["RMSE"], "RMSE_family_UNSEEN": a["RMSE"], "Accuracy_family_seen": b["Accuracy"], "Accuracy_family_UNSEEN": a["Accuracy"]}
            say(f, name, {k: round(v, 4) for k, v in out[(f, name)].items()})
    return pd.DataFrame(out).T
os.makedirs(WK, exist_ok=True); fF = WK + "lofo.joblib"
L = joblib.load(fF) if os.path.exists(fF) else lofo(); joblib.dump(L, fF)
L.round(4).to_csv(OUTQ + "QF3_leave_one_family_out.csv"); say("\n" + L.round(4).to_string()); say("DONE")
