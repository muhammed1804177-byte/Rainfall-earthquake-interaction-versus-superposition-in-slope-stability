"""Additional reviewer analyses from cached predictions (no retraining).
 A  model comparison on the NON-TRIVIAL slopes (families F1-F3; the all-failure F4 removed): RMSE, bootstrap 95% CI,
    accuracy, Marginal F1, Wilcoxon test vs the final framework
 B  family-conditional (Mondrian) conformal intervals: coverage per family and per stability class, global vs conditional
 C  error analysis: where misclassifications happen (distance of the true FoS to the 1.0 / 1.3 thresholds)
 D  safety-oriented decision analysis: missed failures (dangerous) vs false alarms at different decision thresholds
"""
import os, sys, json, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_unified.py")).read()
exec(src.split("# ===================================================================== 4. real case histories")[0])
from scipy.stats import wilcoxon
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTQ = ROOT + "/q1_results/"; os.makedirs(OUTQ + "figures", exist_ok=True)
WK = os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work")
s_ca = s_ca; fam = pd.cut(sva.SeismicCoefficient, [-.01, .03, .10, .12, .31], labels=["F1", "F2", "F3", "F4"]).astype(str).values
y_te, y_ca = sva.FoS.values[s_te], sva.FoS.values[s_ca]; f_te, f_ca = fam[s_te], fam[s_ca]
PT = joblib.load(WK + "/ckptU3/PT.joblib"); FIN = joblib.load(WK + "/ckptFinal/mono_pt1.joblib"); FIN_C = joblib.load(WK + "/ckptFinal/mono_pc1.joblib")
PT = {k.lstrip("_"): v for k, v in PT.items()}; PT["FINAL FRAMEWORK (+ envelope)"] = FIN
cl = lambda p: to_class(np.clip(p, .25, 5))
# ---------------- A non-trivial comparison
m = f_te != "F4"; yt = y_te[m]; rng = np.random.default_rng(42); BI = [rng.integers(0, m.sum(), m.sum()) for _ in range(1000)]
ef = (np.clip(FIN[m], .25, 5) - yt) ** 2; rows = {}
for n, p in PT.items():
    p = np.clip(p[m], .25, 5); e = (p - yt) ** 2; r = [np.sqrt(e[j].mean()) for j in BI]
    rows[n] = dict(RMSE=np.sqrt(e.mean()), CI95_low=np.percentile(r, 2.5), CI95_high=np.percentile(r, 97.5), R2=r2_score(yt, p),
                   Accuracy=accuracy_score(to_class(yt), to_class(p)), F1_Marginal=f1_score(to_class(yt) == 1, to_class(p) == 1),
                   Recall_Failure=recall_score(to_class(yt) == 0, to_class(p) == 0),
                   Wilcoxon_p_framework_better=np.nan if n.startswith("FINAL") else wilcoxon(ef, e, alternative="less").pvalue)
A = pd.DataFrame(rows).T.sort_values("RMSE"); A.round(5).to_csv(OUTQ + "QA_model_comparison_nontrivial_F1_F3.csv"); say("\n" + A.round(4).to_string())
# ---------------- B Mondrian conformal by family
def cover(alpha):
    out = []; e_ca = np.abs(y_ca - np.clip(FIN_C, .25, 5)); n = len(e_ca)
    qg = np.quantile(e_ca, min(1, np.ceil((n + 1) * (1 - alpha)) / n))
    qf = {f: np.quantile(e_ca[f_ca == f], min(1, np.ceil(((f_ca == f).sum() + 1) * (1 - alpha)) / (f_ca == f).sum())) for f in np.unique(f_ca)}
    for meth, q in (("global", np.full(len(y_te), qg)), ("family-conditional (Mondrian)", np.array([qf[f] for f in f_te]))):
        c = np.abs(y_te - FIN) <= q
        row = dict(alpha=alpha, method=meth, coverage_all=c.mean(), mean_half_width=q.mean())
        for f in ["F1", "F2", "F3", "F4"]: row[f"coverage_{f}"] = c[f_te == f].mean(); row[f"half_width_{f}"] = q[f_te == f].mean()
        for k, nm in enumerate(["Failure", "Marginal", "Stable"]): row[f"coverage_class_{nm}"] = c[to_class(y_te) == k].mean()
        out.append(row)
    return out
B = pd.DataFrame(cover(.10) + cover(.05)); B.round(4).to_csv(OUTQ + "QB_conformal_by_family.csv", index=False); say("\n" + B.round(3).T.to_string())
# ---------------- C error analysis
pc_ = cl(FIN); tc = to_class(y_te); wrong = pc_ != tc
dist = np.minimum(np.abs(y_te - 1.0), np.abs(y_te - 1.3))
bins = [0, .01, .02, .05, .1, .2, 10]; lab = ["<0.01", "0.01-0.02", "0.02-0.05", "0.05-0.10", "0.10-0.20", ">0.20"]
C = pd.DataFrame(dict(dist=pd.cut(dist, bins, labels=lab, include_lowest=True), wrong=wrong)).groupby("dist", observed=False).agg(n=("wrong", "size"), errors=("wrong", "sum"))
C["error_rate_pct"] = C.errors / C.n * 100; C["share_of_all_errors_pct"] = C.errors / wrong.sum() * 100
C.round(3).to_csv(OUTQ + "QC_error_vs_distance_to_threshold.csv"); say("\n" + C.round(2).to_string())
conf = pd.crosstab(pd.Series(tc).map({0: "Failure", 1: "Marginal", 2: "Stable"}), pd.Series(pc_).map({0: "Failure", 1: "Marginal", 2: "Stable"}), rownames=["true"], colnames=["predicted"])
conf.to_csv(OUTQ + "QC_confusion_matrix_test.csv"); say("\n" + conf.to_string())
# ---------------- D safety-oriented threshold (missed failures)
D = []
for thr in [1.00, 1.02, 1.05, 1.08, 1.10, 1.15, 1.20]:
    pf = FIN < thr; tf = y_te < 1
    D.append(dict(decision_threshold=thr, missed_failures_pct=(tf & ~pf).sum() / tf.sum() * 100, false_alarms_pct=(~tf & pf).sum() / (~tf).sum() * 100,
                  flagged_pct=pf.mean() * 100))
D = pd.DataFrame(D); D.round(3).to_csv(OUTQ + "QD_safety_threshold_tradeoff.csv", index=False); say("\n" + D.round(2).to_string())
# conformal upper bound rule: declare 'safe' only if the upper end of the 95 % interval is >= 1 ... i.e. flag if lower bound < 1
e_ca = np.abs(y_ca - np.clip(FIN_C, .25, 5)); q95 = np.quantile(e_ca, np.ceil((len(e_ca) + 1) * .95) / len(e_ca)); pf = FIN - q95 < 1; tf = y_te < 1
json.dump(dict(rule="flag slope if lower 95% conformal bound < 1", missed_failures_pct=float((tf & ~pf).sum() / tf.sum() * 100),
               false_alarms_pct=float((~tf & pf).sum() / (~tf).sum() * 100)), open(OUTQ + "QD_conformal_safety_rule.json", "w"), indent=2)
say("DONE")
