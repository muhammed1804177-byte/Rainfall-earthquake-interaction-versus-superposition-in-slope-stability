"""Follow-up reviewer analyses (run after msh_q1_extras.py).
 Q6b training cost of every expert, timed directly in this environment (deep models from the training log)
 Q8  data-grounded compound-hazard analysis: observed vs predicted failure rate in rainfall x kh cells of the TEST set,
     only cells with >= 100 slopes (no extrapolation outside the data), plus critical rainfall restricted to supported cells
"""
import os, sys, re, time, json, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_monotone as MO
FW = MO.FW; U = FW.U
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/q1_results/"; os.makedirs(OUT + "figures", exist_ok=True)
CK = os.environ.get("MSH_WORK", os.path.dirname(HERE) + "/work") + "/q1/"; os.makedirs(CK, exist_ok=True)
T0 = time.time()
def say(*a): print(f"[Q1M {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    say("computing", name); r = fn(); joblib.dump(r, f); return r

# ---------------- Q6b training cost
def q6b():
    logs = ""
    for f in ("unified.log", "log_msh_unified.log"):
        p = os.path.join(ROOT, ".work", f)
        if os.path.exists(p): logs += open(p).read()
    dl = {}
    for m in re.finditer(r"\]\s+(\S+): (\d+) ep, val iRMSE [\d.]+, (\d+)s", logs): dl[m.group(1)] = (int(m.group(2)), float(m.group(3)))
    tr = {}
    t = time.time(); U.fit_xgb(U.TR["A"], U.TR, Dv=U.VA); tr["XGBoost"] = time.time() - t
    t = time.time(); U.fit_lgb(U.TR["A"], U.TR, U.VA); tr["LightGBM"] = time.time() - t
    t = time.time(); RandomForestRegressor(n_estimators=150, min_samples_leaf=2, max_samples=.5, n_jobs=-1, random_state=42).fit(U.TR["A"], U.TR["lo"]); tr["RandomForest"] = time.time() - t
    return dl, tr
DL, TRT = cached("q6b", q6b)
Q6 = pd.read_csv(OUT + "Q6_computational_cost.csv", index_col=0)
for n in Q6.index:
    k = "".join(ch for ch in n if ch.isalnum())[:30]
    if k in DL: Q6.loc[n, "train_epochs"], Q6.loc[n, "train_seconds"] = DL[k]
    if n in TRT: Q6.loc[n, "train_seconds"] = TRT[n]
Q6["note"] = ""; Q6.loc[Q6.index.str.startswith("Hybrid") | Q6.index.str.startswith("N2") | Q6.index.str.contains("embedding"), "note"] = "plus the training time of its deep feature extractor"
Q6.loc[Q6.index.str.startswith("S-"), "note"] = "same cost as XGBoost (regime-weighted)"
Q6.loc["RandomForest", "note"] = "train time shown for a single fit; the interval-loss projection refits twice"
Q6.round(2).to_csv(OUT + "Q6_computational_cost.csv"); say("\n" + Q6.round(1).to_string())

# ---------------- Q8 data-grounded compound hazard
say("Q8 data-grounded compound hazard")
A = U.TS["A"].reset_index(drop=True); y = U.TS["lo"]; p = MO.piece("pt1", None)
rb = pd.cut(A.Rainfall_mm_day, [0, 40, 80, 120, 160, 200, 240, 320], include_lowest=True); kb = pd.cut(A.SeismicCoefficient, [0, .05, .1, .15, .2, .25, .3], include_lowest=True)
D = pd.DataFrame(dict(rain=rb, kh=kb, obs=(y < 1).astype(float), pred=(p < 1).astype(float), FoS_obs=y, FoS_pred=p))
G = D.groupby(["kh", "rain"], observed=True).agg(n=("obs", "size"), observed_failure_rate=("obs", "mean"), predicted_failure_rate=("pred", "mean"),
                                                 median_FoS_observed=("FoS_obs", "median"), median_FoS_predicted=("FoS_pred", "median")).reset_index()
G["supported"] = G.n >= 100; G.round(4).to_csv(OUT + "Q8_compound_hazard_cells_test_set.csv", index=False)
Gs = G[G.supported]
say(f"cells with >=100 test slopes: {len(Gs)} of {len(G)}; mean |observed-predicted failure rate| = {np.mean(np.abs(Gs.observed_failure_rate - Gs.predicted_failure_rate))*100:.2f} pp")
# heatmaps (observed / predicted), unsupported cells blank
piv = lambda col: G.pivot(index="kh", columns="rain", values=col).where(G.pivot(index="kh", columns="rain", values="supported").fillna(False).astype(bool))
fig, axs = plt.subplots(1, 2, figsize=(11, 4), sharey=True)
from matplotlib.colors import LinearSegmentedColormap
SEQ = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"])
for ax, col, t in zip(axs, ["observed_failure_rate", "predicted_failure_rate"], ["(a) Observed failure rate (test labels)", "(b) Framework predicted failure rate"]):
    M = piv(col); im = ax.imshow(M.values * 100, cmap=SEQ, vmin=0, vmax=100, aspect="auto", origin="lower")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M.values[i, j]
            if np.isfinite(v): ax.text(j, i, f"{v*100:.0f}", ha="center", va="center", fontsize=7, color="white" if v > .55 else "#0b0b0b")
    ax.set_xticks(range(M.shape[1]), [str(c) for c in M.columns], rotation=35, fontsize=7); ax.set_yticks(range(M.shape[0]), [str(c) for c in M.index], fontsize=7)
    ax.set(xlabel="Rainfall (mm/day)", title=t); ax.grid(False)
axs[0].set_ylabel("Seismic coefficient kh"); plt.colorbar(im, ax=axs, label="% of slopes with FoS < 1", shrink=.8)
fig.text(.01, -.02, "Blank cells: fewer than 100 test slopes (outside the data's support); no values are extrapolated.", fontsize=8, color="#52514e")
plt.savefig(OUT + "figures/Q8_compound_hazard_failure_rates.png", dpi=300, bbox_inches="tight"); plt.savefig(OUT + "figures/Q8_compound_hazard_failure_rates.pdf", bbox_inches="tight"); plt.close()
# critical rainfall only where supported (Q7 support mask on the median-slope surface)
S7 = joblib.load(CK + "q7.joblib"); sup = S7["supported"]; crit = []
for j, k in enumerate(FW.Kg):
    row = FW.SURF[j]; ok = sup[j]; below = np.where((row < 1) & ok)[0]
    crit.append(dict(kh=round(float(k), 2), critical_rainfall_supported=float(FW.Rg[below[0]]) if len(below) else np.nan,
                     max_supported_rain=float(FW.Rg[ok].max()) if ok.any() else np.nan, FoS_at_max_supported_rain=float(row[ok][-1]) if ok.any() else np.nan))
pd.DataFrame(crit).round(3).to_csv(OUT + "Q8b_critical_rainfall_supported_region_only.csv", index=False)
say("\n" + pd.DataFrame(crit).round(3).to_string()); say("DONE")
