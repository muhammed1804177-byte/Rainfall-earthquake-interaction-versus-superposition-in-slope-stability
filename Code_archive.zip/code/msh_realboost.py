"""
Wider real-world search: 13 learners x 6 feature sets (incl. 20-expert predictions from the 120k-slope models)
+ soft-voting ensembles. Each configuration: 5x repeated grouped 5-fold CV (unbiased for that configuration).
The 'pick the best configuration' procedure: NESTED grouped CV (selection inside outer training folds only).
"""
import os, json, time, warnings
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import xgboost as xgb, lightgbm as lgb
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score
warnings.filterwarnings("ignore")
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/"); CK = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptR/")
__import__("os").makedirs(CK, exist_ok=True); __import__("os").makedirs(OUT + "figures", exist_ok=True)
RS = 42; T0 = time.time(); TARGET = .93
def say(*a): print(f"[B {(time.time()-T0)/60:5.1f}m]", *a, flush=True)

# ---------------- real slopes (identical construction to msh_unified / msh_realcombo)
R = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/real_validation_data/"); F6 = ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "PorePressureRatio"]
c1 = pd.read_csv(R + "1_circular_case_histories_184.csv"); c2 = pd.read_csv(R + "2_compiled_case_histories_361.csv")
real = pd.concat([pd.DataFrame(dict(zip(F6, [c1.H_m, c1.beta_deg, c1.gamma_kN_m3, c1.c_kPa, c1.phi_deg, c1.r_u]), fail=(c1.stability == "Failure").astype(int))),
                  pd.DataFrame(dict(zip(F6, [c2["slope height (m)"], c2["Slope angle"], c2["unit weight(kN/m3)"], c2["Cohesion(kPa)"], c2["internal friction angle"],
                                             c2["pore pressure ratio"]]), fail=(c2.Status == "Failure").astype(int)))], ignore_index=True)
real[F6] = real[F6].round(2); real = real.drop_duplicates(subset=F6).query("SlopeHeight_m > 0 and UnitWeight_kN_m3 > 0").reset_index(drop=True)
kq = pd.DataFrame(dict(a=real.SlopeHeight_m.round(0), b=real.SlopeAngle_deg.round(0), c=(real.UnitWeight_kN_m3 * 2).round(), d=real.Cohesion_kPa.round(0),
                       e=real.FrictionAngle_deg.round(0), f=(real.PorePressureRatio * 20).round()))
G = pd.factorize(kq.astype(str).agg("|".join, axis=1))[0]; y = real.fail.values
P = joblib.load(CK + "P_real.joblib"); EXPERTS = list(P)
assert len(next(iter(P.values()))) == len(y)

# ---------------- feature sets
b, p = np.radians(np.clip(real.SlopeAngle_deg, 1, 89)), np.radians(real.FrictionAngle_deg)
H, g, c, ru = real.SlopeHeight_m, real.UnitWeight_kN_m3, real.Cohesion_kPa, real.PorePressureRatio
PHY = pd.DataFrame(dict(N=c / (g * H), Fr=np.tan(p) / np.tan(b), FSinf=np.clip(c / (g * H * np.sin(b) * np.cos(b)) + (1 - ru) * np.tan(p) / np.tan(b), 0, 50),
                        lam=np.log1p(g * H * np.tan(p) / (c + .1)), logH=np.log(H), effphi=np.tan(p) * (1 - ru)))
E = pd.DataFrame({e: np.log(np.clip(P[e], .2, 6)) for e in EXPERTS})
top7 = pd.read_csv(OUT + "T1_all_combinations_realworld_CV.csv").iloc[0].members.split(" | ")
FS = {"F6": real[F6], "F6+physics": pd.concat([real[F6], PHY], axis=1),
      "physics only": PHY,
      "F6+physics+fused(best k=7 combo)": pd.concat([real[F6], PHY, E[top7].mean(1).rename("fused")], axis=1),
      "F6+physics+all 20 experts": pd.concat([real[F6], PHY, E], axis=1),
      "F6+physics+20-expert summary (mean, min, max, sd)": pd.concat([real[F6], PHY, E.mean(1).rename("emean"), E.min(1).rename("emin"), E.max(1).rename("emax"), E.std(1).rename("esd")], axis=1)}
FS = {k: v.values.astype(float) for k, v in FS.items()}
LEARN = {
    "Logistic": lambda: make_pipeline(StandardScaler(), LogisticRegression(C=1, max_iter=2000)),
    "Logistic poly-2": lambda: make_pipeline(StandardScaler(), PolynomialFeatures(2), StandardScaler(), LogisticRegression(C=.1, max_iter=3000)),
    "SVM-RBF": lambda: make_pipeline(StandardScaler(), SVC(C=3, gamma="scale", probability=True, random_state=RS)),
    "kNN-15": lambda: make_pipeline(StandardScaler(), KNeighborsClassifier(15, weights="distance")),
    "RandomForest": lambda: RandomForestClassifier(300, min_samples_leaf=2, random_state=RS, n_jobs=-1),
    "ExtraTrees": lambda: ExtraTreesClassifier(300, min_samples_leaf=2, random_state=RS, n_jobs=-1),
    "XGBoost": lambda: xgb.XGBClassifier(n_estimators=300, max_depth=3, learning_rate=.05, subsample=.8, colsample_bytree=.8, random_state=RS, eval_metric="logloss"),
    "LightGBM": lambda: lgb.LGBMClassifier(n_estimators=300, num_leaves=15, learning_rate=.05, subsample=.8, subsample_freq=1, colsample_bytree=.8, min_child_samples=10, verbose=-1, random_state=RS),
    "HistGB": lambda: HistGradientBoostingClassifier(max_iter=300, learning_rate=.05, max_leaf_nodes=15, random_state=RS),
    "MLP": lambda: make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(64, 32), alpha=1e-2, max_iter=2000, early_stopping=True, random_state=RS)),
    "GaussianProcess": lambda: make_pipeline(StandardScaler(), GaussianProcessClassifier(ConstantKernel() * RBF(), random_state=RS)),
}
class Vote:
    def __init__(s, names): s.names = names
    def fit(s, X, yy): s.m = [LEARN[n]().fit(X, yy) for n in s.names]; return s
    def predict_proba(s, X): return np.mean([m.predict_proba(X) for m in s.m], 0)
for nm in (["RandomForest", "ExtraTrees", "SVM-RBF"], ["XGBoost", "RandomForest", "GaussianProcess"], ["SVM-RBF", "GaussianProcess", "Logistic poly-2", "ExtraTrees"]):
    LEARN["Vote(" + "+".join(nm) + ")"] = (lambda nm=nm: Vote(nm))
CONFIGS = [(f, l) for f in FS for l in LEARN]
REPS = 5; FOLDS = [list(StratifiedGroupKFold(5, shuffle=True, random_state=r).split(FS["F6"], y, G)) for r in range(REPS)]
def cv(f, l, folds_list):
    X = FS[f]; acc, auc = [], []
    for folds in folds_list:
        pp = np.zeros(len(y))
        for a, b_ in folds: pp[b_] = LEARN[l]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]
        acc.append(accuracy_score(y, pp > .5)); auc.append(roc_auc_score(y, pp))
    return np.mean(acc), np.std(acc), np.mean(auc)
f_res = CK + "boost_configs.joblib"
if os.path.exists(f_res): RES = joblib.load(f_res)
else:
    RES = []
    for i, (f, l) in enumerate(CONFIGS):
        a, s, u = cv(f, l, FOLDS); RES.append(dict(features=f, learner=l, Accuracy=a, Accuracy_sd=s, AUROC=u))
        if i % 10 == 0: say(f"  {i+1}/{len(CONFIGS)} {f[:28]:28s} {l[:22]:22s} acc {a:.3f} auc {u:.3f}")
    joblib.dump(RES, f_res)
RES = pd.DataFrame(RES).sort_values("Accuracy", ascending=False); RES["meets_93pct"] = RES.Accuracy >= TARGET
RES.round(4).to_csv(OUT + "T5_wide_search_learners_x_features.csv", index=False); say("\n" + RES.head(12).round(4).to_string())

# ---------------- nested CV over ALL configurations (unbiased estimate of picking the best)
say("nested CV over all configurations")
f_nest = CK + "boost_nested.joblib"
if os.path.exists(f_nest): NEST = joblib.load(f_nest)
else:
    accs, aucs, picks = [], [], []
    for rep in range(2):
        pp = np.zeros(len(y))
        for a, b_ in FOLDS[rep]:
            inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=100 + rep).split(a, y[a], G[a])); best, bs = None, -1
            for f, l in CONFIGS:
                X = FS[f][a]; s = np.mean([accuracy_score(y[a][ib], LEARN[l]().fit(X[ia], y[a][ia]).predict_proba(X[ib])[:, 1] > .5) for ia, ib in inner])
                if s > bs: best, bs = (f, l), s
            picks.append(" | ".join(best)); pp[b_] = LEARN[best[1]]().fit(FS[best[0]][a], y[a]).predict_proba(FS[best[0]][b_])[:, 1]
        accs.append(accuracy_score(y, pp > .5)); aucs.append(roc_auc_score(y, pp)); say(f"  nested repeat {rep+1}: acc {accs[-1]:.3f}")
    NEST = dict(nested_accuracy=float(np.mean(accs)), nested_sd=float(np.std(accs)), nested_AUROC=float(np.mean(aucs)), picks=pd.Series(picks).value_counts().to_dict())
    joblib.dump(NEST, f_nest)
say("  nested:", {k: v for k, v in NEST.items() if k != "picks"})

# ---------------- does the 120k-slope knowledge help? (same learner, with vs without expert features)
cmp = RES.pivot_table(index="learner", columns="features", values="Accuracy")
cmp.round(4).to_csv(OUT + "T6_expert_features_effect.csv")
fig, ax = plt.subplots(figsize=(10, 5)); cmp.plot.bar(ax=ax, width=.85); ax.axhline(TARGET, c="k", ls=":", label="93 % target")
ax.axhline(NEST["nested_accuracy"], c="r", ls="--", label=f"nested (unbiased) {NEST['nested_accuracy']:.3f}"); ax.set_ylim(.5, 1)
ax.set(ylabel=f"accuracy, {len(y)} real slopes (grouped 5x5 CV)", title="Real-world accuracy: learners x feature sets"); ax.legend(fontsize=6, ncol=2)
plt.xticks(rotation=30, ha="right", fontsize=7); plt.tight_layout(); plt.savefig(OUT + "figures/F2_wide_search.png", dpi=160); plt.close()
json.dump(dict(configs=len(CONFIGS), best=RES.iloc[0][["features", "learner", "Accuracy", "AUROC"]].to_dict(), any_meets_93=bool(RES.meets_93pct.any()), nested=NEST,
               minutes=round((time.time() - T0) / 60, 1)), open(OUT + "run_log_widesearch.json", "w"), indent=2, default=str)
say("DONE")
