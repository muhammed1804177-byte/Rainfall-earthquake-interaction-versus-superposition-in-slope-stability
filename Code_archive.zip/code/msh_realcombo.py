"""
REAL-WORLD PROGRESSIVE COMBINATIONS (3 -> 20 experts), 120,000 SVA slopes + all real slopes in EVERY combination.

Per combination C (a subset of the 20 experts):
  layer 1  the experts in C (trained on the 120,000 SVA slopes only) predict FoS for each real slope (zero-shot)
  layer 2  physics-guided fusion: non-negative stacking weights for C fitted on SVA VALIDATION slopes (no real data)
  layer 3  real-world adaptation: a monotone-constrained gradient-boosting classifier trained on REAL slopes, inputs =
           six measured properties + dimensionless physics features + fused FoS + the experts' FoS predictions
           (monotone: P(fail) rises with H, beta, r_u; falls with c, phi, N, FS_inf and every predicted FoS)
Evaluation: 5x repeated StratifiedGroupKFold(5) on all real slopes (near-duplicate groups never split).
Selection bias: every subset in the pre-registered pool is scored with the same CV (each score unbiased); the "best
of all subsets" is additionally estimated with NESTED CV (selection inside the outer training folds only).
Benchmark: accuracy >= 0.93 on real slopes (reported as met / not met, never forced).
Baselines: real-only model (no SVA experts) and physics-only (infinite-slope FS).
"""
import os, sys, json, time, warnings
import numpy as np, pandas as pd, joblib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import msh_unified as U
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import xgboost as xgb
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, roc_auc_score, average_precision_score, f1_score, precision_score, recall_score,
                             brier_score_loss, matthews_corrcoef)
warnings.filterwarnings("ignore")
SMOKE = U.SMOKE
OUT = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/smokeR/") if SMOKE else (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/")
CK = OUT + "ck/" if SMOKE else (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptR/")
for p in (OUT, OUT + "figures", CK): os.makedirs(p, exist_ok=True)
RS = 42; T0 = time.time(); REPS = 1 if SMOKE else 5; NRAND = 3 if SMOKE else 15; TARGET = .93
def say(*a): print(f"[R {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): say(f"  [cache] {name}"); return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r

# ---------------------------------------------------------------- real slopes: all available case histories (+ optional uploads)
real = U.real.copy()
extra = (__import__("os").environ.get("MSH_DATA", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/data") + "/real_world_events.csv")          # optional: user-supplied events with the six properties + fail
if os.path.exists(extra):
    e = pd.read_csv(extra); e = e[U.F6 + ["fail"]].dropna(); e["location"] = "uploaded"; real = pd.concat([real, e], ignore_index=True)
    real[U.F6] = real[U.F6].round(2); real = real.drop_duplicates(subset=U.F6).reset_index(drop=True)
kq = pd.DataFrame(dict(a=real.SlopeHeight_m.round(0), b=real.SlopeAngle_deg.round(0), c=(real.UnitWeight_kN_m3 * 2).round(), d=real.Cohesion_kPa.round(0),
                       e=real.FrictionAngle_deg.round(0), f=(real.PorePressureRatio * 20).round()))
real["group"] = pd.factorize(kq.astype(str).agg("|".join, axis=1))[0]
y, G = real.fail.values.astype(int), real.group.values
say(f"real slopes: {len(real)} ({y.sum()} failed / {(1-y).sum()} stable), {real.group.nunique()} near-duplicate groups")

# ---------------------------------------------------------------- 20 experts (17 generalists + 3 hazard specialists)
def regime(A, Q):
    wet = A.PorePressureRatio.values >= Q["ru75"]; dry = A.PorePressureRatio.values < Q["ru50"]
    eq = A.SeismicCoefficient.values >= Q["kh75"]; calm = A.SeismicCoefficient.values < Q["kh50"]
    return np.select([wet & eq, wet & calm, eq & dry], ["compound", "rainfall", "seismic"], "other")
A_tr = U.TR["A"].iloc[:U.TR["nS"]]
Q = dict(ru75=A_tr.PorePressureRatio.quantile(.75), ru50=A_tr.PorePressureRatio.quantile(.5), kh75=A_tr.SeismicCoefficient.quantile(.75), kh50=A_tr.SeismicCoefficient.quantile(.5))
def specialist(reg):
    w = U.TR["w"].copy(); w[:U.TR["nS"]] *= np.where(regime(A_tr, Q) == reg, 5., 1.); return U.fit_xgb(U.TR["A"], dict(U.TR, w=w), Dv=U.VA)
ORIG = {n.lstrip("_"): n for n in U.BASE}
FN = {n: U.PRED[o] for n, o in ORIG.items()}
for reg, nm in [("rainfall", "S-R Rainfall specialist"), ("seismic", "S-S Seismic specialist"), ("compound", "S-C Compound specialist")]:
    m = cached("spec_" + reg, lambda reg=reg: specialist(reg)); FN[nm] = (lambda A, m=m: U.xgb_pred(m, A[U.FEATS]))
EXPERTS = list(FN); assert len(EXPERTS) == 20
A_real = U.real_matrix(real)
P_real = cached("P_real", lambda: {n: FN[n](A_real) for n in EXPERTS})          # zero-shot FoS of every expert, every real slope
P_val = cached("P_val", lambda: {n: FN[n](U.VA["A"]) for n in EXPERTS})         # SVA validation (for fusion weights + greedy order)
yV = U.VA["lo"][:U.VA["nS"]]

# ---------------------------------------------------------------- features of the real-world adaptation layer
def physics(df):
    b, p = np.radians(np.clip(df.SlopeAngle_deg, 1, 89)), np.radians(df.FrictionAngle_deg); H = df.SlopeHeight_m.clip(lower=.01); g = df.UnitWeight_kN_m3.clip(lower=.1)
    N = df.Cohesion_kPa / (g * H); Fr = np.tan(p) / np.tan(b); FS = N / (np.sin(b) * np.cos(b)) + (1 - df.PorePressureRatio) * Fr
    return pd.DataFrame(dict(N=N, Fr=Fr, FSinf=np.clip(FS, 0, 50)))
PHY = physics(real)
BASEF = pd.concat([real[U.F6].reset_index(drop=True), PHY], axis=1)
MONO_BASE = [1, 1, 0, -1, -1, 1, -1, -1, -1]                     # H, beta, gamma, c, phi, ru, N, Fr, FSinf  (+1 = raises P(fail))
def fused_weights(cols):
    X = np.column_stack([P_val[c] for c in cols]); return U.fit_ridge(X, U.VA_M)  # SVA-only, non-negative stacking
def design(cols, mdl):
    fused = mdl.predict(np.column_stack([P_real[c] for c in cols]))
    X = BASEF.copy(); X["fused_FoS"] = np.log(np.clip(fused, .2, 6))
    for c in cols: X["E:" + c] = np.log(np.clip(P_real[c], .2, 6))
    mono = MONO_BASE + [-1] * (1 + len(cols)); return X.values, "(" + ",".join(map(str, mono)) + ")", fused
def clf(mono): return xgb.XGBClassifier(n_estimators=200, max_depth=3, learning_rate=.05, subsample=.8, colsample_bytree=.8, min_child_weight=2,
                                        monotone_constraints=mono, random_state=RS, eval_metric="logloss")
FOLDS = [list(StratifiedGroupKFold(5, shuffle=True, random_state=r).split(BASEF, y, G)) for r in range(REPS)]
def ece(yy, p, bins=10):
    e, ed = 0., np.linspace(0, 1, bins + 1)
    for a, b in zip(ed[:-1], ed[1:]):
        m = (p >= a) & ((p < b) if b < 1 else (p <= b))
        if m.any(): e += m.mean() * abs(yy[m].mean() - p[m].mean())
    return e
def cv_eval(X, mono):
    """repeated grouped CV -> pooled out-of-fold metrics (mean over repeats) + per-repeat accuracy"""
    accs, rows = [], []
    for folds in FOLDS:
        p = np.zeros(len(y))
        for a, b in folds: p[b] = clf(mono).fit(X[a], y[a]).predict_proba(X[b])[:, 1]
        rows.append(dict(Accuracy=accuracy_score(y, p > .5), AUROC=roc_auc_score(y, p), AUPRC=average_precision_score(y, p), F1=f1_score(y, p > .5),
                         Precision=precision_score(y, p > .5), Recall=recall_score(y, p > .5), MCC=matthews_corrcoef(y, p > .5), Brier=brier_score_loss(y, p), ECE=ece(y, p)))
    d = pd.DataFrame(rows); out = d.mean().to_dict(); out["Accuracy_sd"] = d.Accuracy.std(); out["Accuracy_min_repeat"] = d.Accuracy.min(); return out

# ---------------------------------------------------------------- baselines
say("baselines")
BL = {}
BL["Physics only (infinite-slope FS < 1)"] = dict(Accuracy=accuracy_score(y, PHY.FSinf.values < 1), AUROC=roc_auc_score(y, -PHY.FSinf.values))
BL["Real data only (monotone XGB on 6 properties + physics features, NO SVA experts)"] = cv_eval(BASEF.values, "(" + ",".join(map(str, MONO_BASE)) + ")")
for n in ["XGBoost", "M1 CNN-BiLSTM-SE-Attention", "N1 PLE-ResNet-Attention"]:
    BL[f"Zero-shot SVA expert {n} (FoS<1, no real data)"] = dict(Accuracy=accuracy_score(y, P_real[n] < 1), AUROC=roc_auc_score(y, -P_real[n]))
pd.DataFrame(BL).T.round(4).to_csv(OUT + "T0_baselines.csv"); say("\n" + pd.DataFrame(BL).T[["Accuracy", "AUROC"]].round(3).to_string())

# ---------------------------------------------------------------- pre-registered subset pool (defined WITHOUT real data)
GROUP = {}
for n in EXPERTS:                                                   # hazard group from SVA validation regime skill
    reg = regime(U.VA["A"].iloc[:U.VA["nS"]], Q); r = {g: np.sqrt(np.mean((np.clip(P_val[n][:len(yV)], .25, 5)[reg == g] - yV[reg == g]) ** 2)) for g in ["rainfall", "seismic", "compound"]}
    med = {g: np.median([np.sqrt(np.mean((np.clip(P_val[m][:len(yV)], .25, 5)[reg == g] - yV[reg == g]) ** 2)) for m in EXPERTS]) for g in r}
    rel = {g: r[g] / med[g] for g in r}; g0 = min(rel, key=rel.get); GROUP[n] = g0 + "-focused" if rel[g0] < .97 else "generalist"
val_rmse = {n: np.sqrt(np.mean((np.clip(P_val[n][:len(yV)], .25, 5) - yV) ** 2)) for n in EXPERTS}
order = sorted(EXPERTS, key=val_rmse.get)                           # greedy-by-SVA-validation order (real-data independent)
rng = np.random.default_rng(RS); POOL = []
for k in range(3, 21):
    POOL.append((k, "SVA-greedy", tuple(order[:k])))
    groups = sorted(set(GROUP.values()))
    for i in range(NRAND if k < 20 else 0):
        first = [rng.choice([e for e in EXPERTS if GROUP[e] == g]) for g in rng.permutation(groups)][:k]
        rest = [e for e in EXPERTS if e not in first]; POOL.append((k, "hazard-balanced random", tuple(sorted(list(first) + list(rng.choice(rest, k - len(first), replace=False))))))
POOL = list(dict.fromkeys(POOL)); say(f"pool: {len(POOL)} pre-registered combinations (k = 3..20)")

# ---------------------------------------------------------------- evaluate every combination
def run_pool():
    rows = []
    for i, (k, how, cols) in enumerate(POOL):
        mdl = fused_weights(list(cols)); X, mono, fused = design(list(cols), mdl)
        r = cv_eval(X, mono); r.update(k=k, how=how, members=" | ".join(cols), zero_shot_fused_acc=accuracy_score(y, fused < 1), zero_shot_fused_auc=roc_auc_score(y, -fused))
        rows.append(r)
        if i % 20 == 0: say(f"  {i+1}/{len(POOL)}  k={k}  acc={r['Accuracy']:.3f}  auc={r['AUROC']:.3f}")
    return pd.DataFrame(rows)
RESP = cached("pool", run_pool); RESP["meets_93pct"] = RESP.Accuracy >= TARGET
RESP.sort_values("Accuracy", ascending=False).round(4).to_csv(OUT + "T1_all_combinations_realworld_CV.csv", index=False)
byk = RESP.groupby("k").agg(best_acc=("Accuracy", "max"), median_acc=("Accuracy", "median"), best_auc=("AUROC", "max"), n=("Accuracy", "size"),
                            n_meeting_93=("meets_93pct", "sum")); byk.round(4).to_csv(OUT + "T2_accuracy_by_k.csv")

# ---------------------------------------------------------------- nested CV: unbiased estimate of "pick the best combination"
say("nested CV of the selection procedure")
def nested():
    accs, aucs, chosen = [], [], []
    designs = {}
    for k, how, cols in POOL:
        mdl = fused_weights(list(cols)); designs[(k, how, cols)] = design(list(cols), mdl)[:2]
    for rep, folds in enumerate(FOLDS):
        p = np.zeros(len(y))
        for a, b in folds:
            inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=rep).split(a, y[a], G[a])); best, bs = None, -1
            for key, (X, mono) in designs.items():          # inner selection with a fast scorer (scaled logistic)
                s = []
                for ia, ib in inner:
                    sc = StandardScaler().fit(X[a][ia]); lr = LogisticRegression(max_iter=500).fit(sc.transform(X[a][ia]), y[a][ia])
                    s.append(accuracy_score(y[a][ib], lr.predict(sc.transform(X[a][ib]))))
                if np.mean(s) > bs: best, bs = key, np.mean(s)
            X, mono = designs[best]; p[b] = clf(mono).fit(X[a], y[a]).predict_proba(X[b])[:, 1]; chosen.append(best[0])
        accs.append(accuracy_score(y, p > .5)); aucs.append(roc_auc_score(y, p))
    return dict(nested_accuracy_mean=float(np.mean(accs)), nested_accuracy_sd=float(np.std(accs)), nested_AUROC_mean=float(np.mean(aucs)),
                chosen_k_distribution=pd.Series(chosen).value_counts().to_dict())
NEST = cached("nested", nested); say("  nested:", NEST)

# ---------------------------------------------------------------- explicit REAL VALIDATION split (grouped 60/20/20)
say("explicit real train / real validation / real test split")
def explicit_split():
    f5 = list(StratifiedGroupKFold(5, shuffle=True, random_state=RS).split(BASEF, y, G))
    te, va = f5[0][1], f5[1][1]; tr = np.setdiff1d(np.arange(len(y)), np.r_[te, va]); rows = []
    for k, how, cols in POOL:
        mdl = fused_weights(list(cols)); X, mono, _ = design(list(cols), mdl); m = clf(mono).fit(X[tr], y[tr])
        pv, pt = m.predict_proba(X[va])[:, 1], m.predict_proba(X[te])[:, 1]
        rows.append(dict(k=k, how=how, members=" | ".join(cols), real_VAL_accuracy=accuracy_score(y[va], pv > .5), real_VAL_AUROC=roc_auc_score(y[va], pv),
                         real_TEST_accuracy=accuracy_score(y[te], pt > .5), real_TEST_AUROC=roc_auc_score(y[te], pt), real_TEST_F1=f1_score(y[te], pt > .5)))
    Xb = BASEF.values; mb = clf("(" + ",".join(map(str, MONO_BASE)) + ")").fit(Xb[tr], y[tr])
    base = dict(real_VAL_accuracy=accuracy_score(y[va], mb.predict(Xb[va])), real_TEST_accuracy=accuracy_score(y[te], mb.predict(Xb[te])))
    return dict(rows=rows, n=dict(train=len(tr), val=len(va), test=len(te)), real_only=base)
EX = cached("explicit", explicit_split); EXD = pd.DataFrame(EX["rows"])
EXD.sort_values("real_VAL_accuracy", ascending=False).round(4).to_csv(OUT + "T3_realVAL_realTEST_explicit_split.csv", index=False)
sel_k = EXD.loc[EXD.groupby("k").real_VAL_accuracy.idxmax()].set_index("k")[["members", "real_VAL_accuracy", "real_TEST_accuracy", "real_TEST_AUROC"]]
sel_k.round(4).to_csv(OUT + "T4_best_per_k_chosen_on_real_validation.csv")
chosen = EXD.loc[EXD.real_VAL_accuracy.idxmax()]
EXPL = dict(split=EX["n"], chosen_on_real_validation=dict(k=int(chosen.k), members=chosen.members, real_VAL_accuracy=float(chosen.real_VAL_accuracy),
            real_TEST_accuracy=float(chosen.real_TEST_accuracy), real_TEST_AUROC=float(chosen.real_TEST_AUROC), meets_93_on_test=bool(chosen.real_TEST_accuracy >= TARGET)),
            real_only_baseline=EX["real_only"]); say("  explicit split:", EXPL["chosen_on_real_validation"])

# ---------------------------------------------------------------- figure + log
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.scatter(RESP.k, RESP.Accuracy, s=10, alpha=.4, c="gray", label="each combination (grouped repeated CV)")
ax.plot(byk.index, byk.best_acc, "o-", c="#c44e52", label="best combination per k (selection-biased)")
ax.plot(byk.index, byk.median_acc, "s--", c="#4c72b0", label="median combination per k")
ax.axhline(TARGET, c="k", ls=":", label="93 % target"); ax.axhline(NEST["nested_accuracy_mean"], c="#55a868", ls="-.", label=f"nested CV (unbiased) {NEST['nested_accuracy_mean']:.3f}")
ax.axhline(BL["Real data only (monotone XGB on 6 properties + physics features, NO SVA experts)"]["Accuracy"], c="orange", ls="--", label="real-only (no 120k experts)")
ax.set(xlabel="number of experts k", ylabel=f"accuracy on {len(y)} real slopes", title="Real-world accuracy of progressive combinations", xticks=range(3, 21))
ax.legend(fontsize=7, loc="lower right"); plt.tight_layout(); plt.savefig(OUT + "figures/F1_realworld_accuracy_vs_k.png", dpi=160); plt.close()
best = RESP.sort_values("Accuracy", ascending=False).iloc[0]
json.dump(dict(real_slopes=int(len(y)), groups=int(real.group.nunique()), pool=len(POOL), any_combination_meets_93=bool(RESP.meets_93pct.any()),
               best_combination=dict(k=int(best.k), accuracy=float(best.Accuracy), auroc=float(best.AUROC), members=best.members),
               nested=NEST, explicit_real_validation=EXPL, expert_groups=GROUP, minutes=round((time.time() - T0) / 60, 1)), open(OUT + "run_log.json", "w"), indent=2, default=str)
say("DONE")
