"""
Progressive 3 -> 20 combinations, re-run with the best real-world adaptation layer from the wide search (LightGBM).
Combination input = 6 properties + physics features + fused FoS of the k experts (each trained on 120,000 SVA slopes).
Same 270 pre-registered combinations as msh_realcombo.py, 5x repeated grouped 5-fold CV, nested CV for selection.
"""
import json, time, warnings, os
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import lightgbm as lgb
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, average_precision_score
warnings.filterwarnings("ignore")
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realboost.py")).read().split("# ---------------- feature sets")[0])      # identical real-slope construction
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/"); CK = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptR/"); T0 = time.time(); TARGET = .93
__import__("os").makedirs(CK, exist_ok=True); __import__("os").makedirs(OUT + "figures", exist_ok=True)
def say(*a): print(f"[C {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
b, p = np.radians(np.clip(real.SlopeAngle_deg, 1, 89)), np.radians(real.FrictionAngle_deg)
H, g, c, ru = real.SlopeHeight_m, real.UnitWeight_kN_m3, real.Cohesion_kPa, real.PorePressureRatio
PHY = pd.DataFrame(dict(N=c / (g * H), Fr=np.tan(p) / np.tan(b), FSinf=np.clip(c / (g * H * np.sin(b) * np.cos(b)) + (1 - ru) * np.tan(p) / np.tan(b), 0, 50),
                        lam=np.log1p(g * H * np.tan(p) / (c + .1)), logH=np.log(H), effphi=np.tan(p) * (1 - ru)))
BASE = pd.concat([real[F6], PHY], axis=1).values
E = {e: np.log(np.clip(P[e], .2, 6)) for e in P}
POOL = pd.read_csv(OUT + "T1_all_combinations_realworld_CV.csv")[["k", "how", "members"]]
def lgbm(): return lgb.LGBMClassifier(n_estimators=300, num_leaves=15, learning_rate=.05, subsample=.8, subsample_freq=1, colsample_bytree=.8, min_child_samples=10, verbose=-1, random_state=RS)
def X_of(members): return np.c_[BASE, np.mean([E[m] for m in members.split(" | ")], 0)]
FOLDS = [list(StratifiedGroupKFold(5, shuffle=True, random_state=r).split(BASE, y, G)) for r in range(5)]
f_res = CK + "combo2.joblib"
if os.path.exists(f_res): rows = joblib.load(f_res)
else:
    rows = []
    for i, r in POOL.iterrows():
        X = X_of(r.members); acc, auc, f1, ap = [], [], [], []
        for folds in FOLDS:
            pp = np.zeros(len(y))
            for a, b_ in folds: pp[b_] = lgbm().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]
            acc.append(accuracy_score(y, pp > .5)); auc.append(roc_auc_score(y, pp)); f1.append(f1_score(y, pp > .5)); ap.append(average_precision_score(y, pp))
        rows.append(dict(k=r.k, how=r.how, members=r.members, Accuracy=np.mean(acc), Accuracy_sd=np.std(acc), AUROC=np.mean(auc), F1=np.mean(f1), AUPRC=np.mean(ap)))
        if i % 30 == 0: say(f"  {i+1}/{len(POOL)} k={r.k} acc {rows[-1]['Accuracy']:.3f}")
    joblib.dump(rows, f_res)
D = pd.DataFrame(rows); D["meets_93pct"] = D.Accuracy >= TARGET
D.sort_values("Accuracy", ascending=False).round(4).to_csv(OUT + "T7_progressive_combinations_LightGBM_layer.csv", index=False)
byk = D.groupby("k").agg(best_acc=("Accuracy", "max"), median_acc=("Accuracy", "median"), worst_acc=("Accuracy", "min"), best_auc=("AUROC", "max"), n=("Accuracy", "size"),
                         n_meeting_93=("meets_93pct", "sum")); byk.round(4).to_csv(OUT + "T8_accuracy_by_k_LightGBM_layer.csv"); say("\n" + byk.round(4).to_string())
# real-only reference with the same learner
acc0 = []
for folds in FOLDS:
    pp = np.zeros(len(y))
    for a, b_ in folds: pp[b_] = lgbm().fit(BASE[a], y[a]).predict_proba(BASE[b_])[:, 1]
    acc0.append(accuracy_score(y, pp > .5))
# nested selection over all 270 combinations
f_n = CK + "combo2_nested.joblib"
if os.path.exists(f_n): NEST = joblib.load(f_n)
else:
    accs, picks = [], []
    Xs = {r.members: X_of(r.members) for r in POOL.itertuples()}
    for rep in range(2):
        pp = np.zeros(len(y))
        for a, b_ in FOLDS[rep]:
            inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=200 + rep).split(a, y[a], G[a])); best, bs = None, -1
            for mem, X in Xs.items():
                s = np.mean([accuracy_score(y[a][ib], lgbm().fit(X[a][ia], y[a][ia]).predict(X[a][ib])) for ia, ib in inner])
                if s > bs: best, bs = mem, s
            picks.append(len(best.split(" | "))); pp[b_] = lgbm().fit(Xs[best][a], y[a]).predict_proba(Xs[best][b_])[:, 1]
        accs.append(accuracy_score(y, pp > .5)); say(f"  nested repeat {rep+1}: {accs[-1]:.3f}")
    NEST = dict(nested_accuracy=float(np.mean(accs)), nested_sd=float(np.std(accs)), chosen_k=pd.Series(picks).value_counts().to_dict()); joblib.dump(NEST, f_n)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.scatter(D.k, D.Accuracy, s=10, c="gray", alpha=.4, label="each combination"); ax.plot(byk.index, byk.best_acc, "o-", c="#c44e52", label="best per k (selection-biased)")
ax.plot(byk.index, byk.median_acc, "s--", label="median per k"); ax.axhline(np.mean(acc0), c="orange", ls="--", label=f"real-only LightGBM {np.mean(acc0):.3f}")
ax.axhline(NEST["nested_accuracy"], c="g", ls="-.", label=f"nested (unbiased) {NEST['nested_accuracy']:.3f}"); ax.axhline(TARGET, c="k", ls=":", label="93 % target")
ax.set(xlabel="number of experts k", ylabel="accuracy on 363 real slopes", title="Progressive 3->20 combinations, LightGBM real-world layer", xticks=range(3, 21), ylim=(.7, .96))
ax.legend(fontsize=7); plt.tight_layout(); plt.savefig(OUT + "figures/F3_progressive_LightGBM_layer.png", dpi=160); plt.close()
json.dump(dict(real_only_accuracy=float(np.mean(acc0)), nested=NEST, best=D.sort_values("Accuracy").iloc[-1][["k", "members", "Accuracy", "AUROC"]].to_dict(),
               any_meets_93=bool(D.meets_93pct.any())), open(OUT + "run_log_combo2.json", "w"), indent=2, default=str)
say("DONE")
