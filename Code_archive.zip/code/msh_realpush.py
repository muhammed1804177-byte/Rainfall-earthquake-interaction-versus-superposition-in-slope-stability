"""
Real-world accuracy push. Every configuration contains ALL 20 expert models (trained on 120,000 SVA slopes),
a new physics model (Bishop simplified LEM FoS per real slope) and new learners (CatBoost, ensembles).
Leakage-free: grouped (near-duplicate) folds; thresholds and configuration chosen inside training folds only.
"""
import os, json, time, warnings, sys
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import lightgbm as lgb, xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, average_precision_score
warnings.filterwarnings("ignore"); sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from bishop import bishop_fos
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realboost.py")).read().split("# ---------------- feature sets")[0])
OUT = (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/"); CK = (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptR/"); T0 = time.time(); TARGET = .93
__import__("os").makedirs(CK, exist_ok=True); __import__("os").makedirs(OUT + "figures", exist_ok=True)
def say(*a): print(f"[P {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
f_b = CK + "bishop_real.joblib"
if os.path.exists(f_b): BIS = joblib.load(f_b)
else:
    BIS = np.array([bishop_fos(r.SlopeHeight_m, r.SlopeAngle_deg, r.Cohesion_kPa, r.FrictionAngle_deg, r.UnitWeight_kN_m3, r.PorePressureRatio) for r in real.itertuples()])
    joblib.dump(BIS, f_b)
say(f"Bishop FoS computed for {len(BIS)} real slopes; zero-shot accuracy (FoS<1) = {accuracy_score(y, BIS < 1):.3f}, AUROC = {roc_auc_score(y, -BIS):.3f}")
b, p = np.radians(np.clip(real.SlopeAngle_deg, 1, 89)), np.radians(real.FrictionAngle_deg)
H, g, c, ru = real.SlopeHeight_m, real.UnitWeight_kN_m3, real.Cohesion_kPa, real.PorePressureRatio
PHY = pd.DataFrame(dict(N=c / (g * H), Fr=np.tan(p) / np.tan(b), FSinf=np.clip(c / (g * H * np.sin(b) * np.cos(b)) + (1 - ru) * np.tan(p) / np.tan(b), 0, 50),
                        lam=np.log1p(g * H * np.tan(p) / (c + .1)), logH=np.log(H), effphi=np.tan(p) * (1 - ru), bishop=np.log(np.clip(BIS, .05, 50))))
E = pd.DataFrame({e: np.log(np.clip(P[e], .2, 6)) for e in P}); assert E.shape[1] == 20
A = pd.concat([real[F6], PHY], axis=1)
FS = {"6 props + physics + Bishop + ALL-20 fused": pd.concat([A, E.mean(1).rename("fused20")], axis=1),
      "6 props + physics + Bishop + ALL-20 summary": pd.concat([A, E.mean(1).rename("m"), E.min(1).rename("mn"), E.max(1).rename("mx"), E.std(1).rename("sd")], axis=1),
      "6 props + physics + Bishop + ALL-20 individual": pd.concat([A, E], axis=1),
      "6 props + physics + Bishop + ALL-20 fused x Bishop": pd.concat([A, E.mean(1).rename("fused20"), (E.mean(1) - PHY.bishop).rename("expert_minus_bishop")], axis=1)}
FS = {k: v.values.astype(float) for k, v in FS.items()}
REF = {"6 props + physics + Bishop (no experts, reference)": A.values.astype(float), "6 props + physics (no Bishop, no experts, reference)": A.drop(columns="bishop").values.astype(float)}
LEARN = {
    "CatBoost": lambda: CatBoostClassifier(iterations=500, depth=4, learning_rate=.05, l2_leaf_reg=3, verbose=0, random_seed=RS),
    "LightGBM": lambda: lgb.LGBMClassifier(n_estimators=300, num_leaves=15, learning_rate=.05, subsample=.8, subsample_freq=1, colsample_bytree=.8, min_child_samples=10, verbose=-1, random_state=RS),
    "XGBoost": lambda: xgb.XGBClassifier(n_estimators=300, max_depth=3, learning_rate=.05, subsample=.8, colsample_bytree=.8, random_state=RS, eval_metric="logloss"),
    "RandomForest": lambda: RandomForestClassifier(300, min_samples_leaf=2, random_state=RS, n_jobs=-1),
    "ExtraTrees": lambda: ExtraTreesClassifier(300, min_samples_leaf=2, random_state=RS, n_jobs=-1),
    "GaussianProcess": lambda: make_pipeline(StandardScaler(), GaussianProcessClassifier(ConstantKernel() * RBF(), random_state=RS)),
}
class Vote:
    def __init__(s, names): s.names = names
    def fit(s, X, yy): s.m = [LEARN[n]().fit(X, yy) for n in s.names]; return s
    def predict_proba(s, X): return np.mean([m.predict_proba(X) for m in s.m], 0)
for nm in (["CatBoost", "LightGBM"], ["CatBoost", "LightGBM", "XGBoost", "RandomForest"], ["CatBoost", "XGBoost", "RandomForest", "GaussianProcess"]):
    LEARN["Vote(" + "+".join(nm) + ")"] = (lambda nm=nm: Vote(nm))
FOLDS = [list(StratifiedGroupKFold(5, shuffle=True, random_state=r).split(A, y, G)) for r in range(5)]
def oof(X, l, folds):
    pp = np.zeros(len(y))
    for a, b_ in folds: pp[b_] = LEARN[l]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]
    return pp
f_r = CK + "push_configs.joblib"
RES = joblib.load(f_r) if os.path.exists(f_r) else []
done = {(r["features"], r["learner"]) for r in RES}
for fname, X in {**FS, **REF}.items():
    for l in LEARN:
        if (fname, l) in done: continue
        acc, auc = [], []
        for folds in FOLDS: pp = oof(X, l, folds); acc.append(accuracy_score(y, pp > .5)); auc.append(roc_auc_score(y, pp))
        RES.append(dict(features=fname, learner=l, all20_included=fname in FS, Accuracy=np.mean(acc), Accuracy_sd=np.std(acc), AUROC=np.mean(auc)))
        joblib.dump(RES, f_r); say(f"  {fname[:44]:44s} {l[:34]:34s} acc {RES[-1]['Accuracy']:.3f} auc {RES[-1]['AUROC']:.3f}")
D = pd.DataFrame(RES).sort_values("Accuracy", ascending=False); D["meets_93pct"] = D.Accuracy >= TARGET
D.round(4).to_csv(OUT + "T9_push_all20_bishop_catboost.csv", index=False)

# nested CV: configuration AND decision threshold selected inside the outer-training folds (ALL-20 configurations only)
say("nested CV (configuration + threshold chosen inside training folds)")
f_n = CK + "push_nested.joblib"
if os.path.exists(f_n): NEST = joblib.load(f_n)
else:
    accs, aucs, picks = [], [], []
    CANDS = [(f, l) for f in FS for l in LEARN]
    for rep in range(2):
        pp, thr = np.zeros(len(y)), np.zeros(len(y))
        for a, b_ in FOLDS[rep]:
            inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=300 + rep).split(a, y[a], G[a])); best, bs, bt = None, -1, .5
            for f, l in CANDS:
                X = FS[f][a]; po = np.zeros(len(a))
                for ia, ib in inner: po[ib] = LEARN[l]().fit(X[ia], y[a][ia]).predict_proba(X[ib])[:, 1]
                ts = np.linspace(.3, .7, 41); sc = [accuracy_score(y[a], po > t) for t in ts]; j = int(np.argmax(sc))
                if sc[j] > bs: best, bs, bt = (f, l), sc[j], ts[j]
            picks.append(f"{best[0]} | {best[1]} | thr={bt:.2f}")
            pp[b_] = LEARN[best[1]]().fit(FS[best[0]][a], y[a]).predict_proba(FS[best[0]][b_])[:, 1]; thr[b_] = bt
        accs.append(accuracy_score(y, pp > thr)); aucs.append(roc_auc_score(y, pp)); say(f"  nested repeat {rep+1}: acc {accs[-1]:.3f} auc {aucs[-1]:.3f}")
    NEST = dict(nested_accuracy=float(np.mean(accs)), nested_sd=float(np.std(accs)), nested_AUROC=float(np.mean(aucs)), picks=pd.Series(picks).value_counts().to_dict())
    joblib.dump(NEST, f_n)
say("  nested:", {k: v for k, v in NEST.items() if k != "picks"})
fig, ax = plt.subplots(figsize=(9, 5)); d = D.copy(); d["label"] = d.learner.str[:22] + " | " + d.features.str.replace("6 props + physics", "").str[:30]
d.head(20).iloc[::-1].plot.barh(x="label", y="Accuracy", ax=ax, legend=False, color=["#c44e52" if a else "#8c8c8c" for a in d.head(20).iloc[::-1].all20_included])
ax.axvline(TARGET, c="k", ls=":"); ax.axvline(NEST["nested_accuracy"], c="g", ls="--"); ax.set_xlim(.75, .95)
ax.set(xlabel="accuracy on 363 real slopes (grouped 5x5 CV); red = includes all 20 models; dashed = nested estimate; dotted = 93 %", ylabel="")
plt.yticks(fontsize=7); plt.tight_layout(); plt.savefig(OUT + "figures/F4_push_top20.png", dpi=160); plt.close()
json.dump(dict(bishop_zero_shot=dict(acc=float(accuracy_score(y, BIS < 1)), auc=float(roc_auc_score(y, -BIS))), best=D.iloc[0][["features", "learner", "Accuracy", "AUROC"]].to_dict(),
               any_meets_93=bool(D.meets_93pct.any()), nested=NEST), open(OUT + "run_log_push.json", "w"), indent=2, default=str)
say("DONE")
