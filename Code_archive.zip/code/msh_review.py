"""Editorial-review analyses (R-series). Run after the full pipeline and the mechanics extension.
R1 paired statistical comparison of the final framework with every model (Diebold-Mariano, paired bootstrap, Holm)
R2 residual analysis by scenario family, FoS band and class (bias, RMSE, P95 error, heteroscedasticity, confusion)
R3 input-noise robustness (realistic site-characterisation error, 3 levels)
R4 missing-feature robustness (feature imputed by the training median)
R6 ICE / partial dependence on kh and r_u vs mechanics
R7 counterfactual remediation on the mechanics-verified benchmark (drainage / regrading to reach a target FoS)
R8 real-world probability calibration and decision cost (363 case histories, 5 grouped-CV repeats)
R9 expert redundancy (residual correlation clustering) -> pruned benchmarking hierarchy
Test set used for evaluation only; nothing is selected on it."""
import os, sys, time, json, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import msh_monotone as MO
import msh_mechanics as ME
from scipy import stats
from sklearn.metrics import r2_score, accuracy_score, f1_score, roc_auc_score, brier_score_loss, confusion_matrix
FW, U = MO.FW, MO.FW.U
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUT = ROOT + "/review_results/"; os.makedirs(OUT, exist_ok=True)
WK = os.environ.get("MSH_WORK", ROOT + "/.work"); CK = WK + "/review/"; os.makedirs(CK, exist_ok=True)
T0 = time.time()
def say(*a): print(f"[REV {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(n, fn):
    f = CK + n + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
rmse = lambda y, p: float(np.sqrt(np.mean((y - p) ** 2)))
cls = U.to_class
Ate = U.TS["A"].reset_index(drop=True); y = FW.y_te
assert np.allclose(y, U.sva.FoS.values[U.s_te]), "test labels misaligned"
kh_te = Ate.SeismicCoefficient.values
FAM = np.select([kh_te < .03, kh_te < .10, kh_te < .1201], ["F1 low", "F2 moderate", "F3 elevated"], "F4 extreme compound")

# ---------------------------------------------------------------- predictions
MECH = ["SlopeHeight_m", "SlopeAngle_deg", "Cohesion_kPa", "FrictionAngle_deg", "UnitWeight_kN_m3", "PorePressureRatio", "SeismicCoefficient"]
ENV = [c for c in U.FEATS if c not in MECH + ["StabilityNumber_N", "FrictionRatio", "FS_infinite"]]
MAH = joblib.load(ME.CK + "mah_models.joblib"); A_, D_ = "A data-only LightGBM", "D anchored calibration (environment inputs only)"
WS = float(open(ROOT + "/mechanics_results/M8d_selected_blend.txt").read().split("\n")[0].split("=")[1])
def prior(A):
    d = pd.DataFrame(A[MECH].values, columns=ME.COLS)
    for i, k in enumerate(ME.COLS): d[k] = d[k].clip(ME.LO[i], ME.HI[i])
    return np.log(np.clip(ME.pred(ME.BEST, ME.feats(d)), .05, 20))
def lgbm(A): return np.clip(MAH[A_].predict(A[U.FEATS]), .05, 20)
def mah(A): return np.exp(WS * np.log(lgbm(A)) + (1 - WS) * (prior(A) + MAH[D_].predict(A[ENV])))
def mech(A):
    d = pd.DataFrame(A[MECH].values, columns=ME.COLS)
    for i, k in enumerate(ME.COLS): d[k] = d[k].clip(ME.LO[i], ME.HI[i])
    return ME.pred(ME.BEST, ME.feats(d))
P = cached("test_preds", lambda: {"Proposed framework": MO.fw(Ate), "Mechanics-anchored hybrid (w=%.2f)" % WS: mah(Ate)})
PT = joblib.load(WK + "/ckptF/PT.joblib"); PT = {k: v for k, v in PT.items()}
ALL = {**P, **PT}
say("predictions ready:", len(ALL))

# ---------------------------------------------------------------- R1 paired statistics
def r1():
    ref = np.clip(ALL["Proposed framework"], .25, 5); e0 = (ref - y) ** 2; n = len(y); rng = np.random.default_rng(0)
    B = rng.integers(0, n, (2000, n)); rows = []
    for k, p in ALL.items():
        if k == "Proposed framework": continue
        p = np.clip(p, .25, 5); e1 = (p - y) ** 2; d = e1 - e0
        dm = d.mean() / (d.std(ddof=1) / np.sqrt(n)); pdm = 2 * (1 - stats.norm.cdf(abs(dm)))
        dr = np.sqrt(e1[B].mean(1)) - np.sqrt(e0[B].mean(1))
        w = stats.wilcoxon(np.abs(p - y), np.abs(ref - y)).pvalue
        rows.append(dict(model=k, RMSE=rmse(y, p), dRMSE_vs_framework=rmse(y, p) - rmse(y, ref), dRMSE_CI_low=np.quantile(dr, .025), dRMSE_CI_high=np.quantile(dr, .975),
                         DM_stat=dm, DM_p=pdm, Wilcoxon_abs_error_p=w, Accuracy=accuracy_score(cls(y), cls(p))))
    T = pd.DataFrame(rows).sort_values("RMSE")
    # Holm correction on DM p-values
    o = np.argsort(T.DM_p.values); m = len(o); adj = np.empty(m); run = 0
    for r_, i in enumerate(o): run = max(run, min(1, (m - r_) * T.DM_p.values[i])); adj[i] = run
    T["DM_p_Holm"] = adj; T["framework_significantly_better_(Holm<0.05)"] = (T.DM_p_Holm < .05) & (T.dRMSE_vs_framework > 0)
    T["practically_equivalent_(|dRMSE|<0.001)"] = T.dRMSE_vs_framework.abs() < .001
    return T
T1 = cached("r1", r1); T1.round(5).to_csv(OUT + "R1_paired_statistical_comparison.csv", index=False); say("R1 done")

# ---------------------------------------------------------------- R2 residuals
def r2_():
    rows = []
    for nm in ("Proposed framework", "Mechanics-anchored hybrid (w=%.2f)" % WS, "LightGBM"):
        p = np.clip(ALL[nm], .25, 5); e = p - y
        groups = [("all", np.ones(len(y), bool))] + [(f, FAM == f) for f in sorted(set(FAM))] + \
                 [("FoS < 1.0", y < 1), ("1.0 <= FoS < 1.3", (y >= 1) & (y < 1.3)), ("1.3 <= FoS < 2.0", (y >= 1.3) & (y < 2)), ("FoS >= 2.0", y >= 2)]
        for g, m in groups:
            rows.append(dict(model=nm, subset=g, n=int(m.sum()), bias=e[m].mean(), RMSE=rmse(y[m], p[m]), MAE=np.abs(e[m]).mean(), P95_abs_error=np.quantile(np.abs(e[m]), .95),
                             MAPE_pct=np.mean(np.abs(e[m]) / y[m]) * 100, share_within_5pct=np.mean(np.abs(e[m]) / y[m] < .05) * 100))
    T = pd.DataFrame(rows)
    p = np.clip(ALL["Proposed framework"], .25, 5); e = p - y
    het = dict(spearman_abs_error_vs_FoS=stats.spearmanr(np.abs(e), y)[0], spearman_rel_error_vs_FoS=stats.spearmanr(np.abs(e) / y, y)[0],
               residual_skew=stats.skew(e), residual_kurtosis=stats.kurtosis(e), residual_q01=np.quantile(e, .01), residual_q99=np.quantile(e, .99))
    C = pd.DataFrame(confusion_matrix(cls(y), cls(p)), index=["true FoS<1", "true 1-1.3", "true >=1.3"], columns=["pred FoS<1", "pred 1-1.3", "pred >=1.3"])
    # dangerous error: true unstable predicted stable (>= 1.3)
    het["unsafe_misclass_pct (true<1, pred>=1.3)"] = float(np.mean((y < 1) & (p >= 1.3)) * 100)
    het["unsafe_misclass_pct (true<1, pred>=1)"] = float(np.mean((y < 1) & (p >= 1)) * 100)
    return T, het, C
T2, H2, C2 = cached("r2", r2_)
T2.round(4).to_csv(OUT + "R2_residuals_by_subset.csv", index=False); pd.Series(H2).round(4).to_csv(OUT + "R2b_residual_diagnostics.csv"); C2.to_csv(OUT + "R2c_confusion_matrix_framework.csv")
pd.DataFrame(dict(FoS_true=y, FoS_framework=np.clip(ALL["Proposed framework"], .25, 5), family=FAM)).sample(3000, random_state=3).round(4).to_csv(OUT + "R2d_residual_points_3000.csv", index=False)
say("R2 done")

# ---------------------------------------------------------------- R3 noise robustness, R4 missing features
SUB = Ate.sample(3000, random_state=21).reset_index(drop=True); yS = y[Ate.sample(3000, random_state=21).index.values] if False else None
idx = Ate.sample(3000, random_state=21).index.values; yS = y[idx]
MODELS_R = {"Proposed framework": MO.fw, "Mechanics-anchored hybrid": mah, "LightGBM (data-only)": lgbm}
LEVEL = {"L1 good site investigation": 1, "L2 typical": 2, "L3 poor / sparse data": 3}
def noisy(A, L, rng):
    D = A.copy(); n = len(D)
    D["Cohesion_kPa"] *= np.exp(rng.normal(0, .1 * L, n) - (.1 * L) ** 2 / 2)
    D["FrictionAngle_deg"] += rng.normal(0, 1. * L, n); D["UnitWeight_kN_m3"] *= 1 + rng.normal(0, .02 * L, n)
    D["SlopeAngle_deg"] += rng.normal(0, .5 * L, n); D["SlopeHeight_m"] *= 1 + rng.normal(0, .03 * L, n)
    D["PorePressureRatio"] += rng.normal(0, .02 * L, n); D["SeismicCoefficient"] *= 1 + rng.normal(0, .1 * L, n)
    D["Rainfall_mm_day"] *= 1 + rng.normal(0, .1 * L, n); D["GroundwaterDepth_m"] += rng.normal(0, .5 * L, n)
    for c in U.NUM[:11]: D[c] = np.clip(D[c], U.LO_[c], U.HI_[c])
    return U.recompute(D)
def r3():
    clean = {k: np.clip(f(SUB), .25, 5) for k, f in MODELS_R.items()}; rows = []
    for k in MODELS_R: rows.append(dict(model=k, level="L0 clean", RMSE=rmse(yS, clean[k]), Accuracy=accuracy_score(cls(yS), cls(clean[k])), prediction_shift_RMSE=0., verdict_flip_pct=0.))
    for ln, L in LEVEL.items():
        for k, f in MODELS_R.items():
            r = []
            for s in range(3):
                p = np.clip(f(noisy(SUB, L, np.random.default_rng(100 * L + s))), .25, 5)
                r.append((rmse(yS, p), accuracy_score(cls(yS), cls(p)), rmse(clean[k], p), np.mean(cls(p) != cls(clean[k])) * 100))
            r = np.mean(r, 0); rows.append(dict(model=k, level=ln, RMSE=r[0], Accuracy=r[1], prediction_shift_RMSE=r[2], verdict_flip_pct=r[3]))
    # reference: how much the mechanics itself moves under the same input noise (irreducible part)
    mc = mech(SUB)
    for ln, L in LEVEL.items():
        r = [rmse(mc, mech(noisy(SUB, L, np.random.default_rng(100 * L + s)))) for s in range(3)]
        rows.append(dict(model="Mechanics reference (Bishop surrogate)", level=ln, prediction_shift_RMSE=np.mean(r), verdict_flip_pct=np.nan))
    return pd.DataFrame(rows)
T3 = cached("r3", r3); T3.round(4).to_csv(OUT + "R3_input_noise_robustness.csv", index=False); say("R3 done")
GROUPS_MISS = {"rainfall chain (rain, GW depth, GW rise, weathering)": ["Rainfall_mm_day", "GroundwaterDepth_m", "GroundwaterRiseRate_m_day", "WeatheringIndex"],
               "GW rise rate + weathering (often unmeasured)": ["GroundwaterRiseRate_m_day", "WeatheringIndex"],
               "pore-pressure ratio r_u": ["PorePressureRatio"], "seismic coefficient kh": ["SeismicCoefficient"], "cohesion c": ["Cohesion_kPa"],
               "friction angle phi": ["FrictionAngle_deg"], "unit weight gamma": ["UnitWeight_kN_m3"], "slope height H": ["SlopeHeight_m"], "slope angle beta": ["SlopeAngle_deg"]}
def r4():
    rows = []; base = {k: rmse(yS, np.clip(f(SUB), .25, 5)) for k, f in MODELS_R.items()}
    for g, cols in GROUPS_MISS.items():
        D = SUB.copy()
        for c in cols: D[c] = U.MED[c]
        D = U.recompute(D)
        for k, f in MODELS_R.items():
            p = np.clip(f(D), .25, 5); rows.append(dict(missing=g, model=k, RMSE=rmse(yS, p), RMSE_increase=rmse(yS, p) - base[k], Accuracy=accuracy_score(cls(yS), cls(p))))
    return pd.DataFrame(rows)
T4 = cached("r4", r4); T4.round(4).to_csv(OUT + "R4_missing_feature_robustness.csv", index=False); say("R4 done")

# ---------------------------------------------------------------- R6 ICE / PDP
ICE_S = Ate[FAM != "F4 extreme compound"].sample(200, random_state=5).reset_index(drop=True)
KHG, RUG = np.round(np.linspace(0, .3, 13), 3), np.round(np.linspace(0, .6, 13), 3)
def r6():
    out = {}
    for var, grid in (("SeismicCoefficient", KHG), ("PorePressureRatio", RUG)):
        reps = []
        for g in grid:
            D = ICE_S.copy(); D[var] = g; reps.append(U.recompute(D))
        BIG = pd.concat(reps, ignore_index=True)
        for k, f in (("Proposed framework", MO.fw), ("Mechanics-anchored hybrid", mah), ("Bishop (MVB surrogate)", mech)):
            out[(var, k)] = np.clip(f(BIG), .05, 20).reshape(len(grid), len(ICE_S)).T
    return out
ICE = cached("r6", r6); rows = []
for (var, k), M in ICE.items():
    Mn = M / M[:, :1]; inc = np.max(np.diff(M, axis=1), axis=1)
    rows.append(dict(variable=var, model=k, pct_ICE_nonmonotone_gt_0_01=np.mean(inc > .01) * 100, median_norm_FoS_at_max=np.median(Mn[:, -1]),
                     median_norm_FoS_at_mid=np.median(Mn[:, len(Mn[0]) // 2])))
T6 = pd.DataFrame(rows); T6.round(4).to_csv(OUT + "R6_ICE_monotonicity_and_PDP.csv", index=False)
pdp = []
for (var, k), M in ICE.items():
    g = KHG if var == "SeismicCoefficient" else RUG; Mn = M / M[:, :1]
    for j, x in enumerate(g): pdp.append(dict(variable=var, model=k, x=x, PDP_norm=np.mean(Mn[:, j]), q10=np.quantile(Mn[:, j], .1), q90=np.quantile(Mn[:, j], .9)))
pd.DataFrame(pdp).round(4).to_csv(OUT + "R6b_PDP_curves.csv", index=False); say("R6 done")

# ---------------------------------------------------------------- R7 counterfactual remediation (mechanics benchmark)
def r7():
    D = ME.D.iloc[ME.i_te][ME.COLS].reset_index(drop=True); F = ME.D.FoS.values[ME.i_te]
    f = lambda d: ME.pred(ME.BEST, ME.feats(d)); rows = []
    for target in (1.3, 1.5):
        need = F < target; Dn = D[need].reset_index(drop=True)
        # drainage: smallest r_u reduction (bisection on r_u in [0, ru]), monotone decreasing FoS(r_u)
        lo, hi = np.zeros(len(Dn)), Dn.ru.values.copy(); ok_dr = f(Dn.assign(ru=0.)) >= target
        for _ in range(25):
            mid = (lo + hi) / 2; ok = f(Dn.assign(ru=mid)) >= target; lo = np.where(ok, mid, lo); hi = np.where(ok, hi, mid)
        ru_new = np.where(ok_dr, lo, np.nan)
        # regrading: smallest slope-angle reduction (beta >= 15)
        lo2, hi2 = np.full(len(Dn), 15.), Dn.beta.values.copy(); ok_rg = f(Dn.assign(beta=15.)) >= target
        for _ in range(25):
            mid = (lo2 + hi2) / 2; ok = f(Dn.assign(beta=mid)) >= target; lo2 = np.where(ok, mid, lo2); hi2 = np.where(ok, hi2, mid)
        b_new = np.where(ok_rg, lo2, np.nan)
        kb = pd.cut(Dn.kh, [-.01, .1, .2, .31], labels=["kh 0-0.1", "kh 0.1-0.2", "kh 0.2-0.3"])
        for band in ["all"] + list(kb.cat.categories):
            m = np.ones(len(Dn), bool) if band == "all" else (kb == band).values
            rows.append(dict(target_FoS=target, kh_band=band, n_below_target=int(m.sum()), pct_fixable_by_drainage_alone=np.mean(ok_dr[m]) * 100,
                             median_ru_reduction=np.nanmedian((Dn.ru.values - ru_new)[m]), pct_fixable_by_regrading_alone=np.mean(ok_rg[m]) * 100,
                             median_beta_reduction_deg=np.nanmedian((Dn.beta.values - b_new)[m]), pct_needing_both_or_structural=np.mean(~ok_dr[m] & ~ok_rg[m]) * 100))
        if target == 1.3:
            sv = Dn.assign(ru_new=ru_new, beta_new=b_new)
    # verify 150 drainage designs directly with Bishop
    v = sv.dropna(subset=["ru_new"]).sample(150, random_state=2)
    fb = np.array([ME.bishop_ps(r.H, r.beta, r.c, r.phi, r.gamma, ru=r.ru_new, kh=r.kh) for r in v.itertuples()])
    ver = dict(n=len(v), median_Bishop_FoS_at_design=float(np.median(fb)), pct_Bishop_ge_1_25=float(np.mean(fb >= 1.25) * 100), pct_Bishop_ge_1_3=float(np.mean(fb >= 1.3) * 100))
    return pd.DataFrame(rows), ver, sv
T7, V7, SV7 = cached("r7", r7); T7.round(3).to_csv(OUT + "R7_counterfactual_remediation.csv", index=False); pd.Series(V7).round(4).to_csv(OUT + "R7b_remediation_verified_with_Bishop.csv")
SV7.round(4).to_csv(OUT + "R7c_remediation_designs_FoS1.3.csv", index=False); say("R7 done", V7)

# ---------------------------------------------------------------- R8 real-world calibration and decision cost
def r8():
    yr = U.real.fail.values.astype(int); runs = [joblib.load(WK + f"/ckptU3/conf_run_{s}.joblib")[0] for s in (11, 12, 13, 14, 15)]
    rows, rel = [], []
    for s, p in zip((11, 12, 13, 14, 15), runs):
        bins = np.linspace(0, 1, 11); b = np.clip(np.digitize(p, bins) - 1, 0, 9)
        ece = sum(np.mean(b == i) * abs(p[b == i].mean() - yr[b == i].mean()) for i in range(10) if np.any(b == i))
        cost = {f"expected_cost_ratio_{r}": min(np.mean((p < t) & (yr == 1)) * r + np.mean((p >= t) & (yr == 0)) for t in np.linspace(.02, .98, 49)) for r in (1, 5, 10)}
        best_t = {f"cost_optimal_threshold_{r}": float(np.linspace(.02, .98, 49)[np.argmin([np.mean((p < t) & (yr == 1)) * r + np.mean((p >= t) & (yr == 0)) for t in np.linspace(.02, .98, 49)])]) for r in (5, 10)}
        rows.append(dict(seed=s, AUROC=roc_auc_score(yr, p), Brier=brier_score_loss(yr, p), Brier_climatology=brier_score_loss(yr, np.full(len(yr), yr.mean())),
                         ECE_10bins=ece, accuracy_at_0_5=accuracy_score(yr, p >= .5), recall_failures_at_0_5=np.mean(p[yr == 1] >= .5),
                         **cost, **best_t))
    pall = np.mean(runs, 0); bins = np.linspace(0, 1, 11); b = np.clip(np.digitize(pall, bins) - 1, 0, 9)
    for i in range(10):
        if np.any(b == i): rel.append(dict(bin_mid=(bins[i] + bins[i + 1]) / 2, mean_predicted=pall[b == i].mean(), observed_failure_rate=yr[b == i].mean(), n=int(np.sum(b == i))))
    return pd.DataFrame(rows), pd.DataFrame(rel)
T8, REL8 = cached("r8", r8); T8.loc["mean"] = T8.mean(numeric_only=True); T8.round(4).to_csv(OUT + "R8_realworld_calibration_and_cost.csv"); REL8.round(4).to_csv(OUT + "R8b_reliability_diagram.csv", index=False); say("R8 done")

# ---------------------------------------------------------------- R9 redundancy among experts
def r9():
    names = list(PT); E = np.column_stack([np.clip(PT[k], .25, 5) - y for k in names]); C = np.corrcoef(E.T)
    from scipy.cluster.hierarchy import linkage, fcluster
    from scipy.spatial.distance import squareform
    Z = linkage(squareform(1 - C, checks=False), "average"); cl = fcluster(Z, t=.1, criterion="distance")   # residual corr > ~0.9 -> same cluster
    T = pd.DataFrame(dict(model=names, cluster=cl, RMSE=[rmse(y, np.clip(PT[k], .25, 5)) for k in names])).sort_values(["cluster", "RMSE"])
    return T, pd.DataFrame(C, index=names, columns=names)
T9, C9 = cached("r9", r9); T9.round(5).to_csv(OUT + "R9_expert_redundancy_clusters.csv", index=False); C9.round(3).to_csv(OUT + "R9b_residual_correlation_matrix.csv")
say("R9 done; clusters:", T9.cluster.nunique()); say("DONE")
