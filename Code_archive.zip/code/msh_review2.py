"""Editorial-review analyses, part 2 (training required).
R5  input-group ablation: LightGBM retrained without each physical input group (derived physics features removed with
    any group they are computed from); selection-free, reported on validation and test.
R10 state-of-the-art tabular baselines missing from the benchmark: CatBoost and FT-Transformer (Gorishniy et al., 2021; 2 layers, d=64, CPU budget of 16 epochs),
    same split, same target, early stopping on validation; paired Diebold-Mariano test against the final framework."""
import os, sys, time, warnings
import numpy as np, pandas as pd, joblib
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
src = open(os.path.join(HERE, "msh_unified.py")).read(); exec(src.split("# ===================================================================== 6. tree models")[0])
import lightgbm as lgb2, torch, torch.nn as tnn
from scipy import stats
ROOT = os.environ.get("MSH_OUT", os.path.dirname(HERE)); OUTR = ROOT + "/review_results/"; os.makedirs(OUTR, exist_ok=True)
WK = os.environ.get("MSH_WORK", ROOT + "/.work"); CKR = WK + "/review/"; os.makedirs(CKR, exist_ok=True); T1 = time.time()
def say2(*a): print(f"[REV2 {(time.time()-T1)/60:5.1f}m]", *a, flush=True)
def cached2(n, fn):
    f = CKR + n + ".joblib"
    if os.path.exists(f): return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
yall = sva.FoS.values; Atr, Ava, Ate = A_sva.iloc[s_tr], A_sva.iloc[s_va], A_sva.iloc[s_te]; ytr, yva, yte = yall[s_tr], yall[s_va], yall[s_te]
kh = Ate.SeismicCoefficient.values; FAM = np.select([kh < .03, kh < .10, kh < .1201], ["F1", "F2", "F3"], "F4")
DER = ["StabilityNumber_N", "FrictionRatio", "FS_infinite"]
CAT = [c for c in FEATS if c.startswith(("SoilType_", "VegetationCover_", "DrainageCondition_"))]
G = {"none (all inputs)": [], "derived physics features only": DER,
     "geometry (H, beta)": ["SlopeHeight_m", "SlopeAngle_deg"] + DER, "shear strength (c, phi)": ["Cohesion_kPa", "FrictionAngle_deg"] + DER,
     "unit weight gamma": ["UnitWeight_kN_m3"] + DER, "pore-pressure ratio r_u": ["PorePressureRatio"] + DER,
     "rainfall chain (rain, GW depth, GW rise, weathering)": ["Rainfall_mm_day", "GroundwaterDepth_m", "GroundwaterRiseRate_m_day", "WeatheringIndex"],
     "all hydrology (rainfall chain + r_u)": ["Rainfall_mm_day", "GroundwaterDepth_m", "GroundwaterRiseRate_m_day", "WeatheringIndex", "PorePressureRatio"] + DER,
     "seismic coefficient kh": ["SeismicCoefficient"], "categorical site descriptors (soil, vegetation, drainage)": CAT}
def r5():
    rows = []
    for g, drop in G.items():
        F_ = [c for c in FEATS if c not in drop]
        m = lgb2.LGBMRegressor(n_estimators=4000, learning_rate=.05, num_leaves=63, subsample=.8, subsample_freq=1, colsample_bytree=.8, verbose=-1, random_state=RS, n_jobs=2)
        m.fit(Atr[F_], ytr, eval_set=[(Ava[F_], yva)], callbacks=[lgb2.early_stopping(150, verbose=False)])
        pv, pt = np.clip(m.predict(Ava[F_]), .25, 5), np.clip(m.predict(Ate[F_]), .25, 5)
        r = dict(removed=g, n_features=len(F_), val_RMSE=rm(yva, pv), test_RMSE=rm(yte, pt), test_R2=1 - np.sum((yte - pt) ** 2) / np.sum((yte - yte.mean()) ** 2),
                 test_accuracy=np.mean(to_class(yte) == to_class(pt)))
        for f in ("F1", "F2", "F3", "F4"): r[f"test_RMSE_{f}"] = rm(yte[FAM == f], pt[FAM == f])
        rows.append(r); say2(g, round(r["test_RMSE"], 4))
    T = pd.DataFrame(rows); T["dRMSE_vs_all_inputs"] = T.test_RMSE - T.test_RMSE.iloc[0]; return T
T5 = cached2("r5", r5); T5.round(4).to_csv(OUTR + "R5_input_group_ablation.csv", index=False); say2("R5 done")

# ---------------------------------------------------------------- R10 CatBoost + FT-Transformer
def cat():
    from catboost import CatBoostRegressor
    m = CatBoostRegressor(iterations=6000, learning_rate=.06, depth=8, loss_function="RMSE", random_seed=RS, thread_count=2, verbose=0, od_type="Iter", od_wait=200)
    t = time.time(); m.fit(Atr, ytr, eval_set=(Ava, yva), use_best_model=True); tt = time.time() - t
    return np.clip(m.predict(Ate), .25, 5), np.clip(m.predict(Ava), .25, 5), tt
class FTT(tnn.Module):
    def __init__(s, nf, d=64, L=2, h=8):
        super().__init__(); s.W = tnn.Parameter(torch.randn(nf, d) * .1); s.b = tnn.Parameter(torch.zeros(nf, d)); s.cls = tnn.Parameter(torch.zeros(1, 1, d))
        s.enc = tnn.TransformerEncoder(tnn.TransformerEncoderLayer(d, h, 2 * d, .1, batch_first=True, norm_first=True), L)
        s.head = tnn.Sequential(tnn.LayerNorm(d), tnn.ReLU(), tnn.Linear(d, 1))
    def forward(s, x):
        t = x.unsqueeze(-1) * s.W + s.b; t = torch.cat([s.cls.expand(len(x), -1, -1), t], 1); return s.head(s.enc(t)[:, 0]).squeeze(-1)
def ftt():
    torch.manual_seed(RS); torch.set_num_threads(2)
    mu, sd = Atr.values.mean(0), Atr.values.std(0) + 1e-9; Z = lambda A: torch.tensor((A.values - mu) / sd, dtype=torch.float32)
    Xtr_, Xva_, Xte_ = Z(Atr), Z(Ava), Z(Ate); ytr_ = torch.tensor(np.log(ytr), dtype=torch.float32)
    m = FTT(Xtr_.shape[1]); opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-5); best, bst, wait = 9, None, 0; t = time.time()
    pr = lambda X: np.concatenate([np.exp(m(X[i:i + 4096]).detach().numpy()) for i in range(0, len(X), 4096)])
    for ep in range(25):
        m.train(); perm = torch.randperm(len(Xtr_))
        for i in range(0, len(perm), 1024):
            b = perm[i:i + 1024]; opt.zero_grad(); loss = ((m(Xtr_[b]) - ytr_[b]) ** 2).mean(); loss.backward(); opt.step()
        m.eval(); v = rm(yva, np.clip(pr(Xva_), .25, 5)); say2(f"FT-T epoch {ep} val RMSE {v:.4f}")
        if v < best - 1e-4: best, bst, wait = v, {k: x.clone() for k, x in m.state_dict().items()}, 0
        else:
            wait += 1
            if wait >= 5: break
    m.load_state_dict(bst); m.eval(); return np.clip(pr(Xte_), .25, 5), np.clip(pr(Xva_), .25, 5), time.time() - t
R = {"CatBoost": cached2("r10_cat", cat), "FT-Transformer": cached2("r10_ftt", ftt)}
PF = joblib.load(CKR + "test_preds.joblib")["Proposed framework"]; ref = np.clip(PF, .25, 5); e0 = (ref - yte) ** 2; rows = []
for k, (pt, pv, tt) in R.items():
    d = (pt - yte) ** 2 - e0; dm = d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))
    rows.append(dict(model=k, val_RMSE=rm(yva, pv), test_RMSE=rm(yte, pt), test_R2=1 - np.sum((yte - pt) ** 2) / np.sum((yte - yte.mean()) ** 2), test_accuracy=np.mean(to_class(yte) == to_class(pt)),
                     dRMSE_vs_framework=rm(yte, pt) - rm(yte, ref), DM_stat=dm, DM_p=2 * (1 - stats.norm.cdf(abs(dm))), train_minutes=tt / 60))
pd.DataFrame(rows).round(5).to_csv(OUTR + "R10_sota_tabular_baselines.csv", index=False); say2(pd.DataFrame(rows).round(4).to_string()); say2("DONE")
