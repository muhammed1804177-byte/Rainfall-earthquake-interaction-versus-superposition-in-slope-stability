"""Selective prediction: confident verdicts only; confidence cut-off chosen INSIDE training folds to target >=93%."""
import numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realpush.py")).read().split("FOLDS = [list(")[0])
X = FS["6 props + physics + Bishop + ALL-20 fused"]; L = "Vote(CatBoost+LightGBM+XGBoost+RandomForest)"; rows = []
for gname, grp in [("rounding-duplicate grouping", G)] + [("relatives within 0.25 SD", None)]:
    if grp is None:
        from scipy.cluster.hierarchy import linkage, fcluster
        from sklearn.preprocessing import StandardScaler
        Zs = StandardScaler().fit_transform(np.c_[np.log(real.SlopeHeight_m), real.SlopeAngle_deg, real.UnitWeight_kN_m3, np.log1p(real.Cohesion_kPa), real.FrictionAngle_deg, real.PorePressureRatio])
        grp = fcluster(linkage(Zs, "single"), .25, "distance")
    for r in range(3):
        pp, cut = np.zeros(len(y)), np.zeros(len(y))
        for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=r).split(X, y, grp):
            po = np.zeros(len(a))
            for ia, ib in StratifiedGroupKFold(3, shuffle=True, random_state=10 + r).split(a, y[a], grp[a]): po[ib] = LEARN[L]().fit(X[a][ia], y[a][ia]).predict_proba(X[a][ib])[:, 1]
            conf = np.abs(po - .5); cs = np.sort(np.unique(conf)); c0 = cs[-1]
            for cc in cs:                                      # smallest cut-off whose inner accuracy >= 93 %
                m = conf >= cc
                if m.sum() >= 10 and accuracy_score(y[a][m], po[m] > .5) >= .93: c0 = cc; break
            pp[b_] = LEARN[L]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]; cut[b_] = c0
        m = np.abs(pp - .5) >= cut
        rows.append(dict(grouping=gname, repeat=r, coverage_pct=m.mean() * 100, accuracy_on_confident=accuracy_score(y[m], pp[m] > .5),
                         accuracy_all=accuracy_score(y, pp > .5), flagged_for_investigation_pct=(~m).mean() * 100))
        print(rows[-1], flush=True)
D = pd.DataFrame(rows); S = D.groupby("grouping")[["coverage_pct", "accuracy_on_confident", "accuracy_all", "flagged_for_investigation_pct"]].agg(["mean", "std"])
S.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T12_selective_prediction_93pct.csv")); print(S.round(3).to_string()); print("DONE")
