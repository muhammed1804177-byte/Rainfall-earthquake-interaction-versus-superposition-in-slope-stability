"""Study-slope illustration: (a) 3D block diagram of a vegetated soil slope under rainfall and shaking,
(b) cross-section with the pseudo-static Bishop critical circle, slices, phreatic surface and forces.
The circle in (b) is the actual critical circle returned by the solver for the representative slope."""
import os, sys
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource, LinearSegmentedColormap
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.patches import Polygon, FancyArrowPatch, FancyBboxPatch
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import bishop_ps as B

OUT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs") + "/figures_manuscript/"
plt.rcParams.update({"font.family": "Inter", "font.size": 8.5, "axes.titleweight": "semibold", "svg.fonttype": "none", "pdf.fonttype": 42})
INK, INK2 = "#1F2328", "#555B61"
SOIL, SOIL2, WEATH, ROCK = "#C9A877", "#B08A5A", "#9C8468", "#6E6A66"
GRASS, WATER, SEIS, SLIP, COMP = "#7FA07A", "#2C7FB8", "#7B4F9E", "#B5573B", "#C98A1B"

# ---------- representative slope and its critical circle ----------
H, beta, c, phi, gam, ru, kh = 20.0, 35.0, 15.0, 28.0, 19.0, 0.30, 0.15
def critical_circle(H, beta, c, phi, gam, ru, kh, ngrid=26):
    br = np.radians(beta); L = H / np.tan(br); tphi = np.tan(np.radians(phi)); best = (np.inf, None)
    for depth in (0.0, 0.1, 0.25, 0.5):
        xs = np.linspace(-0.6 * H, L + 0.8 * H, ngrid); ys = np.linspace(0.4 * H, H * 2.5 + L * 0.6, ngrid)
        XC, YC = [a.ravel() for a in np.meshgrid(xs, ys)]
        R, xa, xb, ok = B._candidates(XC, YC, H, L, depth)
        if not ok.any(): continue
        F = B._fos_circles(XC[ok], YC[ok], R[ok], xa[ok], xb[ok], H, br, c, tphi, gam, ru, kh); j = int(np.argmin(F))
        if F[j] < best[0]: best = (F[j], (XC[ok][j], YC[ok][j], R[ok][j], xa[ok][j], xb[ok][j]))
    return best
F_all, circ = critical_circle(H, beta, c, phi, gam, ru, kh)
F_0 = B.bishop_ps(H, beta, c, phi, gam); F_r = B.bishop_ps(H, beta, c, phi, gam, ru=ru); F_e = B.bishop_ps(H, beta, c, phi, gam, kh=kh)
print("F0 %.3f  F_R %.3f  F_E %.3f  F_RE %.3f  I %.3f" % (F_0, F_r, F_e, F_all, F_all * F_0 / (F_r * F_e)))

fig = plt.figure(figsize=(7.2, 7.6), dpi=150)
# =================== (a) 3D block diagram ===================
ax = fig.add_axes([-0.06, 0.43, 1.12, 0.60], projection="3d"); ax.computed_zorder = False
L3, W3, Hs = 110.0, 60.0, 28.0
x = np.linspace(0, L3, 220); y = np.linspace(0, W3, 120); X, Y = np.meshgrid(x, y)
def profile(x):  # toe plain -> slope -> crest plateau (smooth)
    s = 1 / (1 + np.exp(-(x - 55) / 7.5)); return Hs * s
rng = np.random.default_rng(4)
gully = 1.6 * np.exp(-((Y - 22) / 5.0) ** 2) * np.exp(-((X - 55) / 14) ** 2) + 1.1 * np.exp(-((Y - 44) / 4) ** 2) * np.exp(-((X - 58) / 12) ** 2)
noise = sum(a * np.sin(fx * X + fy * Y + p) for a, fx, fy, p in [(0.35, .21, .13, 1), (0.25, .11, .31, 2), (0.18, .37, .07, 3)])
Z = profile(X) - gully + noise * (0.4 + 0.6 * np.exp(-((X - 55) / 20) ** 2))
ls = LightSource(azdeg=300, altdeg=38)
cm = LinearSegmentedColormap.from_list("veg", ["#8DA86E", "#6F9160", "#A7B57A", "#C7B98A"])
rgb = ls.shade(Z, cmap=cm, vert_exag=1.4, blend_mode="soft", vmin=-2, vmax=Hs + 2)
# bare scar on the slope face (shallow slide)
scar = np.exp(-((Y - 32) / 9) ** 4) * np.exp(-((X - 56) / 9) ** 4)
rgb[..., :3] = rgb[..., :3] * (1 - 0.75 * scar[..., None]) + np.array([0.71, 0.55, 0.38]) * 0.75 * scar[..., None]
ax.plot_surface(X, Y, Z, facecolors=rgb, rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False, zorder=1)
zb = -16.0; xf = x; zf = profile(xf) + noise[0] * 0  # front face y = 0
zfront = Z[0]
def face(z_top, z_bot, color, a=1.0):
    verts = [list(zip(xf, np.zeros_like(xf), z_top)) + list(zip(xf[::-1], np.zeros_like(xf), z_bot[::-1]))]
    ax.add_collection3d(Poly3DCollection(verts, facecolor=color, edgecolor="none", alpha=a, zorder=2))
top_soil = zfront; soil_bot = zfront - 3.2; weath_bot = zfront - 9 + 0.12 * (xf - 55) * 0
rock_top = np.minimum(soil_bot - 0.1, -4 + 0.62 * profile(xf))
face(top_soil, soil_bot, SOIL); face(soil_bot, rock_top, WEATH); face(rock_top, np.full_like(xf, zb), ROCK)
# side face x = L3
ys = y; zs = Z[:, 0]
verts = [list(zip(np.full_like(ys, 0.0), ys, zs)) + list(zip(np.full_like(ys, 0.0), ys[::-1], np.full_like(ys, zb)))]
ax.add_collection3d(Poly3DCollection(verts, facecolor="#8A7560", edgecolor="none", zorder=2))
verts = [list(zip(np.full_like(ys, 0.0), ys, zs)) + list(zip(np.full_like(ys, 0.0), ys[::-1], (zs - 3.2)[::-1]))]
ax.add_collection3d(Poly3DCollection(verts, facecolor="#B99A6C", edgecolor="none", zorder=2))
# phreatic surface (perched, rising) and slip surface on front face
wt = soil_bot + 1.6 * np.exp(-((xf - 50) / 22) ** 2) + 0.6
wt = np.minimum(wt, top_soil - 0.25)
ax.plot(xf, np.zeros_like(xf) - 0.05, wt, color=WATER, lw=1.6, zorder=10)
sl = (xf > 38) & (xf < 74); xs_ = xf[sl]; zsl = profile(xs_) - 4.5 * np.sin(np.pi * (xs_ - 38) / 36)
ax.plot(xs_, np.zeros_like(xs_) - 0.1, zsl, color=SLIP, lw=1.8, ls=(0, (4, 2)), zorder=11)
# rain streaks
for k in range(260):
    x0, y0 = rng.uniform(5, L3 - 3), rng.uniform(3, W3 - 3); z0 = profile(np.array([x0]))[0] + rng.uniform(12, 30)
    ax.plot([x0, x0 - 1.0], [y0, y0], [z0, z0 - 5.5], color="#5E8FB8", lw=0.55, alpha=0.65, zorder=6)
# trees on crest and toe (simple cones)
for k in range(70):
    tx = rng.choice([rng.uniform(4, 34), rng.uniform(76, 106)]); ty = rng.uniform(4, W3 - 4); tz = profile(np.array([tx]))[0]
    hgt = rng.uniform(3.5, 6)
    ax.plot([tx, tx], [ty, ty], [tz, tz + hgt * .5], color="#5B4632", lw=1.0, zorder=3)
    ax.scatter([tx], [ty], [tz + hgt * .75], s=rng.uniform(25, 60), color=rng.choice(["#3E6B3A", "#4F7D45", "#5C8A4E"]), edgecolors="#2F4F2A", linewidths=.3, depthshade=False, zorder=4)
# shaking arrow (horizontal, kh W) at the base
ax.quiver(78, -6, zb + 3, 22, 0, 0, color=SEIS, lw=2.0, arrow_length_ratio=0.25)
ax.quiver(100, -6, zb + 3, -22, 0, 0, color=SEIS, lw=2.0, arrow_length_ratio=0.25)
ax.text(89, -8, zb - 3.5, "seismic shaking  $k_h$", color=SEIS, fontsize=8.5, ha="center", fontweight="semibold")
ax.text(40, 30, Hs + 30, "rainfall  →  rising $r_u$", color=WATER, fontsize=8.5, ha="center", fontweight="semibold")
ax.set_xlim(0, L3); ax.set_ylim(0, W3); ax.set_zlim(zb, Hs + 22)
ax.set_box_aspect((L3, W3 * 1.05, (Hs - zb + 22) * 1.1)); ax.view_init(elev=22, azim=-122); ax.set_axis_off()
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
hl = [Line2D([], [], color=WATER, lw=1.8, label="perched water table"), Line2D([], [], color=SLIP, lw=1.8, ls=(0, (4, 2)), label="slip surface"),
      Patch(fc=SOIL, label="residual soil (2–3 m)"), Patch(fc=WEATH, label="weathered zone"), Patch(fc=ROCK, label="bedrock")]
fig.legend(handles=hl, loc="upper left", bbox_to_anchor=(0.03, 0.70), frameon=False, fontsize=7.5, handlelength=2.2)
fig.text(0.02, 0.975, "(a)  Study slope under rainfall and earthquake loading", fontsize=9.5, fontweight="semibold", color=INK)

# =================== (b) cross-section with critical circle ===================
bx = fig.add_axes([0.03, 0.02, 0.95, 0.42])
XC, YC, R, xa, xb = circ; Lh = H / np.tan(np.radians(beta))
xg = np.linspace(-0.9 * H, Lh + 1.3 * H, 600); yg = np.where(xg < 0, 0, np.where(xg > Lh, H, xg * np.tan(np.radians(beta))))
bx.fill_between(xg, -0.45 * H, yg, color=SOIL, zorder=1)
bx.fill_between(xg, -0.45 * H, -0.18 * H + 0 * xg, color=ROCK, zorder=1)
bx.plot(xg, yg, color=INK, lw=1.2, zorder=4)
# slices
n = 12; xe = np.linspace(xa, xb, n + 1)
yt = lambda x: np.where(x < 0, 0, np.where(x > Lh, H, x * np.tan(np.radians(beta))))
yb = lambda x: YC - np.sqrt(np.clip(R ** 2 - (x - XC) ** 2, 0, None))
xx = np.linspace(xa, xb, 300); poly = np.r_[np.c_[xx, yt(xx)], np.c_[xx[::-1], yb(xx[::-1])]]
bx.add_patch(Polygon(poly, closed=True, facecolor="#E7D3B0", edgecolor="none", zorder=2))
for xe_ in xe[1:-1]: bx.plot([xe_, xe_], [yb(xe_), yt(xe_)], color="#8C7458", lw=0.6, zorder=3)
bx.plot(xx, yb(xx), color=SLIP, lw=2.0, ls=(0, (5, 2)), zorder=5)
# phreatic line representing r_u
xw = xg; yw = np.clip(0.55 * yg + 0.12 * H, None, yg - 0.3); yw = np.where(xw < 0, -0.05 * H, yw)
bx.plot(xw, yw, color=WATER, lw=1.4, zorder=4); bx.text(Lh + 0.62 * H, 0.86 * H, "phreatic surface\n($r_u = u/\\gamma h$)", color=WATER, fontsize=7.5, ha="center")
bx.plot([Lh + 0.70 * H], [0.672 * H], marker="v", color=WATER, ms=5)
# centre and radius
ytop_lim = H + 0.32 * H; t_ = (ytop_lim - yb(xb)) / (YC - yb(xb)); px, py = xb + t_ * (XC - xb), ytop_lim
bx.annotate("", xy=(px, py), xytext=(xb, yb(xb)), arrowprops=dict(arrowstyle="->", color=INK2, lw=0.7, ls=":"))
bx.text(px - 0.6, py - 0.3, f"R = {R:.1f} m, to centre O", fontsize=7.5, color=INK2, va="top", ha="right")
# a highlighted slice with forces
i = 5; x1, x2 = xe[i], xe[i + 1]; xm = (x1 + x2) / 2; ym_t, ym_b = yt(xm), yb(xm); yc_ = (ym_t + ym_b) / 2
bx.add_patch(Polygon([[x1, yt(x1)], [x2, yt(x2)], [x2, yb(x2)], [x1, yb(x1)]], facecolor="#D9B98A", edgecolor="#6B5338", lw=0.9, zorder=6))
def arrow(p, q, col, lab=None, off=(0, 0), ha="left"):
    bx.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, color=col, lw=1.3, zorder=8))
    if lab: bx.text(q[0] + off[0], q[1] + off[1], lab, color=col, fontsize=8, ha=ha, va="center", fontweight="semibold")
arrow((xm, yc_ + 1.5), (xm, yc_ - 4.0), INK, "$W$", (0.5, 0.6))
arrow((xm, yc_), (xm - 5.5, yc_), SEIS, "$k_hW$", (-0.6, 0.9), "right")
al = np.arcsin((xm - XC) / R); nx, ny = -np.sin(al), np.cos(al)
arrow((xm - 4.2 * nx, ym_b - 4.2 * ny), (xm, ym_b), WATER, None)
bx.text(xm - 4.6 * nx + 0.2, ym_b - 4.6 * ny - 0.9, "$u\\,b$", color=WATER, fontsize=8, fontweight="semibold")
tx, ty = np.cos(al), np.sin(al)
arrow((xm + 0.4, ym_b + 0.1), (xm + 0.4 - 4 * tx, ym_b + 0.1 - 4 * ty), "#3A5A40", "$S_m$", (-0.4, -1.0), "right")
# dimensions
bx.annotate("", xy=(Lh + 1.18 * H, 0), xytext=(Lh + 1.18 * H, H), arrowprops=dict(arrowstyle="<->", color=INK2, lw=0.8))
bx.text(Lh + 1.21 * H, H / 2, "$H$", color=INK2, fontsize=9)
th = np.linspace(0, np.radians(beta), 30); bx.plot(0.28 * H * np.cos(th), 0.28 * H * np.sin(th), color=INK2, lw=0.8); bx.text(0.31 * H, 0.06 * H, "$\\beta$", fontsize=9, color=INK2)
box = ("Representative slope: $H$ = 20 m, $\\beta$ = 35°, $c'$ = 15 kPa, $\\varphi'$ = 28°, $\\gamma$ = 19 kN/m³\n"
       f"Bishop (pseudo-static):  $F_0$ = {F_0:.2f}   $F_R$($r_u$=0.3) = {F_r:.2f}   $F_E$($k_h$=0.15) = {F_e:.2f}   "
       f"$F_{{RE}}$ = {F_all:.2f}   $I$ = {F_all * F_0 / (F_r * F_e):.3f}")
bx.text(-0.88 * H, -0.40 * H, box, fontsize=7.4, color=INK, va="bottom",
        bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="#BDB6A8", lw=0.6), zorder=9)
bx.text(xb - 1, H + 0.6, "critical circle", color=SLIP, fontsize=7.5, ha="right")
bx.set_xlim(-0.9 * H, Lh + 1.35 * H); bx.set_ylim(-0.45 * H, H + 0.34 * H); bx.set_aspect("equal"); bx.axis("off")
fig.text(0.02, 0.455, "(b)  Pseudo-static Bishop analysis: critical circle, slices and forces on slice $i$", fontsize=9.5, fontweight="semibold", color=INK)
for ext in ("png", "pdf"):
    fig.savefig(OUT + "Fig02_study_slope_model." + ext, dpi=600 if ext == "png" else None, facecolor="white")
print("saved")
