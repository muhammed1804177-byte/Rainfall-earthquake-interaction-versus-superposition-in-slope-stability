"""Sensitivity of real-world accuracy to how strictly related slopes are grouped (leakage check)."""
import numpy as np, pandas as pd, joblib, warnings, json
warnings.filterwarnings("ignore")
src = open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realpush.py")).read()
exec(src.split("FOLDS = [list(")[0])                       # data, Bishop, features, learners (no training)
from scipy.cluster.hierarchy import linkage, fcluster
from sklearn.preprocessing import StandardScaler
Z = StandardScaler().fit_transform(np.c_[np.log(real.SlopeHeight_m), real.SlopeAngle_deg, real.UnitWeight_kN_m3, np.log1p(real.Cohesion_kPa), real.FrictionAngle_deg, real.PorePressureRatio])
LK = linkage(Z, "single")
CFG = {"No experts: 6 props + physics, LightGBM": ("REF", "6 props + physics (no Bishop, no experts, reference)", "LightGBM"),
       "ALL-20 fused + Bishop, Vote(Cat+LGB+XGB+RF)": ("FS", "6 props + physics + Bishop + ALL-20 fused", "Vote(CatBoost+LightGBM+XGBoost+RandomForest)"),
       "ALL-20 fused + Bishop, CatBoost": ("FS", "6 props + physics + Bishop + ALL-20 fused", "CatBoost")}
rows = []
for thr in [0.0, 0.25, 0.5, 0.75, 1.0]:
    grp = G if thr == 0 else fcluster(LK, thr, "distance")
    ng = len(np.unique(grp)); biggest = pd.Series(grp).value_counts().iloc[0]
    for name, (kind, f, l) in CFG.items():
        X = (REF if kind == "REF" else FS)[f]; acc, auc = [], []
        for r in range(3):
            pp = np.zeros(len(y))
            for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=r).split(X, y, grp): pp[b_] = LEARN[l]().fit(X[a], y[a]).predict_proba(X[b_])[:, 1]
            acc.append(accuracy_score(y, pp > .5)); auc.append(roc_auc_score(y, pp))
        rows.append(dict(grouping=("rounding duplicates only (used so far)" if thr == 0 else f"relatives within {thr} SD"), groups=ng, largest_group=int(biggest),
                         config=name, Accuracy=np.mean(acc), AUROC=np.mean(auc)))
        print(rows[-1], flush=True)
D = pd.DataFrame(rows); D.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T10_strict_grouping_leakage_check.csv"), index=False)
print(D.pivot_table(index=["grouping", "groups"], columns="config", values="Accuracy", sort=False).round(3).to_string())
