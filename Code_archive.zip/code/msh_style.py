"""Visual identity for all manuscript figures ("Strata" palette).

Earth-and-water hues chosen for a geotechnical / environmental study, validated for colour-vision deficiency (all-pairs CVD
dE >= 11, normal-vision dE >= 16.7) and for print. Every ROLE keeps the same colour in every figure.

  Proposed framework (and its variants) ... TERRACOTTA  #B24A2F   (fired clay)
  Rainfall / pore pressure / hydrology .... LAGOON      #008F86   (groundwater)
  Seismic loading (kh) .................... PLUM        #7B4F9E   (deep crust)
  Compound rainfall + seismic ............. OCHRE       #C98A1B   (weathered loess)
  Mechanics reference (Bishop, M-P, LEM) .. BASALT      #2F353B   (dark ink, dashed / hollow markers)
  Other ML/DL models, baselines ........... STONE       #A39E93   (neutral)
  Neutral midpoint / backgrounds .......... SAND        #EFE8DA
Sequential magnitude ramp (one hue, light -> dark): SAND -> TERRACOTTA -> umber.
Diverging FoS ramp: terracotta (unsafe, FoS < 1) <- sand (FoS = 1) -> lagoon (safe).
Typeface: Inter. Ink: #1F2328 / #555B61; hairline grid #E6E1D8; axes #BDB6A8.
"""
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, to_rgb
import numpy as np

TERRACOTTA, LAGOON, PLUM, OCHRE = "#B24A2F", "#008F86", "#7B4F9E", "#C98A1B"
BASALT, STONE, SAND = "#2F353B", "#A39E93", "#EFE8DA"
INK, INK2, GRID, AXIS = "#1F2328", "#555B61", "#E6E1D8", "#BDB6A8"
TERRA_TINT = "#D9876A"            # a lighter variant of the proposed framework (e.g. alternative configuration)
ROLE = dict(framework=TERRACOTTA, framework_alt=TERRA_TINT, rainfall=LAGOON, seismic=PLUM, compound=OCHRE,
            mechanics=BASALT, baseline=STONE, neutral=SAND)
HAZARD = {"static": STONE, "rainfall": LAGOON, "seismic": PLUM, "compound": OCHRE}
# variable groups -> colour (used for importance / sensitivity bars)
VAR_GROUP = {"SlopeAngle_deg": BASALT, "SlopeHeight_m": BASALT, "Cohesion_kPa": BASALT, "FrictionAngle_deg": BASALT, "UnitWeight_kN_m3": BASALT,
             "Rainfall_mm_day": LAGOON, "PorePressureRatio": LAGOON, "GroundwaterDepth_m": LAGOON, "GroundwaterRiseRate_m_day": LAGOON,
             "WeatheringIndex": LAGOON, "SeismicCoefficient": PLUM}
VAR_LABEL = {"SlopeAngle_deg": "Slope angle β", "SlopeHeight_m": "Slope height H", "Cohesion_kPa": "Cohesion c", "FrictionAngle_deg": "Friction angle φ",
             "UnitWeight_kN_m3": "Unit weight γ", "Rainfall_mm_day": "Rainfall", "PorePressureRatio": "Pore-pressure ratio rᵤ",
             "GroundwaterDepth_m": "Groundwater depth", "GroundwaterRiseRate_m_day": "Groundwater rise rate", "WeatheringIndex": "Weathering index",
             "SeismicCoefficient": "Seismic coefficient kₕ"}
EARTH_SEQ = LinearSegmentedColormap.from_list("earth_seq", ["#F6F0E4", "#EBD3B2", "#DCAA80", "#C97D55", "#B24A2F", "#86331F", "#58210F"])
PLUM_SEQ = LinearSegmentedColormap.from_list("plum_seq", ["#E6DCEF", "#B9A0D0", "#7B4F9E", "#4B2B66"])
LAGOON_SEQ = LinearSegmentedColormap.from_list("lagoon_seq", ["#D7EEEA", "#7CC4BB", "#008F86", "#00524C"])
FOS_DIV = LinearSegmentedColormap.from_list("fos_div", ["#86331F", TERRACOTTA, "#E3A58C", SAND, "#8CCBC4", LAGOON, "#00524C"])

def ramp(cmap, n, lo=.25, hi=1.):
    return [cmap(x) for x in np.linspace(lo, hi, n)]

def apply():
    mpl.rcParams.update({
        "font.family": "Inter", "font.size": 8.5, "axes.titlesize": 9.5, "axes.titleweight": "semibold", "axes.titlelocation": "left",
        "axes.titlecolor": INK, "axes.labelsize": 8.5, "axes.labelcolor": INK2, "axes.edgecolor": AXIS, "axes.linewidth": .8,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .6,
        "axes.axisbelow": True, "xtick.color": INK2, "ytick.color": INK2, "xtick.labelsize": 7.8, "ytick.labelsize": 7.8,
        "xtick.major.size": 3, "ytick.major.size": 3, "xtick.major.width": .8, "ytick.major.width": .8,
        "legend.frameon": False, "legend.fontsize": 7.6, "legend.title_fontsize": 7.8, "figure.facecolor": "white", "axes.facecolor": "white",
        "savefig.facecolor": "white", "lines.linewidth": 1.8, "lines.markersize": 4.5, "patch.linewidth": 0, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.prop_cycle": mpl.cycler(color=[TERRACOTTA, LAGOON, PLUM, OCHRE]), "image.cmap": "earth_seq"})
    try: mpl.colormaps.register(EARTH_SEQ)
    except ValueError: pass

def panel_label(ax, s):
    ax.text(-.02, 1.06, s, transform=ax.transAxes, fontsize=10, fontweight="bold", color=INK, ha="right", va="bottom")

def text_on(rgb):
    r, g, b = to_rgb(rgb); return "white" if (.299 * r + .587 * g + .114 * b) < .55 else INK

def swatch(path):
    """Palette key for the authors (not a manuscript figure)."""
    apply(); items = [("Proposed framework", TERRACOTTA), ("Framework variant", TERRA_TINT), ("Rainfall / pore pressure", LAGOON), ("Seismic (kₕ)", PLUM),
                      ("Compound hazard", OCHRE), ("Mechanics reference (LEM)", BASALT), ("Other models / baselines", STONE), ("Neutral", SAND)]
    fig, ax = plt.subplots(figsize=(7.2, 2.6)); ax.axis("off")
    for i, (n, c) in enumerate(items):
        x, y = (i % 4) * 1.8, -(i // 4) * 1.1; ax.add_patch(plt.Rectangle((x, y), 1.6, .62, color=c)); ax.text(x + .08, y + .31, c, color=text_on(c), va="center", fontsize=8, fontweight="semibold")
        ax.text(x, y - .14, n, fontsize=7.6, color=INK2, va="top")
    for j, (nm, cm) in enumerate((("Sequential (magnitude)", EARTH_SEQ), ("Diverging (FoS around 1)", FOS_DIV))):
        ax.imshow(np.linspace(0, 1, 256)[None], cmap=cm, extent=(j * 3.6, j * 3.6 + 3.4, -2.6, -2.25), aspect="auto"); ax.text(j * 3.6, -2.68, nm, fontsize=7.6, color=INK2, va="top")
    ax.set_xlim(-.1, 7.2); ax.set_ylim(-3, .8); ax.set_title("Strata palette: one colour per role across all figures")
    plt.savefig(path, dpi=300, bbox_inches="tight"); plt.close()
