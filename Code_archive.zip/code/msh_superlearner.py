"""Nested super-learner + in-fold hyper-parameter search with ALL 20 experts; plus leaky-split ceiling test."""
import numpy as np, pandas as pd, json, warnings
warnings.filterwarnings("ignore")
exec(open((__import__("os").path.dirname(__import__("os").path.abspath(__file__)) + "/msh_realpush.py")).read().split("FOLDS = [list(")[0])
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
X = FS["6 props + physics + Bishop + ALL-20 fused"]; XR = REF["6 props + physics (no Bishop, no experts, reference)"]
rng = np.random.default_rng(7)
GRID = [("LightGBM", dict(n_estimators=int(rng.choice([200, 400, 800])), num_leaves=int(rng.choice([7, 15, 31])), learning_rate=float(rng.choice([.02, .05, .1])),
          min_child_samples=int(rng.choice([5, 10, 20])), colsample_bytree=float(rng.choice([.6, .8, 1.])))) for _ in range(6)] + \
       [("CatBoost", dict(iterations=int(rng.choice([300, 600])), depth=int(rng.choice([3, 4, 6])), learning_rate=float(rng.choice([.03, .06, .1])), l2_leaf_reg=float(rng.choice([1, 3, 10])))) for _ in range(4)]
def mk(kind, p):
    if kind == "LightGBM": return lgb.LGBMClassifier(subsample=.8, subsample_freq=1, verbose=-1, random_state=RS, **p)
    return CatBoostClassifier(verbose=0, random_seed=RS, **p)
BASE = ["CatBoost", "LightGBM", "XGBoost", "RandomForest", "ExtraTrees", "GaussianProcess"]
def super_fit_predict(Xa, ya, Ga, Xb, seed):
    inner = list(StratifiedGroupKFold(3, shuffle=True, random_state=seed).split(Xa, ya, Ga))
    # (1) in-fold hyper-parameter search
    best, bs = None, -1
    for kind, p in GRID:
        po = np.zeros(len(ya))
        for ia, ib in inner: po[ib] = mk(kind, p).fit(Xa[ia], ya[ia]).predict_proba(Xa[ib])[:, 1]
        s = accuracy_score(ya, po > .5)
        if s > bs: best, bs = (kind, p), s
    # (2) super learner: OOF predictions of base learners + tuned model -> logistic meta
    names = BASE + ["tuned"]; O = np.zeros((len(ya), len(names)))
    for ia, ib in inner:
        for j, n in enumerate(names):
            m = mk(*best) if n == "tuned" else LEARN[n](); O[ib, j] = m.fit(Xa[ia], ya[ia]).predict_proba(Xa[ib])[:, 1]
    meta = LogisticRegression(C=1., max_iter=1000).fit(np.log(O / (1 - O + 1e-6) + 1e-6).clip(-8, 8), ya)
    Ob = np.column_stack([(mk(*best) if n == "tuned" else LEARN[n]()).fit(Xa, ya).predict_proba(Xb)[:, 1] for n in names])
    return meta.predict_proba(np.log(Ob / (1 - Ob + 1e-6) + 1e-6).clip(-8, 8))[:, 1], best
res = {}
for gname, grp in [("rounding-duplicate grouping", G)]:
    accs, aucs, picks = [], [], []
    for r in range(2):
        pp = np.zeros(len(y))
        for a, b_ in StratifiedGroupKFold(5, shuffle=True, random_state=r).split(X, y, grp):
            pp[b_], bst = super_fit_predict(X[a], y[a], grp[a], X[b_], r); picks.append(bst[0])
        accs.append(accuracy_score(y, pp > .5)); aucs.append(roc_auc_score(y, pp)); print(f"super-learner repeat {r+1}: acc {accs[-1]:.3f} auc {aucs[-1]:.3f}", flush=True)
    res["nested super-learner, ALL-20 + Bishop"] = dict(Accuracy=float(np.mean(accs)), AUROC=float(np.mean(aucs)))
# ceiling test: LEAKY random 5-fold (no grouping) - an upper bound, NOT a valid estimate
for nm, XX in [("LEAKY random split, ALL-20 + Bishop, Vote", X), ("LEAKY random split, no experts, LightGBM", XR)]:
    l = "Vote(CatBoost+LightGBM+XGBoost+RandomForest)" if "Vote" in nm else "LightGBM"; acc = []
    for r in range(3):
        pp = np.zeros(len(y))
        for a, b_ in StratifiedKFold(5, shuffle=True, random_state=r).split(XX, y): pp[b_] = LEARN[l]().fit(XX[a], y[a]).predict_proba(XX[b_])[:, 1]
        acc.append(accuracy_score(y, pp > .5))
    res[nm] = dict(Accuracy=float(np.mean(acc))); print(nm, round(np.mean(acc), 3), flush=True)
prev = pd.read_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T9_push_all20_bishop_catboost.csv"))
res["max over ALL ~650 configurations (selection-biased upper bound)"] = dict(Accuracy=float(max(prev.Accuracy.max(), .846)))
pd.DataFrame(res).T.round(4).to_csv((__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/realworld_combinations/T11_superlearner_and_ceiling.csv")); print(pd.DataFrame(res).T.round(3).to_string()); print("DONE")
