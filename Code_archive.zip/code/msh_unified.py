"""
UNIFIED, LEAKAGE-AUDITED STUDY - every model uses exactly the same data, splits, features and objective.

DATA (identical for all 20 models)
  SVA (120,000 synthetic slopes, exact FoS)  +  363 real case-history slopes (failed / stable, i.e. interval-censored FoS)
  Train  = SVA-train (70 %)  + Real-train (60 %)
  Val    = SVA-val   (7.5 %) + Real-val (20 %)      early stopping, meta-learner fitting (cross-fitted)
  Calib  = SVA-calib (7.5 %)                         conformal calibration ONLY (never seen by any model)
  Test   = SVA-test  (15 %)  + Real-test (20 %)      reported once, after model selection on validation
  External (never used for training or selection): 128 real rock slopes (Case Study I),
           30 % of Morgenstern-Price geometries (seismic benchmark)

ONE OBJECTIVE FOR ALL MODELS - interval-censored squared loss
  SVA slope:  FoS known exactly           -> [lo, hi] = [FoS, FoS]          (ordinary squared error)
  Real failed slope:  FoS < 1             -> [0.25, 0.999]
  Real stable slope:  FoS >= 1            -> [1.0, 5.0]
  loss = w * ( relu(lo - pred)^2 + relu(pred - hi)^2 ),  w = 1 (SVA) or W_REAL (real)
  DL: used directly. XGBoost / LightGBM: custom gradient/hessian. Random forest and linear meta-learners:
  censored-target projection (alternating minimisation of the same loss).

LEAKAGE FIXES vs. rounds 1-3
  L1 seismic-correction model (s_model) was fitted on ALL SVA rows incl. test -> now train rows only
  L2 Morgenstern-Price surrogate and MP seismic check used the same data (circular) -> grouped 70/30 geometry split
  L3 conformal calibration rows had been used for early stopping -> separate, untouched calibration set
  L4 meta-learners (stacking, GME gate) were scored on the data they were fitted on -> 5-fold cross-fitting on val
  L5 real near-duplicate slopes could fall in different folds -> grouped splits (StratifiedGroupKFold)
  L6 final model was chosen by looking at test results -> selection on validation only, test reported once
  L8 meta-learners were fitted with a much larger real-slope weight share on val (40 %) than in training (13 %) -> matched
  L9 real slopes carried a field-case flag and impossible one-hot values (1/6, 1/3) -> models output FoS~1.0 for
     every real slope (boundary collapse); flag removed, nearest-neighbour hot-deck imputation instead
  L10 joint training on 219 interval-labelled real slopes made models memorise FoS~1.0 near real slopes
      (boundary collapse persisted even without a flag) -> real case histories are EXTERNAL validation only
  L7 models used different data (some SVA only, some SVA + real, some fine-tuned) -> one dataset, one objective
"""
import os, json, time, copy, warnings
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import torch, torch.nn as nn, torch.nn.functional as Fnn
import xgboost as xgb, lightgbm as lgb
from scipy.stats import wilcoxon
from sklearn.model_selection import train_test_split, StratifiedGroupKFold, GroupShuffleSplit, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import (r2_score, mean_squared_error, mean_absolute_error, accuracy_score, f1_score,
                             recall_score, roc_auc_score)
warnings.filterwarnings("ignore")

SMOKE = os.environ.get("SMOKE") == "1"
CFG = dict(SVA=(__import__("os").environ.get("MSH_DATA", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/data") + "/1791149933879_Slope_dataset_SVA.csv"), REAL=(__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/real_validation_data/"),
           OUT=(__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/smokeU/") if SMOKE else (__import__("os").environ.get("MSH_OUT", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))) + "/unified_results/"),
           CK=(__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/smokeU/ck/") if SMOKE else (__import__("os").environ.get("MSH_WORK", __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))) + "/work") + "/ckptU3/"),
           SEED=42, W_REAL=50.0, REAL_IN_TRAIN=False, EPOCHS=2 if SMOKE else 40, PAT=6, BS=512, KH=0.15,
           # hyper-parameters found earlier on validation data only (no test information)
           M1=dict(d=16, C=96, H=64, drop=0.18, lr=0.0042, bs=512),
           XGB=dict(max_depth=4, learning_rate=0.0361, subsample=0.941, colsample_bytree=0.853, min_child_weight=1.056, reg_lambda=0.00277),
           LGB=dict(num_leaves=83, learning_rate=0.0395, bagging_fraction=0.626, bagging_freq=1, feature_fraction=0.974,
                    min_data_in_leaf=90, lambda_l2=1.71))
OUT, CK, RS, W = CFG["OUT"], CFG["CK"], CFG["SEED"], CFG["W_REAL"]
for p in (OUT, OUT + "figures", CK): os.makedirs(p, exist_ok=True)
torch.set_num_threads(max(1, os.cpu_count() or 1)); DEV = "cpu"
T0 = time.time(); LOG = {}
def say(*a): print(f"[U {(time.time()-T0)/60:5.1f}m]", *a, flush=True)
def cached(name, fn):
    f = CK + name + ".joblib"
    if os.path.exists(f): say(f"  [cache] {name}"); return joblib.load(f)
    r = fn(); joblib.dump(r, f); return r
def savefig(n): plt.tight_layout(); plt.savefig(OUT + "figures/" + n, dpi=160, bbox_inches="tight"); plt.close()
def to_class(f): return np.where(f < 1.0, 0, np.where(f < 1.3, 1, 2))
CLASSES = ["Failure", "Marginal", "Stable"]

# ===================================================================== 1. SVA split (before any fitting)
say("1  SVA split")
sva = pd.read_csv(CFG["SVA"]).drop(columns="SlopeID"); sva["VegetationCover"] = sva["VegetationCover"].fillna("Unknown")
if SMOKE: sva = sva.sample(8000, random_state=RS).reset_index(drop=True)
c0 = to_class(sva.FactorOfSafety.values); idx = np.arange(len(sva))
s_tr, s_te = train_test_split(idx, test_size=.15, stratify=c0, random_state=RS)
s_tr, s_v = train_test_split(s_tr, test_size=.15 / .85, stratify=c0[s_tr], random_state=RS)
s_va, s_ca = train_test_split(s_v, test_size=.5, stratify=c0[s_v], random_state=RS)
LOG["sva_split"] = dict(train=len(s_tr), val=len(s_va), calib=len(s_ca), test=len(s_te))

# ===================================================================== 2. physics-informed seismic correction (fixes L1, L2)
say("2  seismic correction (train-only, grouped MP split)")
mp = pd.read_csv(CFG["REAL"] + "4_pseudostatic_morgenstern_price_19128.csv"); mp = mp[(mp.kvr == 0) & (mp.fmp > 0)].copy()
key = ["Slope Angle", "CbygammaH", "phi"]; b0 = mp[mp.kh == 0].set_index(key).fmp
mp["ratio"] = mp.fmp / mp.set_index(key).index.map(b0).values; mp = mp.dropna(subset=["ratio"]).reset_index(drop=True)
mp["geom"] = pd.factorize(mp[key].astype(str).agg("|".join, axis=1))[0]
g_tr, g_ho = next(GroupShuffleSplit(1, test_size=.3, random_state=RS).split(mp, groups=mp.geom))
GF = ["Slope Angle", "CbygammaH", "phi", "kh"]
g_model = lgb.LGBMRegressor(n_estimators=600, learning_rate=.05, num_leaves=31, verbose=-1, random_state=RS).fit(mp.iloc[g_tr][GF], mp.iloc[g_tr].ratio)
LOG["MP_surrogate_R2_heldout_geometries"] = float(r2_score(mp.iloc[g_ho].ratio, g_model.predict(mp.iloc[g_ho][GF])))
raw = pd.get_dummies(sva.drop(columns=["FactorOfSafety"]).drop(columns=["StabilityStatus"]), columns=["SoilType", "VegetationCover", "DrainageCondition"], dtype=float)
s_model = lgb.LGBMRegressor(n_estimators=800, learning_rate=.05, num_leaves=63, verbose=-1, random_state=RS).fit(raw.iloc[s_tr], sva.FactorOfSafety.iloc[s_tr])
s_ratio = np.clip(s_model.predict(raw) / s_model.predict(raw.assign(SeismicCoefficient=0.)), .5, 1.2)
N_ = sva.Cohesion_kPa / (sva.UnitWeight_kN_m3 * sva.SlopeHeight_m)
gq = pd.DataFrame({"Slope Angle": sva.SlopeAngle_deg, "CbygammaH": np.clip(N_, 0, mp.CbygammaH.max()), "phi": sva.FrictionAngle_deg, "kh": sva.SeismicCoefficient})
g_ratio = np.clip(g_model.predict(gq) / g_model.predict(gq.assign(kh=0.)), .3, 1.)
sva["FoS"] = np.clip(sva.FactorOfSafety / s_ratio * g_ratio, .25, 5.)
LOG["PIC_class_changed_pct"] = float((to_class(sva.FoS) != c0).mean() * 100)
say("  MP surrogate R2 on held-out geometries %.3f, classes changed %.1f%%" % (LOG["MP_surrogate_R2_heldout_geometries"], LOG["PIC_class_changed_pct"]))

# ===================================================================== 3. features
def physics(H, b, g, c, p, ru):
    br, pr = np.radians(np.clip(b, 1, 89)), np.radians(p)
    return c / (g * H), np.tan(pr) / np.tan(br), c / (g * H * np.sin(br) * np.cos(br)) + (1 - ru) * np.tan(pr) / np.tan(br)
NUM = ["SlopeHeight_m", "SlopeAngle_deg", "UnitWeight_kN_m3", "Cohesion_kPa", "FrictionAngle_deg", "WeatheringIndex", "Rainfall_mm_day",
       "GroundwaterRiseRate_m_day", "GroundwaterDepth_m", "PorePressureRatio", "SeismicCoefficient", "StabilityNumber_N", "FrictionRatio", "FS_infinite"]
F6 = NUM[:5] + ["PorePressureRatio"]
sva["StabilityNumber_N"], sva["FrictionRatio"], sva["FS_infinite"] = physics(*(sva[c] for c in F6))
A_sva = pd.get_dummies(sva[NUM + ["SoilType", "VegetationCover", "DrainageCondition"]], columns=["SoilType", "VegetationCover", "DrainageCondition"], dtype=float)
FEATS = list(A_sva.columns); NF = len(FEATS); fi = {f: i for i, f in enumerate(FEATS)}
LO_, HI_, MED = A_sva.iloc[s_tr][NUM].min(), A_sva.iloc[s_tr][NUM].max(), A_sva.iloc[s_tr].median()
def recompute(D):
    D = D.copy(); D["StabilityNumber_N"], D["FrictionRatio"], D["FS_infinite"] = physics(*(D[c] for c in F6)); return D

# ===================================================================== 4. real case histories (fix L5)
say("4  real case histories")
R = CFG["REAL"]; c1 = pd.read_csv(R + "1_circular_case_histories_184.csv"); c2 = pd.read_csv(R + "2_compiled_case_histories_361.csv")
real = pd.concat([pd.DataFrame(dict(zip(F6, [c1.H_m, c1.beta_deg, c1.gamma_kN_m3, c1.c_kPa, c1.phi_deg, c1.r_u]), fail=(c1.stability == "Failure").astype(int), location=c1.location)),
                  pd.DataFrame(dict(zip(F6, [c2["slope height (m)"], c2["Slope angle"], c2["unit weight(kN/m3)"], c2["Cohesion(kPa)"], c2["internal friction angle"],
                                             c2["pore pressure ratio"]]), fail=(c2.Status == "Failure").astype(int), location="Unknown"))], ignore_index=True)
real[F6] = real[F6].round(2); real = real.drop_duplicates(subset=F6).query("SlopeHeight_m > 0 and UnitWeight_kN_m3 > 0").reset_index(drop=True)
kq = pd.DataFrame(dict(a=real.SlopeHeight_m.round(0), b=real.SlopeAngle_deg.round(0), c=(real.UnitWeight_kN_m3 * 2).round(), d=real.Cohesion_kPa.round(0),
                       e=real.FrictionAngle_deg.round(0), f=(real.PorePressureRatio * 20).round()))
real["group"] = pd.factorize(kq.astype(str).agg("|".join, axis=1))[0]
folds = list(StratifiedGroupKFold(5, shuffle=True, random_state=RS).split(real, real.fail, real.group))
r_te, r_va = folds[0][1], folds[1][1]; r_tr = np.setdiff1d(np.arange(len(real)), np.r_[r_te, r_va])
if not CFG["REAL_IN_TRAIN"]:      # fix L10: real case histories are EXTERNAL validation only (never trained / tuned / selected on)
    r_tr, r_va, r_te = np.array([], int), np.array([], int), np.arange(len(real))
LOG["real_split"] = dict(train=len(r_tr), val=len(r_va), test=len(r_te), groups=int(real.group.nunique()))
from sklearn.neighbors import NearestNeighbors
_F6m, _F6s = A_sva.iloc[s_tr][F6].mean(), A_sva.iloc[s_tr][F6].std()
_NN = NearestNeighbors(n_neighbors=1).fit(((A_sva.iloc[s_tr][F6] - _F6m) / _F6s).values)
_DONOR = A_sva.iloc[s_tr].reset_index(drop=True)
def real_matrix(df, ru_add=0., kh=0.):
    """Real slope -> model input WITHOUT any field-case signature (fix L9): the six measured properties are kept;
    unmeasured environment/hydrology/category features are copied from the most similar SVA training slope
    (nearest neighbour on the six properties, hot-deck imputation). Case histories are static -> kh = 0."""
    q = df[F6].copy()
    for c in F6: q[c] = q[c].clip(LO_[c], HI_[c])
    j = _NN.kneighbors(((q - _F6m) / _F6s).values, return_distance=False)[:, 0]
    D = _DONOR.iloc[j].reset_index(drop=True).copy()
    for c in F6: D[c] = df[c].values
    D["PorePressureRatio"] = np.clip(D.PorePressureRatio + ru_add, 0, .95); D["SeismicCoefficient"] = kh
    D = recompute(D)
    for c in NUM: D[c] = D[c].clip(LO_[c], HI_[c])          # identical clipping rule for every model
    return D[FEATS]
A_real = real_matrix(real)

# ===================================================================== 5. unified sets
def interval(y=None, fail=None):
    if y is not None: return y, y
    return np.where(fail == 1, .25, 1.), np.where(fail == 1, .999, 5.)
def make(Sidx, Ridx):
    A = pd.concat([A_sva.iloc[Sidx], A_real.iloc[Ridx]], ignore_index=True)
    l1, h1 = interval(y=sva.FoS.values[Sidx]); l2, h2 = interval(fail=real.fail.values[Ridx])
    return dict(A=A, lo=np.r_[l1, l2], hi=np.r_[h1, h2], w=np.r_[np.ones(len(Sidx)), np.full(len(Ridx), W)], nS=len(Sidx))
TR, VA = make(s_tr, r_tr), make(s_va, r_va)
# meta-learners use validation weights whose real-slope SHARE matches the training set (fix L8)
SHARE = W * len(r_tr) / len(s_tr); WV = SHARE * len(s_va) / max(len(r_va), 1) if len(r_va) else 0.
VA_M = dict(VA, w=np.r_[np.ones(len(s_va)), np.full(len(r_va), WV)])
CA, TS, TRL = make(s_ca, []), make(s_te, []), make([], r_te)
scaler = StandardScaler().fit(TR["A"])
Z = lambda A: scaler.transform(A[FEATS]).astype(np.float32)
for D in (TR, VA, CA, TS, TRL): D["Z"] = Z(D["A"])
y_te, yR_te, yR_va = TS["lo"], real.fail.values[r_te], real.fail.values[r_va]
MU_t, SD_t = torch.tensor(scaler.mean_, dtype=torch.float32), torch.tensor(scaler.scale_, dtype=torch.float32)
FMU, FSD = float(sva.FoS.values[s_tr].mean()), float(sva.FoS.values[s_tr].std())
LMU, LSD = float(np.log(sva.FoS.values[s_tr]).mean()), float(np.log(sva.FoS.values[s_tr]).std())
say("  train %d (+%d real) | val %d (+%d real) | calib %d | test %d SVA + %d real" % (TR["nS"], len(r_tr), VA["nS"], len(r_va), CA["nS"], TS["nS"], len(r_te)))
def iloss_np(p, D): return float(np.sqrt(np.sum(D["w"] * (np.maximum(D["lo"] - p, 0) ** 2 + np.maximum(p - D["hi"], 0) ** 2)) / D["w"].sum()))

# ===================================================================== 6. tree models with the interval objective
def xgb_obj(lo, hi, w):
    def f(p, dm):
        a, b = p < lo, p > hi; g = np.where(a, 2 * w * (p - lo), np.where(b, 2 * w * (p - hi), 0.)); h = np.where(a | b, 2 * w, 1e-6); return g, h
    return f
def lgb_obj(lo, hi, w):
    def f(p, ds):
        a, b = p < lo, p > hi; return np.where(a, 2 * w * (p - lo), np.where(b, 2 * w * (p - hi), 0.)), np.where(a | b, 2 * w, 1e-6)
    return f
def fit_xgb(A, D, seed=RS, Dv=None, rounds=None):
    dm = xgb.DMatrix(np.asarray(A, dtype=float)); dm.set_base_margin(np.full(len(D["lo"]), FMU))
    p = dict(CFG["XGB"], tree_method="hist", seed=seed, disable_default_eval_metric=1)
    if Dv is None: return xgb.train(p, dm, rounds or (50 if SMOKE else 3000), obj=xgb_obj(D["lo"], D["hi"], D["w"]))
    dv = xgb.DMatrix(np.asarray(Dv["Ax"], dtype=float)); dv.set_base_margin(np.full(len(Dv["lo"]), FMU))
    metric = lambda pr, d: ("iRMSE", iloss_np(pr, Dv))
    return xgb.train(p, dm, 50 if SMOKE else 4000, obj=xgb_obj(D["lo"], D["hi"], D["w"]), evals=[(dv, "val")], custom_metric=metric,
                     early_stopping_rounds=150, verbose_eval=False)
def xgb_pred(m, A):
    A = np.asarray(A, dtype=float); d = xgb.DMatrix(A); d.set_base_margin(np.full(len(A), FMU))
    try: it = (0, m.best_iteration + 1)
    except Exception: it = (0, 0)
    return m.predict(d, iteration_range=it)
def fit_lgb(A, D, Dv):
    ds = lgb.Dataset(np.asarray(A, dtype=float), init_score=np.full(len(D["lo"]), FMU), free_raw_data=False)
    dv = lgb.Dataset(np.asarray(Dv["Ax"], dtype=float), init_score=np.full(len(Dv["lo"]), FMU), reference=ds)
    p = dict(CFG["LGB"], objective=lgb_obj(D["lo"], D["hi"], D["w"]), verbose=-1, seed=RS)
    return lgb.train(p, ds, 5000 if not SMOKE else 50, valid_sets=[dv], feval=lambda pr, d: ("iRMSE", iloss_np(pr, Dv), False),
                     callbacks=[lgb.early_stopping(150, verbose=False)])
lgb_pred = lambda m, A: m.predict(np.asarray(A, dtype=float), num_iteration=m.best_iteration) + FMU
def project(model_fit, model_pred, A, D, iters=2):
    """censored-target projection: real targets <- clip(current prediction, lo, hi); refit (same interval loss)."""
    t = np.where(D["lo"] == D["hi"], D["lo"], (D["lo"] + D["hi"]) / 2); m = None
    for _ in range(iters + 1):
        m = model_fit(A, t, D["w"]); t = np.where(D["lo"] == D["hi"], D["lo"], np.clip(model_pred(m, A), D["lo"], D["hi"]))
    return m
VA["Ax"] = VA["A"].values

PRED = {}                       # name -> function(A DataFrame of FEATS) -> FoS
say("6  tree models")
XGB = cached("xgb", lambda: fit_xgb(TR["A"], TR, Dv=VA)); PRED["XGBoost"] = lambda A: xgb_pred(XGB, A[FEATS])
LGB = cached("lgb", lambda: fit_lgb(TR["A"], TR, VA)); PRED["LightGBM"] = lambda A: lgb_pred(LGB, A[FEATS])
RF = cached("rf", lambda: project(lambda A, t, w: RandomForestRegressor(n_estimators=20 if SMOKE else 150, min_samples_leaf=2, max_samples=.5, n_jobs=-1,
                                                                      random_state=RS).fit(A, t, sample_weight=w), lambda m, A: m.predict(A), TR["A"], TR, iters=1))
PRED["RandomForest"] = lambda A: RF.predict(A[FEATS])

# ===================================================================== 7. deep models (identical data, interval loss)
class Tok(nn.Module):
    def __init__(s, F, d): super().__init__(); s.W = nn.Parameter(torch.randn(F, d) * .1); s.b = nn.Parameter(torch.zeros(F, d))
    def forward(s, x): return x.unsqueeze(-1) * s.W + s.b
class SE(nn.Module):
    def __init__(s, C, r=4): super().__init__(); s.f = nn.Sequential(nn.Linear(C, max(C // r, 4)), nn.ReLU(), nn.Linear(max(C // r, 4), C), nn.Sigmoid())
    def forward(s, h): return h * s.f(h.mean(-1)).unsqueeze(-1)
class Att(nn.Module):
    def __init__(s, d): super().__init__(); s.v = nn.Sequential(nn.Linear(d, d), nn.Tanh(), nn.Linear(d, 1))
    def forward(s, h): a = torch.softmax(s.v(h).squeeze(-1), 1); return (a.unsqueeze(-1) * h).sum(1)
class MHA(nn.Module):
    def __init__(s, d, k=4): super().__init__(); s.q = nn.Parameter(torch.randn(1, 1, d) * .1); s.m = nn.MultiheadAttention(d, k, batch_first=True)
    def forward(s, h): return s.m(s.q.expand(len(h), -1, -1), h, h)[0].squeeze(1)
def cb(d, C): return nn.Sequential(nn.Conv1d(d, C, 3, padding=1), nn.BatchNorm1d(C), nn.ReLU())
class Net(nn.Module):
    def forward(s, x, ex=None): return s.out(s.embed(x, ex)).squeeze(-1)
class DNN(Net):
    def __init__(s, ex=0):
        super().__init__(); s.b = nn.Sequential(nn.Linear(NF + ex, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.1), nn.Linear(256, 128), nn.BatchNorm1d(128),
                                                nn.ReLU(), nn.Dropout(.1), nn.Linear(128, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None): return s.b(x if ex is None else torch.cat([x, ex], 1))
class CNN(Net):
    def __init__(s, d=32):
        super().__init__(); s.t = Tok(NF, d); s.c = nn.Sequential(cb(d, 64), cb(64, 64)); s.f = nn.Sequential(nn.Linear(128, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None): h = s.c(s.t(x).transpose(1, 2)); return s.f(torch.cat([h.mean(-1), h.amax(-1)], 1))
class RNN(Net):
    def __init__(s, kind, d=32, H=64):
        super().__init__(); s.k = kind; s.t = Tok(NF, d)
        s.r1 = nn.GRU(d, H, batch_first=True) if kind == "gru" else nn.LSTM(d, H, batch_first=True)
        s.r2 = nn.GRU(H, H, batch_first=True) if kind == "lstm_gru" else None
        s.f = nn.Sequential(nn.Linear(2 * H, 128), nn.ReLU(), nn.Dropout(.1), nn.Linear(128, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None):
        h, _ = s.r1(s.t(x))
        if s.r2 is not None: h, _ = s.r2(h)
        return s.f(torch.cat([h[:, -1], h.mean(1)], 1))
class M1(Net):                 # CNN-BiLSTM-SE-Attention (Optuna hyper-parameters)
    def __init__(s, p=CFG["M1"]):
        super().__init__(); s.t = Tok(NF, p["d"]); s.c = cb(p["d"], p["C"]); s.se = SE(p["C"]); s.r = nn.LSTM(p["C"], p["H"], batch_first=True, bidirectional=True)
        s.a = Att(2 * p["H"]); s.f = nn.Sequential(nn.Dropout(p["drop"]), nn.Linear(2 * p["H"], 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None): h = s.se(s.c(s.t(x).transpose(1, 2))).transpose(1, 2); h, _ = s.r(h); return s.f(s.a(h))
class M2(Net):                 # Physics-guided CNN/DNN + attention
    PH = None
    def __init__(s, d=32, C=64):
        super().__init__(); s.t = Tok(NF, d); s.c = cb(d, C); s.a = Att(C); s.dn = nn.Sequential(nn.Linear(NF, 128), nn.ReLU(), nn.Linear(128, 64), nn.ReLU())
        s.f = nn.Sequential(nn.Linear(C + 64, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def phys(s, x):
        r = x * SD_t + MU_t; H, b, g, c, p, ru = (r[:, fi[k]] for k in F6); br, pr = torch.deg2rad(b.clamp(1, 89)), torch.deg2rad(p)
        N = c / (g * H); Fr = torch.tan(pr) / torch.tan(br); FS = c / (g * H * torch.sin(br) * torch.cos(br)) + (1 - ru) * Fr; x = x.clone()
        for k, v in (("StabilityNumber_N", N), ("FrictionRatio", Fr), ("FS_infinite", FS)): j = fi[k]; x[:, j] = ((v - MU_t[j]) / SD_t[j]).clamp(-6, 6)
        return x
    def embed(s, x, ex=None):
        x = s.phys(x); h = s.c(s.t(x).transpose(1, 2)).transpose(1, 2); return s.f(torch.cat([s.a(h), s.dn(x)], 1))
class M3(Net):                 # CNN-Transformer-LSTM + multi-head attention
    def __init__(s, d=32, C=64, H=64):
        super().__init__(); s.t = Tok(NF, d); s.c = cb(d, C); s.pos = nn.Parameter(torch.zeros(1, NF, C))
        s.tf = nn.TransformerEncoder(nn.TransformerEncoderLayer(C, 4, 128, .1, batch_first=True), 2); s.r = nn.LSTM(C, H, batch_first=True); s.a = MHA(H)
        s.f = nn.Sequential(nn.Linear(H, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None): h = s.c(s.t(x).transpose(1, 2)).transpose(1, 2) + s.pos; h, _ = s.r(s.tf(h)); return s.f(s.a(h))
class M4(Net):                 # CNN-LSTM-SE + attention
    def __init__(s, d=32, C=64, H=64):
        super().__init__(); s.t = Tok(NF, d); s.c = cb(d, C); s.se = SE(C); s.r = nn.LSTM(C, H, batch_first=True); s.a = Att(H)
        s.f = nn.Sequential(nn.Linear(H, 64), nn.ReLU()); s.out = nn.Linear(64, 1)
    def embed(s, x, ex=None): h = s.se(s.c(s.t(x).transpose(1, 2))).transpose(1, 2); h, _ = s.r(h); return s.f(s.a(h))
NUMI = [fi[c] for c in NUM]; CATI = [i for i in range(NF) if i not in NUMI]
class PLE(nn.Module):
    def __init__(s, Zt, NB=16):
        super().__init__(); E = [np.quantile(Zt[:, j], np.linspace(0, 1, NB + 1)) + np.arange(NB + 1) * 1e-6 for j in NUMI]
        s.register_buffer("E", torch.tensor(np.array(E), dtype=torch.float32))
    def forward(s, xn):
        lo, hi = s.E[:, :-1], s.E[:, 1:]; t = (xn.unsqueeze(-1) - lo) / (hi - lo)
        return torch.cat([t[..., :1].clamp(max=1), t[..., 1:-1].clamp(0, 1), t[..., -1:].clamp(min=0)], -1)
class N1(Net):                 # PLE-ResNet-Attention
    def __init__(s, ex=0, d=16, NB=16, Wd=256):
        super().__init__(); Fn, Fc = len(NUMI), len(CATI); s.p = PLE(TR["Z"], NB); s.ew = nn.Parameter(torch.randn(Fn, NB, d) * .1); s.eb = nn.Parameter(torch.zeros(Fn, d))
        s.ct = Tok(Fc, d); s.a = Att(d); s.i = nn.Linear((Fn + Fc) * d + d + ex, Wd)
        s.bl = nn.ModuleList([nn.Sequential(nn.BatchNorm1d(Wd), nn.Linear(Wd, Wd), nn.ReLU(), nn.Dropout(.1), nn.Linear(Wd, Wd)) for _ in range(3)])
        s.o = nn.Sequential(nn.BatchNorm1d(Wd), nn.ReLU()); s.out = nn.Linear(Wd, 1)
    def embed(s, x, ex=None):
        tn = torch.relu(torch.einsum("bfn,fnd->bfd", s.p(x[:, NUMI]), s.ew) + s.eb); T = torch.cat([tn, s.ct(x[:, CATI])], 1)
        h = s.i(torch.cat([T.flatten(1), s.a(T)] + ([ex] if ex is not None else []), 1))
        for b in s.bl: h = h + b(h)
        return s.o(h)

MONO_DEC = ["SlopeHeight_m", "SlopeAngle_deg", "PorePressureRatio", "SeismicCoefficient", "Rainfall_mm_day"]; MONO_INC = ["Cohesion_kPa", "FrictionAngle_deg", "GroundwaterDepth_m"]
def phys_pen(m, xb):
    xs = xb[:128].clone().requires_grad_(True); g = torch.autograd.grad(m(xs).sum(), xs, create_graph=True)[0]
    return sum(Fnn.relu(g[:, fi[k]]).pow(2).mean() for k in MONO_DEC) + sum(Fnn.relu(-g[:, fi[k]]).pow(2).mean() for k in MONO_INC)

class Space:
    """target transformation: 'fos' (standardised FoS), 'log' (standardised log FoS) or residual on a base prediction"""
    def __init__(s, kind, base_tr=None, base_fn=None):
        s.k, s.bfn = kind, base_fn
        if kind == "res": s.bt = np.log(np.clip(base_tr, .2, 6)); s.rsd = float(np.std(np.log(TR["lo"][:TR["nS"]]) - s.bt[:TR["nS"]]))
    def enc(s, v, base=None):
        if s.k == "fos": return (v - FMU) / FSD
        if s.k == "log": return (np.log(v) - LMU) / LSD
        return (np.log(v) - base) / s.rsd
    def dec(s, o, base=None):
        if s.k == "fos": return o * FSD + FMU
        if s.k == "log": return np.exp(o * LSD + LMU)
        return np.exp(base + o * s.rsd)
def ex_of(sp, A):
    if sp.k != "res": return None, None
    b = np.log(np.clip(sp.bfn(A), .2, 6)); return b, ((b - LMU) / LSD).reshape(-1, 1).astype(np.float32)

@torch.no_grad()
def net_out(m, Zx, ex=None, bs=8192):
    m.eval(); return np.concatenate([m(torch.tensor(Zx[k:k + bs]), None if ex is None else torch.tensor(ex[k:k + bs])).numpy() for k in range(0, len(Zx), bs)])
def train_dl(name, build, sp, lr=2e-3, bs=512, phys=0., epochs=None):
    epochs = epochs or CFG["EPOCHS"]; ff = CK + name + ".pt"
    btr, extr = (sp.bt, ((sp.bt - LMU) / LSD).reshape(-1, 1).astype(np.float32)) if sp.k == "res" else (None, None)
    bva, exva = ex_of(sp, VA["A"])
    if os.path.exists(ff):
        m = build(); m.load_state_dict(torch.load(ff, weights_only=False)["s"]); m.eval(); say(f"  [cache] {name}"); return m
    torch.manual_seed(RS); np.random.seed(RS); m = build(); opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=.5, patience=2); f = CK + name + "_tr.pt"; st0, best, bad, bst, hist = 0, 1e9, 0, None, []
    if os.path.exists(f):
        s_ = torch.load(f, weights_only=False); m.load_state_dict(s_["m"]); opt.load_state_dict(s_["o"]); st0, best, bad, bst, hist = s_["e"] + 1, s_["b"], s_["bad"], s_["bst"], s_["h"]
    X_ = torch.tensor(TR["Z"]); LO = torch.tensor(sp.enc(TR["lo"], btr), dtype=torch.float32); HI = torch.tensor(sp.enc(TR["hi"], btr), dtype=torch.float32)
    W_ = torch.tensor(TR["w"], dtype=torch.float32); EX = torch.tensor(extr) if extr is not None else None; t0 = time.time()
    for ep in range(st0, epochs):
        if bad >= CFG["PAT"]: break
        m.train(); pm = torch.randperm(len(X_))
        for k in range(0, len(X_), bs):
            b = pm[k:k + bs]; xb = X_[b]; o = m(xb, EX[b] if EX is not None else None)
            loss = (W_[b] * (Fnn.relu(LO[b] - o) ** 2 + Fnn.relu(o - HI[b]) ** 2)).sum() / W_[b].sum()
            if phys: loss = loss + phys * phys_pen(m, xb)
            opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(m.parameters(), 5.); opt.step()
        v = iloss_np(sp.dec(net_out(m, VA["Z"], exva), bva), VA); hist.append(v); sch.step(v)
        if v < best - 1e-6: best, bad, bst = v, 0, copy.deepcopy(m.state_dict())
        else: bad += 1
        torch.save(dict(m=m.state_dict(), o=opt.state_dict(), e=ep, b=best, bad=bad, bst=bst, h=hist), f)
    m.load_state_dict(bst); m.eval(); torch.save(dict(s=bst, h=hist), ff); say(f"  {name}: {len(hist)} ep, val iRMSE {best:.4f}, {time.time()-t0:.0f}s"); return m
def dl_fn(m, sp):
    def f(A): b, ex = ex_of(sp, A); return sp.dec(net_out(m, Z(A), ex), b)
    return f

say("7  deep models")
SF, SL = Space("fos"), Space("log"); DL = {}
for name, build, sp, kw in [("DNN", lambda: DNN(), SF, {}), ("1D-CNN", lambda: CNN(), SF, {}), ("LSTM", lambda: RNN("lstm"), SF, {}),
                            ("GRU", lambda: RNN("gru"), SF, {}), ("LSTM-GRU-DNN", lambda: RNN("lstm_gru"), SF, {}),
                            ("M1 CNN-BiLSTM-SE-Attention", lambda: M1(), SF, dict(lr=CFG["M1"]["lr"])),
                            ("M2 Physics-Guided CNN-DNN-Attention", lambda: M2(), SF, dict(phys=1.)),
                            ("M3 CNN-Transformer-LSTM-MHA", lambda: M3(), SF, dict(lr=1e-3)),
                            ("M4 CNN-LSTM-SE-Attention", lambda: M4(), SF, {}),
                            ("N1 PLE-ResNet-Attention", lambda: N1(), SL, {})]:
    tag = "".join(ch for ch in name if ch.isalnum())[:30]
    DL[name] = train_dl(tag, build, sp, **kw); PRED[name] = dl_fn(DL[name], sp)

# ===================================================================== 8. hybrids (all on the same data)
say("8  hybrids")
def emb(m, A, bs=8192):
    Zx = Z(A); m.eval()
    with torch.no_grad(): return np.concatenate([m.embed(torch.tensor(Zx[k:k + bs])).numpy() for k in range(0, len(Zx), bs)])
def emb_xgb(dlname):
    m = DL[dlname]; Etr, Eva = emb(m, TR["A"]), emb(m, VA["A"])
    D = dict(VA, Ax=np.hstack([VA["A"].values, Eva])); return fit_xgb(np.hstack([TR["A"].values, Etr]), TR, Dv=D)
for dlname, hname in [("1D-CNN", "Hybrid CNN-XGBoost"), ("LSTM-GRU-DNN", "Hybrid LSTM-GRU-DNN-XGBoost"), ("DNN", "_DNN-embedding-XGBoost")]:
    mdl = cached("h_" + hname[7:10] + dlname[:4], lambda dlname=dlname: emb_xgb(dlname))
    PRED[hname] = (lambda A, mdl=mdl, dlname=dlname: xgb_pred(mdl, np.hstack([A[FEATS].values, emb(DL[dlname], A)])))
# N2: XGBoost -> deep residual (out-of-fold XGBoost on the same combined training set)
def oof():
    o = np.zeros(len(TR["lo"]))
    for a, b in KFold(5, shuffle=True, random_state=RS).split(TR["A"]):
        Dk = {k: (v[a] if isinstance(v, np.ndarray) else v) for k, v in TR.items() if k in ("lo", "hi", "w")}
        mk = fit_xgb(TR["A"].iloc[a], Dk, rounds=XGB.best_iteration + 1); o[b] = xgb_pred(mk, TR["A"].iloc[b])
    return o
OOF = cached("xgb_oof", oof)
SR = Space("res", OOF, PRED["XGBoost"])
CFG_X_N = XGB.best_iteration + 1
DL["N2"] = train_dl("N2res", lambda: N1(ex=1), SR, lr=1e-3); PRED["N2 XGBoost->Deep-Residual"] = dl_fn(DL["N2"], SR)
# validation / test prediction matrices
BASE = list(PRED)
PV = cached("PV", lambda: {n: PRED[n](VA["A"]) for n in BASE})
PT = cached("PT", lambda: {n: PRED[n](TS["A"]) for n in BASE})
PRT = cached("PRT", lambda: {n: PRED[n](TRL["A"]) for n in BASE})
PC = cached("PC", lambda: {n: PRED[n](CA["A"]) for n in BASE})

# meta-learners: fitted on VAL with the same interval loss (projection), scored by 5-fold cross-fitting (fix L4)
def fit_ridge(P, D, idx=None):
    idx = np.arange(len(D["lo"])) if idx is None else idx; Dk = {k: D[k][idx] for k in ("lo", "hi", "w")}
    return project(lambda A, t, w: Ridge(alpha=1e-3, positive=True).fit(A, t, sample_weight=w), lambda m, A: m.predict(A), P[idx], Dk, iters=2)
def crossfit(fit, predict, P, D):
    o = np.zeros(len(D["lo"]))
    for a, b in KFold(5, shuffle=True, random_state=RS).split(P): o[b] = predict(fit(P, D, a), P[b])
    return o
STACKS = {"Hybrid Stacked (ML+DL)": ["XGBoost", "LightGBM", "1D-CNN", "LSTM-GRU-DNN", "Hybrid CNN-XGBoost", "Hybrid LSTM-GRU-DNN-XGBoost"],
          "M5 DNN-XGBoost/LightGBM Stacking": ["DNN", "XGBoost", "LightGBM", "_DNN-embedding-XGBoost"],
          "Ridge stacking of all experts": None}
EXPERTS = ["M1 CNN-BiLSTM-SE-Attention", "M2 Physics-Guided CNN-DNN-Attention", "M3 CNN-Transformer-LSTM-MHA", "M4 CNN-LSTM-SE-Attention",
           "XGBoost", "LightGBM", "RandomForest", "N1 PLE-ResNet-Attention", "N2 XGBoost->Deep-Residual"]
STACKS["Ridge stacking of all experts"] = EXPERTS
mat = lambda P, cols: np.column_stack([P[c] for c in cols])
VAL_CF, META = {}, {}
for sn, cols in STACKS.items():
    META[sn] = fit_ridge(mat(PV, cols), VA_M); VAL_CF[sn] = crossfit(fit_ridge, lambda m, X: m.predict(X), mat(PV, cols), VA_M)
    PT[sn] = META[sn].predict(mat(PT, cols)); PRT[sn] = META[sn].predict(mat(PRT, cols)); PC[sn] = META[sn].predict(mat(PC, cols))
    PRED[sn] = (lambda A, sn=sn, cols=cols: META[sn].predict(np.column_stack([PRED[c](A) for c in cols])))

# N3 GME: gated mixture of experts, interval loss, cross-fitted on val
K = len(EXPERTS)
class Gate(nn.Module):
    def __init__(s, mu, sd):
        super().__init__(); s.mu, s.sd = torch.tensor(mu, dtype=torch.float32), torch.tensor(sd, dtype=torch.float32)
        s.n = nn.Sequential(nn.Linear(NF + K, 128), nn.ReLU(), nn.Dropout(.1), nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, K))
    def forward(s, z, lp): w = torch.softmax(s.n(torch.cat([z, (lp - s.mu) / s.sd], 1)), 1); return torch.exp((w * lp).sum(1)), w
def fit_gate(Zx, LP, D, idx, seed=0):
    torch.manual_seed(seed); rng = np.random.default_rng(seed); idx = rng.permutation(idx); a, b = idx[: int(.85 * len(idx))], idx[int(.85 * len(idx)):]
    g = Gate(LP[a].mean(0), LP[a].std(0) + 1e-6); opt = torch.optim.Adam(g.parameters(), lr=1e-3, weight_decay=1e-5)
    T = lambda v: torch.tensor(v, dtype=torch.float32); Zt, Lt, lo, hi, w = T(Zx), T(LP), T(D["lo"]), T(D["hi"]), T(D["w"]); best, bst, bad = 1e9, None, 0
    il = lambda o, j: ((w[j] * (Fnn.relu(lo[j] - o) ** 2 + Fnn.relu(o - hi[j]) ** 2)).sum() / w[j].sum())
    for ep in range(10 if SMOKE else 300):
        g.train(); pm = rng.permutation(a)
        for k in range(0, len(pm), 256): j = torch.tensor(pm[k:k + 256]); loss = il(g(Zt[j], Lt[j])[0], j); opt.zero_grad(); loss.backward(); opt.step()
        g.eval()
        with torch.no_grad(): v = il(g(Zt[torch.tensor(b)], Lt[torch.tensor(b)])[0], torch.tensor(b)).item()
        if v < best - 1e-8: best, bst, bad = v, copy.deepcopy(g.state_dict()), 0
        else:
            bad += 1
            if bad >= 15: break
    g.load_state_dict(bst); g.eval(); return g
@torch.no_grad()
def gate_pred(gs, Zx, LP): o = [g(torch.tensor(Zx), torch.tensor(LP, dtype=torch.float32)) for g in gs]; return np.mean([a.numpy() for a, _ in o], 0), np.mean([w.numpy() for _, w in o], 0)
LPV = np.log(np.clip(mat(PV, EXPERTS), .2, 6))
def gme_all():
    cf = np.zeros(len(VA["lo"]))
    for a, b in KFold(5, shuffle=True, random_state=RS).split(LPV): cf[b] = gate_pred([fit_gate(VA["Z"], LPV, VA_M, a)], VA["Z"][b], LPV[b])[0]
    gs = [fit_gate(VA["Z"], LPV, VA_M, np.arange(len(LPV)), seed=s) for s in range(3)]
    return dict(cf=cf, states=[g.state_dict() for g in gs], mu=[g.mu.numpy() for g in gs], sd=[g.sd.numpy() for g in gs])
GM = cached("gme", gme_all); GS = []
for st, mu, sd in zip(GM["states"], GM["mu"], GM["sd"]): g = Gate(mu, sd); g.load_state_dict(st); g.eval(); GS.append(g)
NG = "N3 GME: Gated Mixture of Deep & Boosted Experts"; VAL_CF[NG] = GM["cf"]
gm = lambda Zx, P: gate_pred(GS, Zx, np.log(np.clip(mat(P, EXPERTS), .2, 6)))
PT[NG], W_TE = gm(TS["Z"], PT); PRT[NG] = gm(TRL["Z"], PRT)[0]; PC[NG] = gm(CA["Z"], PC)[0]
PRED[NG] = lambda A: gm(Z(A), {c: PRED[c](A) for c in EXPERTS})[0]
ALL = [n for n in BASE if not n.startswith("_")] + list(STACKS) + [NG]

# ===================================================================== 9. selection on VALIDATION (fix L6), then test once
say("9  validation-based selection")
def sva_m(y, p):
    p = np.clip(p, .25, 5); a, b = to_class(y), to_class(p)
    return dict(RMSE=mean_squared_error(y, p) ** .5, R2=r2_score(y, p), MAE=mean_absolute_error(y, p), Accuracy=accuracy_score(a, b),
                MacroF1=f1_score(a, b, average="macro"), Recall_Failure=recall_score(a == 0, b == 0), F1_Marginal=f1_score(a == 1, b == 1))
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss
def real_calibrated(yf, p, groups):
    """P(fail) from predicted FoS via logistic calibration fitted with grouped 5-fold CV on the real data
    (monotone 1-D map: cannot change AUROC; it only converts FoS into calibrated probabilities)."""
    pr = np.zeros(len(p))
    for a, b in StratifiedGroupKFold(5, shuffle=True, random_state=RS).split(p, yf, groups):
        pr[b] = LogisticRegression().fit(np.c_[-p[a]], yf[a]).predict_proba(np.c_[-p[b]])[:, 1]
    return pr
def ece(y, p, bins=10):
    e = 0.; ed = np.linspace(0, 1, bins + 1)
    for lo_, hi_ in zip(ed[:-1], ed[1:]):
        m = (p >= lo_) & ((p < hi_) if hi_ < 1 else (p <= hi_))
        if m.any(): e += m.mean() * abs(y[m].mean() - p[m].mean())
    return e
def real_m(yf, p):
    return dict(AUC=roc_auc_score(yf, -p) if len(np.unique(yf)) > 1 else np.nan, Accuracy=accuracy_score(yf, p < 1), Recall_Failure=recall_score(yf, p < 1, zero_division=0))
nSv = VA["nS"]; sel = {}
for n in ALL:
    pv = VAL_CF.get(n, PV.get(n)); sel[n] = dict(val_SVA_RMSE=sva_m(VA["lo"][:nSv], pv[:nSv])["RMSE"],
                                                 val_real_AUC=real_m(yR_va, pv[nSv:])["AUC"] if len(yR_va) else np.nan)
SEL = pd.DataFrame(sel).T
SEL["rank_rmse"] = SEL.val_SVA_RMSE.rank(); SEL["rank_auc"] = SEL.val_real_AUC.rank(ascending=False) if SEL.val_real_AUC.notna().any() else SEL.rank_rmse
SEL["mean_rank"] = (SEL.rank_rmse + SEL.rank_auc) / 2
SEL = SEL.sort_values("mean_rank"); SEL.round(4).to_csv(OUT + "T0_validation_model_selection.csv"); CHOSEN = SEL.index[0]
LOG["selected_on_validation"] = CHOSEN; say("  selected on validation:", CHOSEN)

say("10  test evaluation (reported once)")
GR_te = real.group.values[r_te]
def real_full(n):
    d = {"Real_" + k: v for k, v in real_m(yR_te, PRT[n]).items()}; pc = real_calibrated(yR_te, PRT[n], GR_te)
    d.update(Real_AUPRC=average_precision_score(yR_te, -PRT[n]), Real_cal_Accuracy=accuracy_score(yR_te, pc > .5), Real_cal_Brier=brier_score_loss(yR_te, pc),
             Real_cal_ECE=ece(yR_te, pc), Real_pred_FoS_sd=float(np.std(PRT[n])), Real_pct_pred_within_0_02_of_1=float(np.mean(np.abs(PRT[n] - 1) < .02) * 100))
    return d
T = pd.DataFrame({n: {**sva_m(y_te, PT[n]), **real_full(n)} for n in ALL}).T
rng = np.random.default_rng(RS); BI = [rng.integers(0, len(y_te), len(y_te)) for _ in range(500)]
BR = [rng.integers(0, len(yR_te), len(yR_te)) for _ in range(1000)]
bestT = T.RMSE.idxmin(); eb = (np.clip(PT[bestT], .25, 5) - y_te) ** 2
for n in ALL:
    p = np.clip(PT[n], .25, 5); r = [mean_squared_error(y_te[j], p[j]) ** .5 for j in BI]
    T.loc[n, "RMSE_CI_low"], T.loc[n, "RMSE_CI_high"] = np.percentile(r, 2.5), np.percentile(r, 97.5)
    T.loc[n, "Wilcoxon_p_vs_lowest_RMSE"] = np.nan if n == bestT else wilcoxon(eb, (p - y_te) ** 2, alternative="less").pvalue
    au = [roc_auc_score(yR_te[j], -PRT[n][j]) for j in BR if len(np.unique(yR_te[j])) > 1]
    T.loc[n, "Real_AUC_CI_low"], T.loc[n, "Real_AUC_CI_high"] = (np.percentile(au, 2.5), np.percentile(au, 97.5)) if au else (np.nan, np.nan)
T["Selected_on_validation"] = T.index == CHOSEN
T = T.sort_values("RMSE"); T.round(5).to_csv(OUT + "T1_test_all_models_same_data.csv")
say("\n" + T[["RMSE", "R2", "Accuracy", "F1_Marginal", "Real_AUC", "Real_Accuracy"]].round(4).to_string())

# ===================================================================== 11. physics consistency, seismic (held-out MP), case study I, stress tests
say("11  physics / external checks")
XS = TS["A"].sample(min(3000, len(TS["A"])), random_state=RS)
HYD = ["Rainfall_mm_day", "GroundwaterDepth_m", "GroundwaterRiseRate_m_day", "WeatheringIndex"] + [c for c in FEATS if c.startswith(("SoilType_", "VegetationCover_", "DrainageCondition_"))]
ru_m = lgb.LGBMRegressor(n_estimators=600, learning_rate=.05, num_leaves=63, verbose=-1, random_state=RS).fit(A_sva.iloc[s_tr][HYD], A_sva.iloc[s_tr].PorePressureRatio)
chain = lambda f: (lambda D: f(recompute(D.assign(PorePressureRatio=np.clip(ru_m.predict(D[HYD]), .02, .6)))))
STEP = dict(PorePressureRatio=.05, SeismicCoefficient=.03, Rainfall_mm_day=30, SlopeAngle_deg=3, Cohesion_kPa=5, FrictionAngle_deg=2)
def checks():
    V, S, C1, ST = {}, {}, {}, {}
    mpo = mp.iloc[g_ho]; mpc = mpo.groupby(mpo.kh.round(2)).ratio.median(); kv = np.round(np.arange(0, .31, .05), 2)
    pl = pd.read_csv(CFG["REAL"] + "3_planar_rock_slopes_seismic_149.csv"); pl = pl[pl.case_class == "REAL"]
    gm_ = ["location", "slope_angle_af_deg", "failure_plane_dip_ap_deg", "h_m", "unit_weight_gamma_kNm3", "friction_angle_phi_deg", "cohesion_C_kPa"]; cs = []
    for _, g in pl.groupby(gm_):
        def fs(kh, wet):
            s = g[(g.seismic_kh.round(2) == kh) & ((g.saturation != "dry") if wet else (g.saturation == "dry"))]
            if wet and len(s): s = s[s.water_fraction_or_pct == s.water_fraction_or_pct.min()]
            return (s.FoS.iloc[0], s.water_fraction_or_pct.iloc[0]) if len(s) else (np.nan, np.nan)
        f0, _ = fs(0., 0); fw, wf = fs(0., 1); fe, _ = fs(.15, 0); fb, _ = fs(.15, 1)
        if not np.isnan([f0, fw, fe, fb]).any(): cs.append(dict(wf=wf, rain=fw / f0, eq=fe / f0, both=fb / f0))
    cs = pd.DataFrame(cs); Xq = XS.iloc[:600]
    for n in ALL:
        f = PRED[n]; base = f(XS); r = {}
        for k, st in STEP.items():
            if k == "Rainfall_mm_day": cf = chain(f); D = XS.copy(); D[k] += st; d = cf(D) - cf(XS)
            else: D = XS.copy(); D[k] += st; d = f(recompute(D)) - base
            r[k] = float(np.mean(d > 1e-3) if k in MONO_DEC else np.mean(d < -1e-3)) * 100
        V[n] = r
        v = np.array([f(Xq.assign(SeismicCoefficient=k)).mean() for k in kv]); S[n] = v / v[0]
        rr = []
        for wf in cs.wf.unique():
            ruw = np.clip(wf * 9.81 / Xq.UnitWeight_kN_m3.values, .02, .6); run = lambda ru, kh: f(recompute(Xq.assign(PorePressureRatio=ru, SeismicCoefficient=kh)))
            a, b_, c_, d_ = run(.02, 0.), run(ruw, 0.), run(.02, .15), run(ruw, .15); rr += [dict(rain=np.median(b_ / a), eq=np.median(c_ / a), both=np.median(d_ / a))] * int((cs.wf == wf).sum())
        C1[n] = pd.DataFrame(rr).median().to_dict()
        Rt = real.iloc[r_te]; out = {}
        for sc, (ra, kh) in {"baseline": (0, 0), "rain": (.2, 0), "eq": (0, .15), "both": (.2, .15)}.items(): out[sc] = f(real_matrix(Rt, ra, kh))
        ST[n] = dict(rain_lowers_FoS_pct=float(np.mean(out["rain"] <= out["baseline"] + 1e-6) * 100), eq_lowers_FoS_pct=float(np.mean(out["eq"] <= out["baseline"] + 1e-6) * 100),
                     mean_FoS_baseline=float(out["baseline"].mean()), mean_FoS_both=float(out["both"].mean()))
    S = pd.DataFrame(S, index=kv); S["Morgenstern-Price (held-out geometries)"] = mpc.reindex(kv).values
    C1 = pd.DataFrame(C1).T; C1.loc["Real rock slopes (reported)"] = cs[["rain", "eq", "both"]].median()
    return pd.DataFrame(V).T, S, C1, pd.DataFrame(ST).T
V, S, C1, ST = cached("checks", checks)
V["Mean"] = V.mean(1); V.round(2).to_csv(OUT + "T2_physics_violation_pct.csv"); S.round(3).to_csv(OUT + "T3_seismic_vs_heldout_MP.csv")
C1.round(3).to_csv(OUT + "T4_case_study_I_rock_slopes.csv"); ST.round(3).to_csv(OUT + "T5_real_test_stress_consistency.csv")
mpcol = S.columns[-1]; LOG["seismic_RMSE_vs_heldout_MP"] = {n: float(np.sqrt(np.nanmean((S[n] - S[mpcol]) ** 2))) for n in ALL}

# ===================================================================== 12. conformal uncertainty on the untouched calibration set
say("12  conformal (selected model)")
def conformal(n):
    e = np.abs(CA["lo"] - PC[n]); rows = []
    for a in (.1, .05):
        q = np.quantile(e, min(1, np.ceil((len(e) + 1) * (1 - a)) / len(e))); lo, hi = PT[n] - q, PT[n] + q
        cov = np.mean((y_te >= lo) & (y_te <= hi)); dec = np.where(hi < 1, 0, np.where(lo >= 1.3, 2, -1)); m = dec >= 0
        rows.append(dict(model=n, alpha=a, half_width=q, coverage=cov, confident_pct=m.mean() * 100,
                         confident_accuracy=accuracy_score(to_class(y_te)[m], dec[m]) if m.any() else np.nan))
    return rows
CFm = pd.DataFrame(conformal(CHOSEN) + (conformal(bestT) if bestT != CHOSEN else [])); CFm.round(4).to_csv(OUT + "T6_conformal.csv")

# ===================================================================== 13. figures + log
t_ = T.sort_values("RMSE", ascending=False)
fig, axs = plt.subplots(1, 2, figsize=(15, 7), sharey=True)
axs[0].barh(t_.index, t_.RMSE, xerr=[t_.RMSE - t_.RMSE_CI_low, t_.RMSE_CI_high - t_.RMSE], color=["#c44e52" if i == CHOSEN else "#4c72b0" for i in t_.index])
axs[0].set(xlabel="SVA test RMSE (95% CI)", title="Same data, same splits, same loss - all models")
axs[1].barh(t_.index, t_.Real_AUC, xerr=[(t_.Real_AUC - t_.Real_AUC_CI_low).clip(0), (t_.Real_AUC_CI_high - t_.Real_AUC).clip(0)], color="#55a868")
axs[1].set(xlabel=f"Real test AUC ({len(r_te)} held-out real slopes, 95% CI)", xlim=(.4, 1)); savefig("F1_all_models_same_data.png")
fig, ax = plt.subplots(figsize=(7, 4.5))
for c in S.columns: ax.plot(S.index, S[c], "k--" if c == mpcol else "-", lw=2.5 if c == mpcol else .8, alpha=1 if c in (mpcol, CHOSEN) else .5, label=c[:28] if c in (mpcol, CHOSEN) else None)
ax.set(xlabel="kh", ylabel="FoS(kh)/FoS(0)", title="Seismic response vs held-out Morgenstern-Price geometries"); ax.legend(fontsize=8); savefig("F2_seismic_vs_MP.png")
LOG.update(selected=CHOSEN, lowest_test_RMSE=bestT, minutes=round((time.time() - T0) / 60, 1),
           gate_weights=dict(zip(EXPERTS, W_TE.mean(0).round(3).tolist())))
json.dump(LOG, open(OUT + "run_log.json", "w"), indent=2, default=str); say("DONE")
