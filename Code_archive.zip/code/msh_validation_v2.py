"""Independent validation of the calibrated equation (seismic term) against 19,128 pseudo-static
Morgenstern-Price solutions of Waris et al. (2025), which were never used to fit the equation."""
import os, json, numpy as np, pandas as pd
ROOT = os.environ.get("MSH_OUT", "/mnt/user-data/outputs"); OUT = ROOT + "/validation_v2/"
p = json.load(open(ROOT + "/calibrated_equation/C2_calibrated_parameters.json"))["lambda-dependent a,b,c"]
mp = pd.read_csv(ROOT + "/real_validation_data/4_pseudostatic_morgenstern_price_19128.csv")
mp = mp[(mp.kvr == 0) & (mp.fmp > 0)].copy()
key = ["Slope Angle", "CbygammaH", "phi"]
F0 = mp[mp.kh == 0].groupby(key).fmp.first(); mp["F0"] = mp.set_index(key).index.map(F0)
mp = mp.dropna(subset=["F0"]); mp = mp[(mp.kh > 0) & (mp.F0 < 10)]
tb = np.tan(np.radians(mp["Slope Angle"])); lam = mp.CbygammaH / np.tan(np.radians(mp.phi.clip(lower=1)))
b = p[2] / (1 + p[3] * lam); c = p[4] * (1 + p[5] * lam)
mp["F_eq"] = mp.F0 * np.clip(1 - b * mp.kh * tb, 1e-3, None) / (1 + c * mp.kh / tb)
mp["F_infinite"] = mp.F0 * (1 - mp.kh * tb) / (1 + mp.kh / tb)   # a=b=c=1 reference
mp["in_range"] = (mp["Slope Angle"].between(15, 50)) & (mp.kh <= 0.2) & (lam <= 2.6) & (mp.phi >= 15)
def stats(d, col):
    e = d[col] / d.fmp - 1; ok = d.fmp >= 0.3
    return dict(n=len(d), R2=1 - ((d.fmp - d[col]) ** 2).sum() / ((d.fmp - d.fmp.mean()) ** 2).sum(), RMSE=np.sqrt(((d.fmp - d[col]) ** 2).mean()),
                MAPE_pct=np.abs(e[ok]).mean() * 100, within_10pct=(np.abs(e[ok]) <= .1).mean() * 100, class_agreement_pct=((d.fmp < 1) == (d[col] < 1)).mean() * 100)
rows = []
for nm, d in [("inside calibration range", mp[mp.in_range]), ("all kh > 0", mp)]:
    for col, lab in [("F_eq", "calibrated equation"), ("F_infinite", "infinite-slope form (a=b=c=1)")]:
        rows.append(dict(subset=nm, model=lab, **stats(d, col)))
T = pd.DataFrame(rows).round(4); T.to_csv(OUT + "V2_equation_vs_Morgenstern_Price.csv", index=False)
mp[["Slope Angle", "CbygammaH", "phi", "kh", "F0", "fmp", "F_eq", "F_infinite", "in_range"]].to_csv(OUT + "V2b_MP_points.csv", index=False)
print(T.to_string()); print(mp["Slope Angle"].unique()[:20], sorted(mp.kh.unique()))
